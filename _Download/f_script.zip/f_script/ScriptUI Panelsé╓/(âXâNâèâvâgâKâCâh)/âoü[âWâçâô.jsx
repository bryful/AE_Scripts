(function(me){
#includepath "./lib;./lib"

    var scriptName = "バージョン";
	
    var exec = function()
    {
        CONSOLE.writeLn(app.version);
    }
    exec();
})(this);