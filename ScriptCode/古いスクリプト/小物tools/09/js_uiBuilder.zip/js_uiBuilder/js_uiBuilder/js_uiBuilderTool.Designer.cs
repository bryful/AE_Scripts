﻿namespace js_uiBuilder
{
	partial class js_uiBuilderTool
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.btnNew = new bryful.button_AE();
			this.pnlParams = new bryful.panel_AE();
			this.btnWidthDown = new bryful.iconbutton_AE();
			this.btnWidthUp = new bryful.iconbutton_AE();
			this.btnHeightDown = new bryful.iconbutton_AE();
			this.btnHeightUp = new bryful.iconbutton_AE();
			this.btnMoveBottom = new bryful.iconbutton_AE();
			this.btnMoveRight = new bryful.iconbutton_AE();
			this.btnMoveLeft = new bryful.iconbutton_AE();
			this.btnMoveTop = new bryful.iconbutton_AE();
			this.stKind = new bryful.statictext_AE();
			this.lstKind = new bryful.dropdownlist_AE();
			this.stName = new bryful.statictext_AE();
			this.edWidth = new bryful.edittext_AE();
			this.edName = new bryful.edittext_AE();
			this.edHeight = new bryful.edittext_AE();
			this.stWidth = new bryful.statictext_AE();
			this.stText = new bryful.statictext_AE();
			this.stHeight = new bryful.statictext_AE();
			this.btnSize = new bryful.button_AE();
			this.edText = new bryful.edittext_AE();
			this.stParent = new bryful.statictext_AE();
			this.lstParent = new bryful.dropdownlist_AE();
			this.stTop = new bryful.statictext_AE();
			this.stLeft = new bryful.statictext_AE();
			this.edLeft = new bryful.edittext_AE();
			this.edTop = new bryful.edittext_AE();
			this.btnSave = new bryful.button_AE();
			this.btnLoad = new bryful.button_AE();
			this.stCtrlList = new bryful.statictext_AE();
			this.lstCtrl = new bryful.listbox_AE();
			this.btnUp = new bryful.button_AE();
			this.btnDown = new bryful.button_AE();
			this.btnRemove = new bryful.button_AE();
			this.btnShowCode = new bryful.button_AE();
			this.btnKind = new bryful.button_AE();
			this.btnParent = new bryful.button_AE();
			this.btnName = new bryful.button_AE();
			this.btnText = new bryful.button_AE();
			this.pnlPos = new bryful.panel_AE();
			this.pnlParams.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.btnWidthDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnWidthUp)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnHeightDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnHeightUp)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveBottom)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveRight)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveLeft)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveTop)).BeginInit();
			this.pnlPos.SuspendLayout();
			this.SuspendLayout();
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "toolWin";
			// 
			// btnNew
			// 
			this.btnNew.IsLocal = true;
			this.btnNew.Location = new System.Drawing.Point(274, 390);
			this.btnNew.Name = "btnNew";
			this.btnNew.Size = new System.Drawing.Size(72, 31);
			this.btnNew.TabIndex = 10;
			this.btnNew.Text = "追加";
			this.btnNew.UseVisualStyleBackColor = true;
			// 
			// pnlParams
			// 
			this.pnlParams.Controls.Add(this.btnText);
			this.pnlParams.Controls.Add(this.btnName);
			this.pnlParams.Controls.Add(this.btnParent);
			this.pnlParams.Controls.Add(this.btnKind);
			this.pnlParams.Controls.Add(this.stKind);
			this.pnlParams.Controls.Add(this.lstKind);
			this.pnlParams.Controls.Add(this.stName);
			this.pnlParams.Controls.Add(this.edName);
			this.pnlParams.Controls.Add(this.stText);
			this.pnlParams.Controls.Add(this.edText);
			this.pnlParams.Controls.Add(this.stParent);
			this.pnlParams.Controls.Add(this.lstParent);
			this.pnlParams.IsLocal = true;
			this.pnlParams.Location = new System.Drawing.Point(157, 42);
			this.pnlParams.Name = "pnlParams";
			this.pnlParams.Size = new System.Drawing.Size(189, 175);
			this.pnlParams.TabIndex = 8;
			this.pnlParams.TabStop = false;
			this.pnlParams.Text = "params";
			// 
			// btnWidthDown
			// 
			this.btnWidthDown.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnWidthDown.BackgroundImage = global::js_uiBuilder.Properties.Resources.widthDown;
			this.btnWidthDown.ImageName = "(dbIcons)/widthDown.png";
			this.btnWidthDown.IsLocal = true;
			this.btnWidthDown.Location = new System.Drawing.Point(126, 119);
			this.btnWidthDown.Name = "btnWidthDown";
			this.btnWidthDown.Size = new System.Drawing.Size(24, 24);
			this.btnWidthDown.TabIndex = 25;
			this.btnWidthDown.TabStop = false;
			// 
			// btnWidthUp
			// 
			this.btnWidthUp.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnWidthUp.BackgroundImage = global::js_uiBuilder.Properties.Resources.widthUp;
			this.btnWidthUp.ImageName = "(dbIcons)/widthUp.png";
			this.btnWidthUp.IsLocal = true;
			this.btnWidthUp.Location = new System.Drawing.Point(97, 119);
			this.btnWidthUp.Name = "btnWidthUp";
			this.btnWidthUp.Size = new System.Drawing.Size(24, 24);
			this.btnWidthUp.TabIndex = 24;
			this.btnWidthUp.TabStop = false;
			// 
			// btnHeightDown
			// 
			this.btnHeightDown.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnHeightDown.BackgroundImage = global::js_uiBuilder.Properties.Resources.heightDown;
			this.btnHeightDown.ImageName = "(dbIcons)/heightDown.png";
			this.btnHeightDown.IsLocal = true;
			this.btnHeightDown.Location = new System.Drawing.Point(156, 119);
			this.btnHeightDown.Name = "btnHeightDown";
			this.btnHeightDown.Size = new System.Drawing.Size(24, 24);
			this.btnHeightDown.TabIndex = 23;
			this.btnHeightDown.TabStop = false;
			// 
			// btnHeightUp
			// 
			this.btnHeightUp.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnHeightUp.BackgroundImage = global::js_uiBuilder.Properties.Resources.heightUp;
			this.btnHeightUp.ImageName = "(dbIcons)/heightUp.png";
			this.btnHeightUp.IsLocal = true;
			this.btnHeightUp.Location = new System.Drawing.Point(156, 91);
			this.btnHeightUp.Name = "btnHeightUp";
			this.btnHeightUp.Size = new System.Drawing.Size(24, 24);
			this.btnHeightUp.TabIndex = 22;
			this.btnHeightUp.TabStop = false;
			// 
			// btnMoveBottom
			// 
			this.btnMoveBottom.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnMoveBottom.BackgroundImage = global::js_uiBuilder.Properties.Resources.moveBottom;
			this.btnMoveBottom.ImageName = "(dbIcons)/moveBottom.png";
			this.btnMoveBottom.IsLocal = true;
			this.btnMoveBottom.Location = new System.Drawing.Point(44, 119);
			this.btnMoveBottom.Name = "btnMoveBottom";
			this.btnMoveBottom.Size = new System.Drawing.Size(24, 24);
			this.btnMoveBottom.TabIndex = 21;
			this.btnMoveBottom.TabStop = false;
			// 
			// btnMoveRight
			// 
			this.btnMoveRight.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnMoveRight.BackgroundImage = global::js_uiBuilder.Properties.Resources.moveRight;
			this.btnMoveRight.ImageName = "(dbIcons)/moveRight.png";
			this.btnMoveRight.IsLocal = true;
			this.btnMoveRight.Location = new System.Drawing.Point(70, 104);
			this.btnMoveRight.Name = "btnMoveRight";
			this.btnMoveRight.Size = new System.Drawing.Size(24, 24);
			this.btnMoveRight.TabIndex = 20;
			this.btnMoveRight.TabStop = false;
			// 
			// btnMoveLeft
			// 
			this.btnMoveLeft.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnMoveLeft.BackgroundImage = global::js_uiBuilder.Properties.Resources.moveLeft;
			this.btnMoveLeft.ImageName = "(dbIcons)/moveleft.png";
			this.btnMoveLeft.IsLocal = true;
			this.btnMoveLeft.Location = new System.Drawing.Point(17, 104);
			this.btnMoveLeft.Name = "btnMoveLeft";
			this.btnMoveLeft.Size = new System.Drawing.Size(24, 24);
			this.btnMoveLeft.TabIndex = 19;
			this.btnMoveLeft.TabStop = false;
			// 
			// btnMoveTop
			// 
			this.btnMoveTop.BackColor = System.Drawing.SystemColors.ControlLight;
			this.btnMoveTop.BackgroundImage = global::js_uiBuilder.Properties.Resources.moveTop;
			this.btnMoveTop.ImageName = "(dbIcons)/moveTop.png";
			this.btnMoveTop.IsLocal = true;
			this.btnMoveTop.Location = new System.Drawing.Point(44, 90);
			this.btnMoveTop.Name = "btnMoveTop";
			this.btnMoveTop.Size = new System.Drawing.Size(24, 24);
			this.btnMoveTop.TabIndex = 18;
			this.btnMoveTop.TabStop = false;
			// 
			// stKind
			// 
			this.stKind.IsLocal = true;
			this.stKind.Location = new System.Drawing.Point(6, 14);
			this.stKind.Name = "stKind";
			this.stKind.Size = new System.Drawing.Size(40, 13);
			this.stKind.TabIndex = 0;
			this.stKind.Text = "種類";
			// 
			// lstKind
			// 
			this.lstKind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.lstKind.FormattingEnabled = true;
			this.lstKind.Index = -1;
			this.lstKind.IsLocal = true;
			this.lstKind.Location = new System.Drawing.Point(10, 30);
			this.lstKind.Name = "lstKind";
			this.lstKind.Size = new System.Drawing.Size(121, 20);
			this.lstKind.TabIndex = 1;
			// 
			// stName
			// 
			this.stName.IsLocal = true;
			this.stName.Location = new System.Drawing.Point(8, 88);
			this.stName.Name = "stName";
			this.stName.Size = new System.Drawing.Size(40, 13);
			this.stName.TabIndex = 6;
			this.stName.Text = "name";
			// 
			// edWidth
			// 
			this.edWidth.IsLocal = true;
			this.edWidth.Location = new System.Drawing.Point(52, 39);
			this.edWidth.Name = "edWidth";
			this.edWidth.Size = new System.Drawing.Size(68, 19);
			this.edWidth.TabIndex = 5;
			// 
			// edName
			// 
			this.edName.IsLocal = true;
			this.edName.Location = new System.Drawing.Point(10, 103);
			this.edName.Name = "edName";
			this.edName.Size = new System.Drawing.Size(121, 19);
			this.edName.TabIndex = 7;
			// 
			// edHeight
			// 
			this.edHeight.IsLocal = true;
			this.edHeight.Location = new System.Drawing.Point(52, 64);
			this.edHeight.Name = "edHeight";
			this.edHeight.Size = new System.Drawing.Size(68, 19);
			this.edHeight.TabIndex = 7;
			// 
			// stWidth
			// 
			this.stWidth.IsLocal = true;
			this.stWidth.Location = new System.Drawing.Point(13, 42);
			this.stWidth.Name = "stWidth";
			this.stWidth.Size = new System.Drawing.Size(35, 13);
			this.stWidth.TabIndex = 4;
			this.stWidth.Text = "width";
			// 
			// stText
			// 
			this.stText.IsLocal = true;
			this.stText.Location = new System.Drawing.Point(10, 125);
			this.stText.Name = "stText";
			this.stText.Size = new System.Drawing.Size(40, 13);
			this.stText.TabIndex = 9;
			this.stText.Text = "text";
			// 
			// stHeight
			// 
			this.stHeight.IsLocal = true;
			this.stHeight.Location = new System.Drawing.Point(10, 66);
			this.stHeight.Name = "stHeight";
			this.stHeight.Size = new System.Drawing.Size(38, 13);
			this.stHeight.TabIndex = 6;
			this.stHeight.Text = "height";
			// 
			// btnSize
			// 
			this.btnSize.IsLocal = true;
			this.btnSize.Location = new System.Drawing.Point(132, 62);
			this.btnSize.Name = "btnSize";
			this.btnSize.Size = new System.Drawing.Size(48, 21);
			this.btnSize.TabIndex = 8;
			this.btnSize.Text = "変更";
			this.btnSize.UseVisualStyleBackColor = true;
			// 
			// edText
			// 
			this.edText.IsLocal = true;
			this.edText.Location = new System.Drawing.Point(10, 140);
			this.edText.Name = "edText";
			this.edText.Size = new System.Drawing.Size(121, 19);
			this.edText.TabIndex = 10;
			// 
			// stParent
			// 
			this.stParent.IsLocal = true;
			this.stParent.Location = new System.Drawing.Point(4, 51);
			this.stParent.Name = "stParent";
			this.stParent.Size = new System.Drawing.Size(40, 13);
			this.stParent.TabIndex = 3;
			this.stParent.Text = "parent";
			// 
			// lstParent
			// 
			this.lstParent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.lstParent.FormattingEnabled = true;
			this.lstParent.Index = -1;
			this.lstParent.IsLocal = true;
			this.lstParent.Location = new System.Drawing.Point(10, 67);
			this.lstParent.Name = "lstParent";
			this.lstParent.Size = new System.Drawing.Size(121, 20);
			this.lstParent.TabIndex = 4;
			// 
			// stTop
			// 
			this.stTop.IsLocal = true;
			this.stTop.Location = new System.Drawing.Point(102, 17);
			this.stTop.Name = "stTop";
			this.stTop.Size = new System.Drawing.Size(24, 13);
			this.stTop.TabIndex = 2;
			this.stTop.Text = "top";
			// 
			// stLeft
			// 
			this.stLeft.IsLocal = true;
			this.stLeft.Location = new System.Drawing.Point(24, 17);
			this.stLeft.Name = "stLeft";
			this.stLeft.Size = new System.Drawing.Size(24, 13);
			this.stLeft.TabIndex = 0;
			this.stLeft.Text = "left";
			// 
			// edLeft
			// 
			this.edLeft.IsLocal = true;
			this.edLeft.Location = new System.Drawing.Point(52, 14);
			this.edLeft.Name = "edLeft";
			this.edLeft.Size = new System.Drawing.Size(47, 19);
			this.edLeft.TabIndex = 1;
			// 
			// edTop
			// 
			this.edTop.IsLocal = true;
			this.edTop.Location = new System.Drawing.Point(128, 14);
			this.edTop.Name = "edTop";
			this.edTop.Size = new System.Drawing.Size(47, 19);
			this.edTop.TabIndex = 3;
			// 
			// btnSave
			// 
			this.btnSave.IsLocal = true;
			this.btnSave.Location = new System.Drawing.Point(9, 12);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(72, 23);
			this.btnSave.TabIndex = 0;
			this.btnSave.Text = "保存";
			this.btnSave.UseVisualStyleBackColor = true;
			// 
			// btnLoad
			// 
			this.btnLoad.IsLocal = true;
			this.btnLoad.Location = new System.Drawing.Point(87, 12);
			this.btnLoad.Name = "btnLoad";
			this.btnLoad.Size = new System.Drawing.Size(72, 23);
			this.btnLoad.TabIndex = 1;
			this.btnLoad.Text = "読み込み";
			this.btnLoad.UseVisualStyleBackColor = true;
			// 
			// stCtrlList
			// 
			this.stCtrlList.IsLocal = true;
			this.stCtrlList.Location = new System.Drawing.Point(15, 41);
			this.stCtrlList.Name = "stCtrlList";
			this.stCtrlList.Size = new System.Drawing.Size(91, 13);
			this.stCtrlList.TabIndex = 3;
			this.stCtrlList.Text = "コントロールリスト";
			// 
			// lstCtrl
			// 
			this.lstCtrl.FormattingEnabled = true;
			this.lstCtrl.IsLocal = true;
			this.lstCtrl.ItemHeight = 12;
			this.lstCtrl.Location = new System.Drawing.Point(12, 59);
			this.lstCtrl.Name = "lstCtrl";
			this.lstCtrl.Size = new System.Drawing.Size(139, 328);
			this.lstCtrl.TabIndex = 4;
			// 
			// btnUp
			// 
			this.btnUp.IsLocal = true;
			this.btnUp.Location = new System.Drawing.Point(16, 393);
			this.btnUp.Name = "btnUp";
			this.btnUp.Size = new System.Drawing.Size(42, 23);
			this.btnUp.TabIndex = 5;
			this.btnUp.Text = "上へ";
			this.btnUp.UseVisualStyleBackColor = true;
			// 
			// btnDown
			// 
			this.btnDown.IsLocal = true;
			this.btnDown.Location = new System.Drawing.Point(64, 393);
			this.btnDown.Name = "btnDown";
			this.btnDown.Size = new System.Drawing.Size(42, 23);
			this.btnDown.TabIndex = 6;
			this.btnDown.Text = "下へ";
			this.btnDown.UseVisualStyleBackColor = true;
			// 
			// btnRemove
			// 
			this.btnRemove.IsLocal = true;
			this.btnRemove.Location = new System.Drawing.Point(109, 394);
			this.btnRemove.Name = "btnRemove";
			this.btnRemove.Size = new System.Drawing.Size(42, 23);
			this.btnRemove.TabIndex = 7;
			this.btnRemove.Text = "消す";
			this.btnRemove.UseVisualStyleBackColor = true;
			// 
			// btnShowCode
			// 
			this.btnShowCode.IsLocal = true;
			this.btnShowCode.Location = new System.Drawing.Point(265, 12);
			this.btnShowCode.Name = "btnShowCode";
			this.btnShowCode.Size = new System.Drawing.Size(72, 23);
			this.btnShowCode.TabIndex = 2;
			this.btnShowCode.Text = "コード";
			this.btnShowCode.UseVisualStyleBackColor = true;
			// 
			// btnKind
			// 
			this.btnKind.IsLocal = true;
			this.btnKind.Location = new System.Drawing.Point(134, 30);
			this.btnKind.Name = "btnKind";
			this.btnKind.Size = new System.Drawing.Size(48, 20);
			this.btnKind.TabIndex = 2;
			this.btnKind.Text = "変更";
			this.btnKind.UseVisualStyleBackColor = true;
			// 
			// btnParent
			// 
			this.btnParent.IsLocal = true;
			this.btnParent.Location = new System.Drawing.Point(134, 67);
			this.btnParent.Name = "btnParent";
			this.btnParent.Size = new System.Drawing.Size(48, 20);
			this.btnParent.TabIndex = 5;
			this.btnParent.Text = "変更";
			this.btnParent.UseVisualStyleBackColor = true;
			// 
			// btnName
			// 
			this.btnName.IsLocal = true;
			this.btnName.Location = new System.Drawing.Point(134, 102);
			this.btnName.Name = "btnName";
			this.btnName.Size = new System.Drawing.Size(48, 20);
			this.btnName.TabIndex = 8;
			this.btnName.Text = "変更";
			this.btnName.UseVisualStyleBackColor = true;
			// 
			// btnText
			// 
			this.btnText.IsLocal = true;
			this.btnText.Location = new System.Drawing.Point(134, 139);
			this.btnText.Name = "btnText";
			this.btnText.Size = new System.Drawing.Size(48, 20);
			this.btnText.TabIndex = 11;
			this.btnText.Text = "変更";
			this.btnText.UseVisualStyleBackColor = true;
			// 
			// pnlPos
			// 
			this.pnlPos.Controls.Add(this.edHeight);
			this.pnlPos.Controls.Add(this.stWidth);
			this.pnlPos.Controls.Add(this.stHeight);
			this.pnlPos.Controls.Add(this.edWidth);
			this.pnlPos.Controls.Add(this.stTop);
			this.pnlPos.Controls.Add(this.btnWidthDown);
			this.pnlPos.Controls.Add(this.stLeft);
			this.pnlPos.Controls.Add(this.btnWidthUp);
			this.pnlPos.Controls.Add(this.edTop);
			this.pnlPos.Controls.Add(this.edLeft);
			this.pnlPos.Controls.Add(this.btnSize);
			this.pnlPos.Controls.Add(this.btnMoveRight);
			this.pnlPos.Controls.Add(this.btnHeightDown);
			this.pnlPos.Controls.Add(this.btnMoveTop);
			this.pnlPos.Controls.Add(this.btnHeightUp);
			this.pnlPos.Controls.Add(this.btnMoveLeft);
			this.pnlPos.Controls.Add(this.btnMoveBottom);
			this.pnlPos.IsLocal = true;
			this.pnlPos.Location = new System.Drawing.Point(157, 223);
			this.pnlPos.Name = "pnlPos";
			this.pnlPos.Size = new System.Drawing.Size(189, 161);
			this.pnlPos.TabIndex = 9;
			this.pnlPos.TabStop = false;
			this.pnlPos.Text = "position";
			// 
			// js_uiBuilderTool
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(358, 426);
			this.Controls.Add(this.pnlPos);
			this.Controls.Add(this.btnShowCode);
			this.Controls.Add(this.btnRemove);
			this.Controls.Add(this.btnDown);
			this.Controls.Add(this.btnUp);
			this.Controls.Add(this.lstCtrl);
			this.Controls.Add(this.stCtrlList);
			this.Controls.Add(this.btnLoad);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.pnlParams);
			this.Controls.Add(this.btnNew);
			this.Name = "js_uiBuilderTool";
			this.Text = "ダイアログデザイナ";
			this.pnlParams.ResumeLayout(false);
			this.pnlParams.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.btnWidthDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnWidthUp)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnHeightDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnHeightUp)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveBottom)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveRight)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveLeft)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnMoveTop)).EndInit();
			this.pnlPos.ResumeLayout(false);
			this.pnlPos.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.button_AE btnNew;
		private bryful.panel_AE pnlParams;
		private bryful.button_AE btnSize;
		private bryful.edittext_AE edHeight;
		private bryful.edittext_AE edWidth;
		private bryful.edittext_AE edLeft;
		private bryful.edittext_AE edTop;
		private bryful.statictext_AE stHeight;
		private bryful.statictext_AE stWidth;
		private bryful.statictext_AE stTop;
		private bryful.statictext_AE stLeft;
		private bryful.button_AE btnLoad;
		private bryful.button_AE btnSave;
		private bryful.statictext_AE stParent;
		private bryful.dropdownlist_AE lstParent;
		private bryful.statictext_AE stCtrlList;
		private bryful.statictext_AE stText;
		private bryful.edittext_AE edText;
		private bryful.statictext_AE stName;
		private bryful.edittext_AE edName;
		private bryful.button_AE btnRemove;
		private bryful.button_AE btnDown;
		private bryful.button_AE btnUp;
		private bryful.listbox_AE lstCtrl;
		private bryful.statictext_AE stKind;
		private bryful.dropdownlist_AE lstKind;
		private bryful.button_AE btnShowCode;
		private bryful.iconbutton_AE btnWidthDown;
		private bryful.iconbutton_AE btnWidthUp;
		private bryful.iconbutton_AE btnHeightDown;
		private bryful.iconbutton_AE btnHeightUp;
		private bryful.iconbutton_AE btnMoveBottom;
		private bryful.iconbutton_AE btnMoveRight;
		private bryful.iconbutton_AE btnMoveLeft;
		private bryful.iconbutton_AE btnMoveTop;
		private bryful.panel_AE pnlPos;
		private bryful.button_AE btnText;
		private bryful.button_AE btnName;
		private bryful.button_AE btnParent;
		private bryful.button_AE btnKind;
	}
}

