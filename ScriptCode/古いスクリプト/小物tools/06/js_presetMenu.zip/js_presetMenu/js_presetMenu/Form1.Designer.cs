﻿namespace js_presetMenu
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.listbox_AE1 = new bryful.listbox_AE();
			this.listbox_AE2 = new bryful.listbox_AE();
			this.btnOK = new bryful.button_AE();
			this.statictext_AE2 = new bryful.statictext_AE();
			this.statictext_AE1 = new bryful.statictext_AE();
			this.btnGetProsetFoler = new bryful.button_AE();
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.cmbPath = new bryful.dropdownlist_AE();
			this.btnDelete = new bryful.button_AE();
			this.SuspendLayout();
			// 
			// listbox_AE1
			// 
			this.listbox_AE1.FormattingEnabled = true;
			this.listbox_AE1.IsLocal = true;
			this.listbox_AE1.ItemHeight = 12;
			this.listbox_AE1.Location = new System.Drawing.Point(12, 81);
			this.listbox_AE1.Name = "listbox_AE1";
			this.listbox_AE1.Size = new System.Drawing.Size(134, 256);
			this.listbox_AE1.TabIndex = 5;
			// 
			// listbox_AE2
			// 
			this.listbox_AE2.Enabled = false;
			this.listbox_AE2.FormattingEnabled = true;
			this.listbox_AE2.IsLocal = true;
			this.listbox_AE2.ItemHeight = 12;
			this.listbox_AE2.Location = new System.Drawing.Point(152, 81);
			this.listbox_AE2.Name = "listbox_AE2";
			this.listbox_AE2.Size = new System.Drawing.Size(237, 256);
			this.listbox_AE2.TabIndex = 6;
			// 
			// btnOK
			// 
			this.btnOK.IsLocal = true;
			this.btnOK.Location = new System.Drawing.Point(152, 343);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(237, 26);
			this.btnOK.TabIndex = 7;
			this.btnOK.Text = "適応";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// statictext_AE2
			// 
			this.statictext_AE2.AutoSize = true;
			this.statictext_AE2.IsLocal = false;
			this.statictext_AE2.Location = new System.Drawing.Point(150, 66);
			this.statictext_AE2.Name = "statictext_AE2";
			this.statictext_AE2.Size = new System.Drawing.Size(87, 12);
			this.statictext_AE2.TabIndex = 4;
			this.statictext_AE2.Text = "FFX(Preset) file";
			// 
			// statictext_AE1
			// 
			this.statictext_AE1.AutoSize = true;
			this.statictext_AE1.IsLocal = false;
			this.statictext_AE1.Location = new System.Drawing.Point(12, 66);
			this.statictext_AE1.Name = "statictext_AE1";
			this.statictext_AE1.Size = new System.Drawing.Size(37, 12);
			this.statictext_AE1.TabIndex = 3;
			this.statictext_AE1.Text = "Folder";
			// 
			// btnGetProsetFoler
			// 
			this.btnGetProsetFoler.IsLocal = true;
			this.btnGetProsetFoler.Location = new System.Drawing.Point(12, 38);
			this.btnGetProsetFoler.Name = "btnGetProsetFoler";
			this.btnGetProsetFoler.Size = new System.Drawing.Size(47, 23);
			this.btnGetProsetFoler.TabIndex = 1;
			this.btnGetProsetFoler.Text = "追加";
			this.btnGetProsetFoler.UseVisualStyleBackColor = true;
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// cmbPath
			// 
			this.cmbPath.FormattingEnabled = true;
			this.cmbPath.Index = -1;
			this.cmbPath.IsLocal = true;
			this.cmbPath.Location = new System.Drawing.Point(12, 12);
			this.cmbPath.Name = "cmbPath";
			this.cmbPath.Size = new System.Drawing.Size(370, 20);
			this.cmbPath.TabIndex = 0;
			// 
			// btnDelete
			// 
			this.btnDelete.IsLocal = true;
			this.btnDelete.Location = new System.Drawing.Point(65, 38);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(47, 23);
			this.btnDelete.TabIndex = 2;
			this.btnDelete.Text = "削除";
			this.btnDelete.UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(401, 381);
			this.Controls.Add(this.btnDelete);
			this.Controls.Add(this.statictext_AE2);
			this.Controls.Add(this.cmbPath);
			this.Controls.Add(this.statictext_AE1);
			this.Controls.Add(this.listbox_AE2);
			this.Controls.Add(this.listbox_AE1);
			this.Controls.Add(this.btnGetProsetFoler);
			this.Controls.Add(this.btnOK);
			this.Name = "Form1";
			this.Text = "プリセットメニュー";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.listbox_AE listbox_AE1;
		private bryful.listbox_AE listbox_AE2;
		private bryful.button_AE btnOK;
		private bryful.button_AE btnGetProsetFoler;
		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.statictext_AE statictext_AE2;
		private bryful.statictext_AE statictext_AE1;
		private bryful.dropdownlist_AE cmbPath;
		private bryful.button_AE btnDelete;
	}
}

