﻿namespace js_editExpression
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.edTargetProperty = new bryful.edittext_AE();
			this.edExp = new bryful.edittext_AE();
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.btnOK = new bryful.button_AE();
			this.btnCancel = new bryful.button_AE();
			this.btnGetProperty = new bryful.button_AE();
			this.lstLayer = new bryful.dropdownlist_AE();
			this.lstProp = new bryful.listbox_AE();
			this.stGetExp = new bryful.statictext_AE();
			this.btnGetExp = new bryful.button_AE();
			this.btnDelExp = new bryful.button_AE();
			this.statictext_AE1 = new bryful.statictext_AE();
			this.statictext_AE3 = new bryful.statictext_AE();
			this.statictext_AE2 = new bryful.statictext_AE();
			this.statictext_AE4 = new bryful.statictext_AE();
			this.edProp = new bryful.edittext_AE();
			this.edInfo = new bryful.edittext_AE();
			this.btnRef = new bryful.button_AE();
			this.SuspendLayout();
			// 
			// edTargetProperty
			// 
			this.edTargetProperty.Enabled = false;
			this.edTargetProperty.IsLocal = true;
			this.edTargetProperty.Location = new System.Drawing.Point(91, 33);
			this.edTargetProperty.Multiline = true;
			this.edTargetProperty.Name = "edTargetProperty";
			this.edTargetProperty.Size = new System.Drawing.Size(806, 38);
			this.edTargetProperty.TabIndex = 3;
			// 
			// edExp
			// 
			this.edExp.Enabled = false;
			this.edExp.IsLocal = true;
			this.edExp.Location = new System.Drawing.Point(215, 138);
			this.edExp.Multiline = true;
			this.edExp.Name = "edExp";
			this.edExp.Size = new System.Drawing.Size(682, 294);
			this.edExp.TabIndex = 10;
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.IsLocal = true;
			this.btnOK.Location = new System.Drawing.Point(720, 443);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 33);
			this.btnOK.TabIndex = 16;
			this.btnOK.Text = "適用";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.IsLocal = true;
			this.btnCancel.Location = new System.Drawing.Point(801, 443);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 33);
			this.btnCancel.TabIndex = 0;
			this.btnCancel.Text = "閉じる";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// btnGetProperty
			// 
			this.btnGetProperty.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnGetProperty.IsLocal = true;
			this.btnGetProperty.Location = new System.Drawing.Point(9, 33);
			this.btnGetProperty.Name = "btnGetProperty";
			this.btnGetProperty.Size = new System.Drawing.Size(74, 38);
			this.btnGetProperty.TabIndex = 2;
			this.btnGetProperty.Text = "プロパティ";
			this.btnGetProperty.UseVisualStyleBackColor = true;
			// 
			// lstLayer
			// 
			this.lstLayer.FormattingEnabled = true;
			this.lstLayer.Index = -1;
			this.lstLayer.IsLocal = true;
			this.lstLayer.Location = new System.Drawing.Point(9, 82);
			this.lstLayer.Name = "lstLayer";
			this.lstLayer.Size = new System.Drawing.Size(148, 20);
			this.lstLayer.TabIndex = 4;
			// 
			// lstProp
			// 
			this.lstProp.FormattingEnabled = true;
			this.lstProp.IsLocal = true;
			this.lstProp.ItemHeight = 12;
			this.lstProp.Location = new System.Drawing.Point(10, 114);
			this.lstProp.Name = "lstProp";
			this.lstProp.Size = new System.Drawing.Size(199, 232);
			this.lstProp.TabIndex = 6;
			// 
			// stGetExp
			// 
			this.stGetExp.IsLocal = true;
			this.stGetExp.Location = new System.Drawing.Point(215, 118);
			this.stGetExp.Name = "stGetExp";
			this.stGetExp.Size = new System.Drawing.Size(467, 17);
			this.stGetExp.TabIndex = 8;
			this.stGetExp.Text = "statictext_AE1";
			// 
			// btnGetExp
			// 
			this.btnGetExp.IsLocal = true;
			this.btnGetExp.Location = new System.Drawing.Point(440, 458);
			this.btnGetExp.Name = "btnGetExp";
			this.btnGetExp.Size = new System.Drawing.Size(239, 23);
			this.btnGetExp.TabIndex = 15;
			this.btnGetExp.Text = "獲得";
			this.btnGetExp.UseVisualStyleBackColor = true;
			// 
			// btnDelExp
			// 
			this.btnDelExp.IsLocal = true;
			this.btnDelExp.Location = new System.Drawing.Point(217, 443);
			this.btnDelExp.Name = "btnDelExp";
			this.btnDelExp.Size = new System.Drawing.Size(132, 33);
			this.btnDelExp.TabIndex = 13;
			this.btnDelExp.Text = "エクスプレッションを削除";
			this.btnDelExp.UseVisualStyleBackColor = true;
			// 
			// statictext_AE1
			// 
			this.statictext_AE1.IsLocal = true;
			this.statictext_AE1.Location = new System.Drawing.Point(13, 16);
			this.statictext_AE1.Name = "statictext_AE1";
			this.statictext_AE1.Size = new System.Drawing.Size(325, 15);
			this.statictext_AE1.TabIndex = 0;
			this.statictext_AE1.Text = "プロパティボタンで選択した項目のアクセスコードを獲得";
			// 
			// statictext_AE3
			// 
			this.statictext_AE3.AutoSize = true;
			this.statictext_AE3.IsLocal = true;
			this.statictext_AE3.Location = new System.Drawing.Point(438, 443);
			this.statictext_AE3.Name = "statictext_AE3";
			this.statictext_AE3.Size = new System.Drawing.Size(241, 12);
			this.statictext_AE3.TabIndex = 14;
			this.statictext_AE3.Text = "ターゲットのエクスプレッションを獲得。まずここを押す";
			// 
			// statictext_AE2
			// 
			this.statictext_AE2.IsLocal = true;
			this.statictext_AE2.Location = new System.Drawing.Point(653, 15);
			this.statictext_AE2.Name = "statictext_AE2";
			this.statictext_AE2.Size = new System.Drawing.Size(244, 15);
			this.statictext_AE2.TabIndex = 1;
			this.statictext_AE2.Text = "curry_eggsさんのエディタが完成するまで暫定版";
			// 
			// statictext_AE4
			// 
			this.statictext_AE4.IsLocal = true;
			this.statictext_AE4.Location = new System.Drawing.Point(723, 118);
			this.statictext_AE4.Name = "statictext_AE4";
			this.statictext_AE4.Size = new System.Drawing.Size(174, 17);
			this.statictext_AE4.TabIndex = 9;
			this.statictext_AE4.Text = "改行は、Ctrl+Returnになります。";
			// 
			// edProp
			// 
			this.edProp.Enabled = false;
			this.edProp.IsLocal = true;
			this.edProp.Location = new System.Drawing.Point(215, 83);
			this.edProp.Name = "edProp";
			this.edProp.Size = new System.Drawing.Size(682, 19);
			this.edProp.TabIndex = 7;
			// 
			// edInfo
			// 
			this.edInfo.Enabled = false;
			this.edInfo.IsLocal = true;
			this.edInfo.Location = new System.Drawing.Point(10, 352);
			this.edInfo.Multiline = true;
			this.edInfo.Name = "edInfo";
			this.edInfo.Size = new System.Drawing.Size(199, 126);
			this.edInfo.TabIndex = 11;
			// 
			// btnRef
			// 
			this.btnRef.IsLocal = true;
			this.btnRef.Location = new System.Drawing.Point(163, 80);
			this.btnRef.Name = "btnRef";
			this.btnRef.Size = new System.Drawing.Size(45, 23);
			this.btnRef.TabIndex = 5;
			this.btnRef.Text = "Re";
			this.btnRef.UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(910, 489);
			this.Controls.Add(this.btnRef);
			this.Controls.Add(this.edInfo);
			this.Controls.Add(this.edProp);
			this.Controls.Add(this.statictext_AE4);
			this.Controls.Add(this.statictext_AE2);
			this.Controls.Add(this.statictext_AE3);
			this.Controls.Add(this.statictext_AE1);
			this.Controls.Add(this.btnDelExp);
			this.Controls.Add(this.btnGetExp);
			this.Controls.Add(this.stGetExp);
			this.Controls.Add(this.lstProp);
			this.Controls.Add(this.lstLayer);
			this.Controls.Add(this.btnGetProperty);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.edExp);
			this.Controls.Add(this.edTargetProperty);
			this.Name = "Form1";
			this.Text = "Expressionの編集　curry_eggsさんのエディタが完成するまで暫定版";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.edittext_AE edTargetProperty;
		private bryful.edittext_AE edExp;
		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.button_AE btnOK;
		private bryful.button_AE btnCancel;
		private bryful.listbox_AE lstProp;
		private bryful.dropdownlist_AE lstLayer;
		private bryful.button_AE btnGetProperty;
		private bryful.statictext_AE stGetExp;
		private bryful.button_AE btnGetExp;
		private bryful.button_AE btnDelExp;
		private bryful.statictext_AE statictext_AE3;
		private bryful.statictext_AE statictext_AE1;
		private bryful.statictext_AE statictext_AE2;
		private bryful.statictext_AE statictext_AE4;
		private bryful.edittext_AE edInfo;
		private bryful.edittext_AE edProp;
		private bryful.button_AE btnRef;
	}
}

