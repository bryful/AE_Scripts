﻿namespace js_CompNameReplace
{
	partial class main
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.btnGetName = new bryful.button_AE();
			this.edGetName = new bryful.edittext_AE();
			this.pnl = new bryful.panel_AE();
			this.tbDst = new bryful.edittext_AE();
			this.lbDst = new bryful.statictext_AE();
			this.tbSrc = new bryful.edittext_AE();
			this.lbSrc = new bryful.statictext_AE();
			this.btnOK = new bryful.button_AE();
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.pnl.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnGetName
			// 
			this.btnGetName.IsLocal = true;
			this.btnGetName.Location = new System.Drawing.Point(10, 10);
			this.btnGetName.Name = "btnGetName";
			this.btnGetName.Size = new System.Drawing.Size(49, 23);
			this.btnGetName.TabIndex = 0;
			this.btnGetName.Text = "Get";
			this.btnGetName.UseVisualStyleBackColor = true;
			// 
			// edGetName
			// 
			this.edGetName.IsLocal = true;
			this.edGetName.Location = new System.Drawing.Point(65, 12);
			this.edGetName.Name = "edGetName";
			this.edGetName.Size = new System.Drawing.Size(222, 19);
			this.edGetName.TabIndex = 1;
			// 
			// pnl
			// 
			this.pnl.Controls.Add(this.tbDst);
			this.pnl.Controls.Add(this.lbDst);
			this.pnl.Controls.Add(this.tbSrc);
			this.pnl.Controls.Add(this.lbSrc);
			this.pnl.IsLocal = true;
			this.pnl.Location = new System.Drawing.Point(10, 40);
			this.pnl.Name = "pnl";
			this.pnl.Size = new System.Drawing.Size(277, 96);
			this.pnl.TabIndex = 2;
			this.pnl.TabStop = false;
			this.pnl.Text = "コンポジション名の置換";
			// 
			// tbDst
			// 
			this.tbDst.IsLocal = true;
			this.tbDst.Location = new System.Drawing.Point(102, 57);
			this.tbDst.Name = "tbDst";
			this.tbDst.Size = new System.Drawing.Size(161, 19);
			this.tbDst.TabIndex = 3;
			// 
			// lbDst
			// 
			this.lbDst.IsLocal = true;
			this.lbDst.Location = new System.Drawing.Point(6, 60);
			this.lbDst.Name = "lbDst";
			this.lbDst.Size = new System.Drawing.Size(90, 12);
			this.lbDst.TabIndex = 2;
			this.lbDst.Text = "置換前の文字列";
			// 
			// tbSrc
			// 
			this.tbSrc.IsLocal = true;
			this.tbSrc.Location = new System.Drawing.Point(102, 27);
			this.tbSrc.Name = "tbSrc";
			this.tbSrc.Size = new System.Drawing.Size(161, 19);
			this.tbSrc.TabIndex = 1;
			// 
			// lbSrc
			// 
			this.lbSrc.IsLocal = true;
			this.lbSrc.Location = new System.Drawing.Point(6, 30);
			this.lbSrc.Name = "lbSrc";
			this.lbSrc.Size = new System.Drawing.Size(90, 12);
			this.lbSrc.TabIndex = 0;
			this.lbSrc.Text = "置換前の文字列";
			// 
			// btnOK
			// 
			this.btnOK.IsLocal = true;
			this.btnOK.Location = new System.Drawing.Point(198, 142);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 3;
			this.btnOK.Text = "実行";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(299, 174);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.pnl);
			this.Controls.Add(this.edGetName);
			this.Controls.Add(this.btnGetName);
			this.Name = "main";
			this.Text = "Form1";
			this.pnl.ResumeLayout(false);
			this.pnl.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.button_AE btnGetName;
		private bryful.edittext_AE edGetName;
		private bryful.panel_AE pnl;
		private bryful.edittext_AE tbDst;
		private bryful.statictext_AE lbDst;
		private bryful.edittext_AE tbSrc;
		private bryful.statictext_AE lbSrc;
		private bryful.button_AE btnOK;
		private bryful.AE_DialogsMain aE_DialogsMain1;
	}
}

