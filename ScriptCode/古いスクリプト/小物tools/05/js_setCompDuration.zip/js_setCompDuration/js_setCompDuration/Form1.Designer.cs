﻿namespace js_setCompDuration
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.pnl = new bryful.panel_AE();
			this.edFrameRate = new bryful.edittext_AE();
			this.stFrameRate = new bryful.statictext_AE();
			this.edKoma = new bryful.edittext_AE();
			this.stPluss = new bryful.statictext_AE();
			this.edSec = new bryful.edittext_AE();
			this.rbSecKoma = new bryful.radiobutton_AE();
			this.edFrame = new bryful.edittext_AE();
			this.rbFrame = new bryful.radiobutton_AE();
			this.btnOK = new bryful.button_AE();
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.srWarning = new bryful.statictext_AE();
			this.btnSetDuration = new bryful.button_AE();
			this.btnSetSize = new bryful.button_AE();
			this.btnSetAll = new bryful.button_AE();
			this.cbSec = new bryful.checkbox_AE();
			this.cbSize = new bryful.checkbox_AE();
			this.edWidth = new bryful.edittext_AE();
			this.stWidth = new bryful.statictext_AE();
			this.stHeight = new bryful.statictext_AE();
			this.edHeight = new bryful.edittext_AE();
			this.pnl.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnl
			// 
			this.pnl.Controls.Add(this.stHeight);
			this.pnl.Controls.Add(this.edHeight);
			this.pnl.Controls.Add(this.stWidth);
			this.pnl.Controls.Add(this.edWidth);
			this.pnl.Controls.Add(this.cbSize);
			this.pnl.Controls.Add(this.cbSec);
			this.pnl.Controls.Add(this.edFrameRate);
			this.pnl.Controls.Add(this.stFrameRate);
			this.pnl.Controls.Add(this.edKoma);
			this.pnl.Controls.Add(this.stPluss);
			this.pnl.Controls.Add(this.edSec);
			this.pnl.Controls.Add(this.rbSecKoma);
			this.pnl.Controls.Add(this.edFrame);
			this.pnl.Controls.Add(this.rbFrame);
			this.pnl.IsLocal = true;
			this.pnl.Location = new System.Drawing.Point(3, 99);
			this.pnl.Name = "pnl";
			this.pnl.Size = new System.Drawing.Size(268, 200);
			this.pnl.TabIndex = 6;
			this.pnl.TabStop = false;
			this.pnl.Text = "動作";
			// 
			// edFrameRate
			// 
			this.edFrameRate.IsLocal = true;
			this.edFrameRate.Location = new System.Drawing.Point(104, 97);
			this.edFrameRate.Name = "edFrameRate";
			this.edFrameRate.ReadOnly = true;
			this.edFrameRate.Size = new System.Drawing.Size(69, 19);
			this.edFrameRate.TabIndex = 8;
			// 
			// stFrameRate
			// 
			this.stFrameRate.AutoSize = true;
			this.stFrameRate.IsLocal = true;
			this.stFrameRate.Location = new System.Drawing.Point(37, 100);
			this.stFrameRate.Name = "stFrameRate";
			this.stFrameRate.Size = new System.Drawing.Size(61, 12);
			this.stFrameRate.TabIndex = 7;
			this.stFrameRate.Text = "FrameRate";
			// 
			// edKoma
			// 
			this.edKoma.IsLocal = true;
			this.edKoma.Location = new System.Drawing.Point(205, 65);
			this.edKoma.Name = "edKoma";
			this.edKoma.Size = new System.Drawing.Size(52, 19);
			this.edKoma.TabIndex = 6;
			// 
			// stPluss
			// 
			this.stPluss.AutoSize = true;
			this.stPluss.IsLocal = true;
			this.stPluss.Location = new System.Drawing.Point(190, 67);
			this.stPluss.Name = "stPluss";
			this.stPluss.Size = new System.Drawing.Size(17, 12);
			this.stPluss.TabIndex = 5;
			this.stPluss.Text = "＋";
			// 
			// edSec
			// 
			this.edSec.IsLocal = true;
			this.edSec.Location = new System.Drawing.Point(132, 63);
			this.edSec.Name = "edSec";
			this.edSec.Size = new System.Drawing.Size(52, 19);
			this.edSec.TabIndex = 4;
			// 
			// rbSecKoma
			// 
			this.rbSecKoma.AutoSize = true;
			this.rbSecKoma.Checked = true;
			this.rbSecKoma.IsLocal = true;
			this.rbSecKoma.Location = new System.Drawing.Point(37, 66);
			this.rbSecKoma.Name = "rbSecKoma";
			this.rbSecKoma.Size = new System.Drawing.Size(92, 16);
			this.rbSecKoma.TabIndex = 3;
			this.rbSecKoma.TabStop = true;
			this.rbSecKoma.Text = "秒+コマで指定";
			this.rbSecKoma.UseVisualStyleBackColor = true;
			// 
			// edFrame
			// 
			this.edFrame.IsLocal = true;
			this.edFrame.Location = new System.Drawing.Point(132, 35);
			this.edFrame.Name = "edFrame";
			this.edFrame.Size = new System.Drawing.Size(125, 19);
			this.edFrame.TabIndex = 2;
			// 
			// rbFrame
			// 
			this.rbFrame.AutoSize = true;
			this.rbFrame.IsLocal = true;
			this.rbFrame.Location = new System.Drawing.Point(37, 38);
			this.rbFrame.Name = "rbFrame";
			this.rbFrame.Size = new System.Drawing.Size(89, 16);
			this.rbFrame.TabIndex = 1;
			this.rbFrame.Text = "Frameで指定";
			this.rbFrame.UseVisualStyleBackColor = true;
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.IsLocal = true;
			this.btnOK.Location = new System.Drawing.Point(192, 331);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 8;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// srWarning
			// 
			this.srWarning.AutoSize = true;
			this.srWarning.IsLocal = true;
			this.srWarning.Location = new System.Drawing.Point(6, 307);
			this.srWarning.Name = "srWarning";
			this.srWarning.Size = new System.Drawing.Size(270, 12);
			this.srWarning.TabIndex = 7;
			this.srWarning.Text = "レイヤのin点/out点には何もしません。確認が必要です。";
			// 
			// btnSetDuration
			// 
			this.btnSetDuration.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnSetDuration.IsLocal = true;
			this.btnSetDuration.Location = new System.Drawing.Point(20, 12);
			this.btnSetDuration.Name = "btnSetDuration";
			this.btnSetDuration.Size = new System.Drawing.Size(230, 23);
			this.btnSetDuration.TabIndex = 3;
			this.btnSetDuration.Text = "秒数を獲得";
			this.btnSetDuration.UseVisualStyleBackColor = true;
			// 
			// btnSetSize
			// 
			this.btnSetSize.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnSetSize.IsLocal = true;
			this.btnSetSize.Location = new System.Drawing.Point(20, 41);
			this.btnSetSize.Name = "btnSetSize";
			this.btnSetSize.Size = new System.Drawing.Size(230, 23);
			this.btnSetSize.TabIndex = 4;
			this.btnSetSize.Text = "サイズを獲得";
			this.btnSetSize.UseVisualStyleBackColor = true;
			// 
			// btnSetAll
			// 
			this.btnSetAll.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnSetAll.IsLocal = true;
			this.btnSetAll.Location = new System.Drawing.Point(20, 70);
			this.btnSetAll.Name = "btnSetAll";
			this.btnSetAll.Size = new System.Drawing.Size(231, 23);
			this.btnSetAll.TabIndex = 5;
			this.btnSetAll.Text = "両方秒数サイズを獲得";
			this.btnSetAll.UseVisualStyleBackColor = true;
			// 
			// cbSec
			// 
			this.cbSec.AutoSize = true;
			this.cbSec.Checked = true;
			this.cbSec.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbSec.IsLocal = true;
			this.cbSec.Location = new System.Drawing.Point(13, 18);
			this.cbSec.Name = "cbSec";
			this.cbSec.Size = new System.Drawing.Size(100, 16);
			this.cbSec.TabIndex = 0;
			this.cbSec.Text = "秒数を設定する";
			this.cbSec.UseVisualStyleBackColor = true;
			// 
			// cbSize
			// 
			this.cbSize.AutoSize = true;
			this.cbSize.Checked = true;
			this.cbSize.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbSize.IsLocal = true;
			this.cbSize.Location = new System.Drawing.Point(8, 131);
			this.cbSize.Name = "cbSize";
			this.cbSize.Size = new System.Drawing.Size(105, 16);
			this.cbSize.TabIndex = 9;
			this.cbSize.Text = "サイズを設定する";
			this.cbSize.UseVisualStyleBackColor = true;
			// 
			// edWidth
			// 
			this.edWidth.IsLocal = true;
			this.edWidth.Location = new System.Drawing.Point(57, 153);
			this.edWidth.Name = "edWidth";
			this.edWidth.Size = new System.Drawing.Size(69, 19);
			this.edWidth.TabIndex = 11;
			// 
			// stWidth
			// 
			this.stWidth.AutoSize = true;
			this.stWidth.IsLocal = true;
			this.stWidth.Location = new System.Drawing.Point(22, 156);
			this.stWidth.Name = "stWidth";
			this.stWidth.Size = new System.Drawing.Size(33, 12);
			this.stWidth.TabIndex = 10;
			this.stWidth.Text = "Width";
			// 
			// stHeight
			// 
			this.stHeight.AutoSize = true;
			this.stHeight.IsLocal = true;
			this.stHeight.Location = new System.Drawing.Point(134, 156);
			this.stHeight.Name = "stHeight";
			this.stHeight.Size = new System.Drawing.Size(38, 12);
			this.stHeight.TabIndex = 12;
			this.stHeight.Text = "Height";
			// 
			// edHeight
			// 
			this.edHeight.IsLocal = true;
			this.edHeight.Location = new System.Drawing.Point(178, 153);
			this.edHeight.Name = "edHeight";
			this.edHeight.Size = new System.Drawing.Size(69, 19);
			this.edHeight.TabIndex = 13;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(283, 367);
			this.Controls.Add(this.btnSetAll);
			this.Controls.Add(this.btnSetSize);
			this.Controls.Add(this.btnSetDuration);
			this.Controls.Add(this.srWarning);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.pnl);
			this.Name = "Form1";
			this.Text = "選択したコンポの長さを一括設定";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.pnl.ResumeLayout(false);
			this.pnl.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.panel_AE pnl;
		private bryful.edittext_AE edKoma;
		private bryful.statictext_AE stPluss;
		private bryful.edittext_AE edSec;
		private bryful.radiobutton_AE rbSecKoma;
		private bryful.edittext_AE edFrame;
		private bryful.radiobutton_AE rbFrame;
		private bryful.button_AE btnOK;
		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.edittext_AE edFrameRate;
		private bryful.statictext_AE stFrameRate;
		private bryful.statictext_AE srWarning;
		private bryful.button_AE btnSetAll;
		private bryful.button_AE btnSetSize;
		private bryful.button_AE btnSetDuration;
		private bryful.checkbox_AE cbSize;
		private bryful.checkbox_AE cbSec;
		private bryful.statictext_AE stHeight;
		private bryful.edittext_AE edHeight;
		private bryful.statictext_AE stWidth;
		private bryful.edittext_AE edWidth;
	}
}

