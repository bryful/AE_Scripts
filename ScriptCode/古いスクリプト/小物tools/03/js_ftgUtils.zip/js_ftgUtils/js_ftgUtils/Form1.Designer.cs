﻿namespace js_ftgUtils
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.stAspect = new bryful.statictext_AE();
			this.getAspect = new bryful.button_AE();
			this.setAspect = new bryful.button_AE();
			this.setAlphaMode = new bryful.button_AE();
			this.getAlphaMode = new bryful.button_AE();
			this.stAlphaMode = new bryful.statictext_AE();
			this.lstAlphaMode = new bryful.dropdownlist_AE();
			this.setLoop = new bryful.button_AE();
			this.getLoop = new bryful.button_AE();
			this.stLoop = new bryful.statictext_AE();
			this.edLoop = new bryful.edittext_AE();
			this.edFrameRate = new bryful.edittext_AE();
			this.setFrameRate = new bryful.button_AE();
			this.getFrameRate = new bryful.button_AE();
			this.stFrameRate = new bryful.statictext_AE();
			this.setFieldSepa = new bryful.button_AE();
			this.getFieldSepa = new bryful.button_AE();
			this.stFieldSepa = new bryful.statictext_AE();
			this.lstFieldSape = new bryful.dropdownlist_AE();
			this.setPulldown = new bryful.button_AE();
			this.getPulldown = new bryful.button_AE();
			this.stPulldown = new bryful.statictext_AE();
			this.lstPulldown = new bryful.dropdownlist_AE();
			this.edAspect = new bryful.edittext_AE();
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.stMes = new bryful.statictext_AE();
			this.SuspendLayout();
			// 
			// stAspect
			// 
			this.stAspect.IsLocal = true;
			this.stAspect.Location = new System.Drawing.Point(7, 26);
			this.stAspect.Name = "stAspect";
			this.stAspect.Size = new System.Drawing.Size(170, 12);
			this.stAspect.TabIndex = 0;
			this.stAspect.Text = "ピクセルアスペクト";
			// 
			// getAspect
			// 
			this.getAspect.IsLocal = true;
			this.getAspect.Location = new System.Drawing.Point(9, 41);
			this.getAspect.Name = "getAspect";
			this.getAspect.Size = new System.Drawing.Size(37, 23);
			this.getAspect.TabIndex = 1;
			this.getAspect.Text = "Get";
			this.getAspect.UseVisualStyleBackColor = true;
			// 
			// setAspect
			// 
			this.setAspect.IsLocal = true;
			this.setAspect.Location = new System.Drawing.Point(146, 41);
			this.setAspect.Name = "setAspect";
			this.setAspect.Size = new System.Drawing.Size(37, 23);
			this.setAspect.TabIndex = 3;
			this.setAspect.Text = "Set";
			this.setAspect.UseVisualStyleBackColor = true;
			// 
			// setAlphaMode
			// 
			this.setAlphaMode.IsLocal = true;
			this.setAlphaMode.Location = new System.Drawing.Point(146, 163);
			this.setAlphaMode.Name = "setAlphaMode";
			this.setAlphaMode.Size = new System.Drawing.Size(37, 23);
			this.setAlphaMode.TabIndex = 15;
			this.setAlphaMode.Text = "Set";
			this.setAlphaMode.UseVisualStyleBackColor = true;
			// 
			// getAlphaMode
			// 
			this.getAlphaMode.IsLocal = true;
			this.getAlphaMode.Location = new System.Drawing.Point(9, 163);
			this.getAlphaMode.Name = "getAlphaMode";
			this.getAlphaMode.Size = new System.Drawing.Size(37, 23);
			this.getAlphaMode.TabIndex = 13;
			this.getAlphaMode.Text = "Get";
			this.getAlphaMode.UseVisualStyleBackColor = true;
			// 
			// stAlphaMode
			// 
			this.stAlphaMode.IsLocal = true;
			this.stAlphaMode.Location = new System.Drawing.Point(9, 148);
			this.stAlphaMode.Name = "stAlphaMode";
			this.stAlphaMode.Size = new System.Drawing.Size(170, 12);
			this.stAlphaMode.TabIndex = 12;
			this.stAlphaMode.Text = "フッテージ：αモード";
			// 
			// lstAlphaMode
			// 
			this.lstAlphaMode.FormattingEnabled = true;
			this.lstAlphaMode.Index = -1;
			this.lstAlphaMode.IsLocal = true;
			this.lstAlphaMode.Location = new System.Drawing.Point(51, 163);
			this.lstAlphaMode.Name = "lstAlphaMode";
			this.lstAlphaMode.Size = new System.Drawing.Size(88, 20);
			this.lstAlphaMode.TabIndex = 14;
			// 
			// setLoop
			// 
			this.setLoop.IsLocal = true;
			this.setLoop.Location = new System.Drawing.Point(146, 122);
			this.setLoop.Name = "setLoop";
			this.setLoop.Size = new System.Drawing.Size(37, 23);
			this.setLoop.TabIndex = 11;
			this.setLoop.Text = "Set";
			this.setLoop.UseVisualStyleBackColor = true;
			// 
			// getLoop
			// 
			this.getLoop.IsLocal = true;
			this.getLoop.Location = new System.Drawing.Point(9, 122);
			this.getLoop.Name = "getLoop";
			this.getLoop.Size = new System.Drawing.Size(37, 23);
			this.getLoop.TabIndex = 9;
			this.getLoop.Text = "Get";
			this.getLoop.UseVisualStyleBackColor = true;
			// 
			// stLoop
			// 
			this.stLoop.IsLocal = true;
			this.stLoop.Location = new System.Drawing.Point(9, 108);
			this.stLoop.Name = "stLoop";
			this.stLoop.Size = new System.Drawing.Size(170, 12);
			this.stLoop.TabIndex = 8;
			this.stLoop.Text = "フッテージ：ループ回数";
			// 
			// edLoop
			// 
			this.edLoop.IsLocal = true;
			this.edLoop.Location = new System.Drawing.Point(51, 123);
			this.edLoop.Name = "edLoop";
			this.edLoop.Size = new System.Drawing.Size(88, 19);
			this.edLoop.TabIndex = 10;
			// 
			// edFrameRate
			// 
			this.edFrameRate.IsLocal = true;
			this.edFrameRate.Location = new System.Drawing.Point(51, 84);
			this.edFrameRate.Name = "edFrameRate";
			this.edFrameRate.Size = new System.Drawing.Size(88, 19);
			this.edFrameRate.TabIndex = 6;
			// 
			// setFrameRate
			// 
			this.setFrameRate.IsLocal = true;
			this.setFrameRate.Location = new System.Drawing.Point(146, 82);
			this.setFrameRate.Name = "setFrameRate";
			this.setFrameRate.Size = new System.Drawing.Size(37, 23);
			this.setFrameRate.TabIndex = 7;
			this.setFrameRate.Text = "Set";
			this.setFrameRate.UseVisualStyleBackColor = true;
			// 
			// getFrameRate
			// 
			this.getFrameRate.IsLocal = true;
			this.getFrameRate.Location = new System.Drawing.Point(9, 82);
			this.getFrameRate.Name = "getFrameRate";
			this.getFrameRate.Size = new System.Drawing.Size(37, 23);
			this.getFrameRate.TabIndex = 5;
			this.getFrameRate.Text = "Get";
			this.getFrameRate.UseVisualStyleBackColor = true;
			// 
			// stFrameRate
			// 
			this.stFrameRate.IsLocal = true;
			this.stFrameRate.Location = new System.Drawing.Point(9, 67);
			this.stFrameRate.Name = "stFrameRate";
			this.stFrameRate.Size = new System.Drawing.Size(170, 12);
			this.stFrameRate.TabIndex = 4;
			this.stFrameRate.Text = "フレームレート";
			// 
			// setFieldSepa
			// 
			this.setFieldSepa.IsLocal = true;
			this.setFieldSepa.Location = new System.Drawing.Point(146, 202);
			this.setFieldSepa.Name = "setFieldSepa";
			this.setFieldSepa.Size = new System.Drawing.Size(37, 23);
			this.setFieldSepa.TabIndex = 19;
			this.setFieldSepa.Text = "Set";
			this.setFieldSepa.UseVisualStyleBackColor = true;
			// 
			// getFieldSepa
			// 
			this.getFieldSepa.IsLocal = true;
			this.getFieldSepa.Location = new System.Drawing.Point(9, 203);
			this.getFieldSepa.Name = "getFieldSepa";
			this.getFieldSepa.Size = new System.Drawing.Size(37, 23);
			this.getFieldSepa.TabIndex = 17;
			this.getFieldSepa.Text = "Get";
			this.getFieldSepa.UseVisualStyleBackColor = true;
			// 
			// stFieldSepa
			// 
			this.stFieldSepa.IsLocal = true;
			this.stFieldSepa.Location = new System.Drawing.Point(9, 189);
			this.stFieldSepa.Name = "stFieldSepa";
			this.stFieldSepa.Size = new System.Drawing.Size(170, 12);
			this.stFieldSepa.TabIndex = 16;
			this.stFieldSepa.Text = "フッテージ：フィールドを分割";
			// 
			// lstFieldSape
			// 
			this.lstFieldSape.FormattingEnabled = true;
			this.lstFieldSape.Index = -1;
			this.lstFieldSape.IsLocal = true;
			this.lstFieldSape.Location = new System.Drawing.Point(51, 204);
			this.lstFieldSape.Name = "lstFieldSape";
			this.lstFieldSape.Size = new System.Drawing.Size(88, 20);
			this.lstFieldSape.TabIndex = 18;
			// 
			// setPulldown
			// 
			this.setPulldown.IsLocal = true;
			this.setPulldown.Location = new System.Drawing.Point(146, 241);
			this.setPulldown.Name = "setPulldown";
			this.setPulldown.Size = new System.Drawing.Size(37, 23);
			this.setPulldown.TabIndex = 23;
			this.setPulldown.Text = "Set";
			this.setPulldown.UseVisualStyleBackColor = true;
			// 
			// getPulldown
			// 
			this.getPulldown.IsLocal = true;
			this.getPulldown.Location = new System.Drawing.Point(9, 241);
			this.getPulldown.Name = "getPulldown";
			this.getPulldown.Size = new System.Drawing.Size(37, 23);
			this.getPulldown.TabIndex = 21;
			this.getPulldown.Text = "Get";
			this.getPulldown.UseVisualStyleBackColor = true;
			// 
			// stPulldown
			// 
			this.stPulldown.IsLocal = true;
			this.stPulldown.Location = new System.Drawing.Point(7, 228);
			this.stPulldown.Name = "stPulldown";
			this.stPulldown.Size = new System.Drawing.Size(170, 12);
			this.stPulldown.TabIndex = 20;
			this.stPulldown.Text = "フッテージ：プルダウンを削除";
			// 
			// lstPulldown
			// 
			this.lstPulldown.FormattingEnabled = true;
			this.lstPulldown.Index = -1;
			this.lstPulldown.IsLocal = true;
			this.lstPulldown.Location = new System.Drawing.Point(51, 243);
			this.lstPulldown.Name = "lstPulldown";
			this.lstPulldown.Size = new System.Drawing.Size(88, 20);
			this.lstPulldown.TabIndex = 22;
			// 
			// edAspect
			// 
			this.edAspect.IsLocal = true;
			this.edAspect.Location = new System.Drawing.Point(51, 41);
			this.edAspect.Name = "edAspect";
			this.edAspect.Size = new System.Drawing.Size(88, 19);
			this.edAspect.TabIndex = 2;
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// stMes
			// 
			this.stMes.IsLocal = true;
			this.stMes.Location = new System.Drawing.Point(11, 5);
			this.stMes.Name = "stMes";
			this.stMes.Size = new System.Drawing.Size(164, 17);
			this.stMes.TabIndex = 24;
			this.stMes.Text = "Message";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(192, 277);
			this.Controls.Add(this.stMes);
			this.Controls.Add(this.edAspect);
			this.Controls.Add(this.setPulldown);
			this.Controls.Add(this.getPulldown);
			this.Controls.Add(this.stPulldown);
			this.Controls.Add(this.lstPulldown);
			this.Controls.Add(this.setFieldSepa);
			this.Controls.Add(this.getFieldSepa);
			this.Controls.Add(this.stFieldSepa);
			this.Controls.Add(this.lstFieldSape);
			this.Controls.Add(this.edFrameRate);
			this.Controls.Add(this.setFrameRate);
			this.Controls.Add(this.getFrameRate);
			this.Controls.Add(this.stFrameRate);
			this.Controls.Add(this.edLoop);
			this.Controls.Add(this.setLoop);
			this.Controls.Add(this.getLoop);
			this.Controls.Add(this.stLoop);
			this.Controls.Add(this.setAlphaMode);
			this.Controls.Add(this.getAlphaMode);
			this.Controls.Add(this.stAlphaMode);
			this.Controls.Add(this.lstAlphaMode);
			this.Controls.Add(this.setAspect);
			this.Controls.Add(this.getAspect);
			this.Controls.Add(this.stAspect);
			this.Name = "Form1";
			this.Text = "フッテージ管理";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.statictext_AE stAspect;
		private bryful.button_AE getAspect;
		private bryful.button_AE setAspect;
		private bryful.button_AE setAlphaMode;
		private bryful.button_AE getAlphaMode;
		private bryful.statictext_AE stAlphaMode;
		private bryful.dropdownlist_AE lstAlphaMode;
		private bryful.button_AE setLoop;
		private bryful.button_AE getLoop;
		private bryful.statictext_AE stLoop;
		private bryful.edittext_AE edLoop;
		private bryful.edittext_AE edFrameRate;
		private bryful.button_AE setFrameRate;
		private bryful.button_AE getFrameRate;
		private bryful.statictext_AE stFrameRate;
		private bryful.button_AE setFieldSepa;
		private bryful.button_AE getFieldSepa;
		private bryful.statictext_AE stFieldSepa;
		private bryful.dropdownlist_AE lstFieldSape;
		private bryful.button_AE setPulldown;
		private bryful.button_AE getPulldown;
		private bryful.statictext_AE stPulldown;
		private bryful.dropdownlist_AE lstPulldown;
		private bryful.edittext_AE edAspect;
		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.statictext_AE stMes;
	}
}

