﻿namespace js_compToDialog
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.btnCode = new bryful.button_AE();
			this.btnToImg = new bryful.button_AE();
			this.cbIsPalette = new bryful.checkbox_AE();
			this.SuspendLayout();
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// btnCode
			// 
			this.btnCode.IsLocal = true;
			this.btnCode.Location = new System.Drawing.Point(12, 12);
			this.btnCode.Name = "btnCode";
			this.btnCode.Size = new System.Drawing.Size(156, 28);
			this.btnCode.TabIndex = 0;
			this.btnCode.Text = "Javascript作成";
			this.btnCode.UseVisualStyleBackColor = true;
			// 
			// btnToImg
			// 
			this.btnToImg.IsLocal = true;
			this.btnToImg.Location = new System.Drawing.Point(12, 46);
			this.btnToImg.Name = "btnToImg";
			this.btnToImg.Size = new System.Drawing.Size(156, 28);
			this.btnToImg.TabIndex = 1;
			this.btnToImg.Text = "画像書き出しのComp作成";
			this.btnToImg.UseVisualStyleBackColor = true;
			// 
			// cbIsPalette
			// 
			this.cbIsPalette.AutoSize = true;
			this.cbIsPalette.IsLocal = true;
			this.cbIsPalette.Location = new System.Drawing.Point(12, 80);
			this.cbIsPalette.Name = "cbIsPalette";
			this.cbIsPalette.Size = new System.Drawing.Size(110, 16);
			this.cbIsPalette.TabIndex = 2;
			this.cbIsPalette.Text = "パレット形式にする";
			this.cbIsPalette.UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(186, 102);
			this.Controls.Add(this.cbIsPalette);
			this.Controls.Add(this.btnToImg);
			this.Controls.Add(this.btnCode);
			this.Name = "Form1";
			this.Text = "ダイアログへ変換";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.button_AE btnToImg;
		private bryful.button_AE btnCode;
		private bryful.checkbox_AE cbIsPalette;
	}
}

