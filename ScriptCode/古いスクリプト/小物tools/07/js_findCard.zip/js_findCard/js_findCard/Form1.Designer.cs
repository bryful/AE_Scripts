﻿namespace js_findCard
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.pnlDir = new bryful.panel_AE();
			this.statictext_AE6 = new bryful.statictext_AE();
			this.lstExt = new bryful.dropdownlist_AE();
			this.stInfo = new bryful.statictext_AE();
			this.btnReload = new bryful.button_AE();
			this.btnSetDir = new bryful.button_AE();
			this.stDir = new bryful.statictext_AE();
			this.edWord = new bryful.edittext_AE();
			this.btnFind = new bryful.button_AE();
			this.lbResult = new bryful.listbox_AE();
			this.lstHis = new bryful.dropdownlist_AE();
			this.statictext_AE2 = new bryful.statictext_AE();
			this.btnImport = new bryful.button_AE();
			this.btnClose = new bryful.button_AE();
			this.lstImport = new bryful.listbox_AE();
			this.btnAdd = new bryful.button_AE();
			this.statictext_AE3 = new bryful.statictext_AE();
			this.statictext_AE4 = new bryful.statictext_AE();
			this.statictext_AE5 = new bryful.statictext_AE();
			this.btnRemove = new bryful.button_AE();
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.cbChkDup = new bryful.checkbox_AE();
			this.pnlDir.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlDir
			// 
			this.pnlDir.Controls.Add(this.statictext_AE6);
			this.pnlDir.Controls.Add(this.lstExt);
			this.pnlDir.Controls.Add(this.stInfo);
			this.pnlDir.Controls.Add(this.btnReload);
			this.pnlDir.Controls.Add(this.btnSetDir);
			this.pnlDir.Controls.Add(this.stDir);
			this.pnlDir.IsLocal = true;
			this.pnlDir.Location = new System.Drawing.Point(12, 12);
			this.pnlDir.Name = "pnlDir";
			this.pnlDir.Size = new System.Drawing.Size(528, 80);
			this.pnlDir.TabIndex = 0;
			this.pnlDir.TabStop = false;
			this.pnlDir.Text = "検索対象フォルダ";
			// 
			// statictext_AE6
			// 
			this.statictext_AE6.IsLocal = true;
			this.statictext_AE6.Location = new System.Drawing.Point(87, 46);
			this.statictext_AE6.Name = "statictext_AE6";
			this.statictext_AE6.Size = new System.Drawing.Size(68, 18);
			this.statictext_AE6.TabIndex = 2;
			this.statictext_AE6.Text = "対象拡張子";
			// 
			// lstExt
			// 
			this.lstExt.FormattingEnabled = true;
			this.lstExt.Index = -1;
			this.lstExt.IsLocal = true;
			this.lstExt.Items.AddRange(new object[] {
            ".png",
            ".jpg",
            ".tga",
            ".psd",
            ".tif",
            ".pic",
            ".*"});
			this.lstExt.Location = new System.Drawing.Point(161, 41);
			this.lstExt.Name = "lstExt";
			this.lstExt.Size = new System.Drawing.Size(85, 20);
			this.lstExt.TabIndex = 3;
			// 
			// stInfo
			// 
			this.stInfo.IsLocal = true;
			this.stInfo.Location = new System.Drawing.Point(257, 44);
			this.stInfo.Name = "stInfo";
			this.stInfo.Size = new System.Drawing.Size(171, 18);
			this.stInfo.TabIndex = 4;
			this.stInfo.Text = "対象なし";
			// 
			// btnReload
			// 
			this.btnReload.IsLocal = true;
			this.btnReload.Location = new System.Drawing.Point(6, 41);
			this.btnReload.Name = "btnReload";
			this.btnReload.Size = new System.Drawing.Size(75, 23);
			this.btnReload.TabIndex = 1;
			this.btnReload.Text = "再読み込み";
			this.btnReload.UseVisualStyleBackColor = true;
			// 
			// btnSetDir
			// 
			this.btnSetDir.IsLocal = true;
			this.btnSetDir.Location = new System.Drawing.Point(447, 41);
			this.btnSetDir.Name = "btnSetDir";
			this.btnSetDir.Size = new System.Drawing.Size(75, 23);
			this.btnSetDir.TabIndex = 5;
			this.btnSetDir.Text = "設定";
			this.btnSetDir.UseVisualStyleBackColor = true;
			// 
			// stDir
			// 
			this.stDir.IsLocal = true;
			this.stDir.Location = new System.Drawing.Point(8, 19);
			this.stDir.Name = "stDir";
			this.stDir.Size = new System.Drawing.Size(503, 18);
			this.stDir.TabIndex = 0;
			this.stDir.Text = "statictext_AE1";
			// 
			// edWord
			// 
			this.edWord.IsLocal = true;
			this.edWord.Location = new System.Drawing.Point(14, 159);
			this.edWord.Name = "edWord";
			this.edWord.Size = new System.Drawing.Size(427, 19);
			this.edWord.TabIndex = 4;
			// 
			// btnFind
			// 
			this.btnFind.IsLocal = true;
			this.btnFind.Location = new System.Drawing.Point(447, 113);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(94, 69);
			this.btnFind.TabIndex = 5;
			this.btnFind.Text = "検索開始";
			this.btnFind.UseVisualStyleBackColor = true;
			// 
			// lbResult
			// 
			this.lbResult.FormattingEnabled = true;
			this.lbResult.IsLocal = true;
			this.lbResult.ItemHeight = 12;
			this.lbResult.Location = new System.Drawing.Point(12, 201);
			this.lbResult.Name = "lbResult";
			this.lbResult.Size = new System.Drawing.Size(528, 196);
			this.lbResult.TabIndex = 7;
			// 
			// lstHis
			// 
			this.lstHis.FormattingEnabled = true;
			this.lstHis.Index = -1;
			this.lstHis.IsLocal = true;
			this.lstHis.Location = new System.Drawing.Point(13, 113);
			this.lstHis.Name = "lstHis";
			this.lstHis.Size = new System.Drawing.Size(427, 20);
			this.lstHis.TabIndex = 2;
			// 
			// statictext_AE2
			// 
			this.statictext_AE2.AutoSize = true;
			this.statictext_AE2.IsLocal = true;
			this.statictext_AE2.Location = new System.Drawing.Point(12, 98);
			this.statictext_AE2.Name = "statictext_AE2";
			this.statictext_AE2.Size = new System.Drawing.Size(53, 12);
			this.statictext_AE2.TabIndex = 1;
			this.statictext_AE2.Text = "検索履歴";
			// 
			// btnImport
			// 
			this.btnImport.IsLocal = true;
			this.btnImport.Location = new System.Drawing.Point(447, 525);
			this.btnImport.Name = "btnImport";
			this.btnImport.Size = new System.Drawing.Size(88, 37);
			this.btnImport.TabIndex = 13;
			this.btnImport.Text = "取り込み";
			this.btnImport.UseVisualStyleBackColor = true;
			// 
			// btnClose
			// 
			this.btnClose.IsLocal = true;
			this.btnClose.Location = new System.Drawing.Point(353, 525);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(88, 37);
			this.btnClose.TabIndex = 12;
			this.btnClose.Text = "閉じる";
			this.btnClose.UseVisualStyleBackColor = true;
			// 
			// lstImport
			// 
			this.lstImport.FormattingEnabled = true;
			this.lstImport.IsLocal = true;
			this.lstImport.ItemHeight = 12;
			this.lstImport.Location = new System.Drawing.Point(13, 431);
			this.lstImport.Name = "lstImport";
			this.lstImport.Size = new System.Drawing.Size(528, 88);
			this.lstImport.TabIndex = 10;
			// 
			// btnAdd
			// 
			this.btnAdd.IsLocal = true;
			this.btnAdd.Location = new System.Drawing.Point(446, 403);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(88, 22);
			this.btnAdd.TabIndex = 9;
			this.btnAdd.Text = "追加";
			this.btnAdd.UseVisualStyleBackColor = true;
			// 
			// statictext_AE3
			// 
			this.statictext_AE3.AutoSize = true;
			this.statictext_AE3.IsLocal = true;
			this.statictext_AE3.Location = new System.Drawing.Point(12, 144);
			this.statictext_AE3.Name = "statictext_AE3";
			this.statictext_AE3.Size = new System.Drawing.Size(57, 12);
			this.statictext_AE3.TabIndex = 3;
			this.statictext_AE3.Text = "検索ワード";
			this.statictext_AE3.Click += new System.EventHandler(this.statictext_AE3_Click);
			// 
			// statictext_AE4
			// 
			this.statictext_AE4.AutoSize = true;
			this.statictext_AE4.IsLocal = true;
			this.statictext_AE4.Location = new System.Drawing.Point(12, 186);
			this.statictext_AE4.Name = "statictext_AE4";
			this.statictext_AE4.Size = new System.Drawing.Size(53, 12);
			this.statictext_AE4.TabIndex = 6;
			this.statictext_AE4.Text = "検索結果";
			// 
			// statictext_AE5
			// 
			this.statictext_AE5.AutoSize = true;
			this.statictext_AE5.IsLocal = true;
			this.statictext_AE5.Location = new System.Drawing.Point(18, 416);
			this.statictext_AE5.Name = "statictext_AE5";
			this.statictext_AE5.Size = new System.Drawing.Size(72, 12);
			this.statictext_AE5.TabIndex = 8;
			this.statictext_AE5.Text = "取り込みリスト";
			// 
			// btnRemove
			// 
			this.btnRemove.IsLocal = true;
			this.btnRemove.Location = new System.Drawing.Point(18, 525);
			this.btnRemove.Name = "btnRemove";
			this.btnRemove.Size = new System.Drawing.Size(88, 27);
			this.btnRemove.TabIndex = 11;
			this.btnRemove.Text = "削除";
			this.btnRemove.UseVisualStyleBackColor = true;
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// cbChkDup
			// 
			this.cbChkDup.AutoSize = true;
			this.cbChkDup.IsLocal = true;
			this.cbChkDup.Location = new System.Drawing.Point(335, 407);
			this.cbChkDup.Name = "cbChkDup";
			this.cbChkDup.Size = new System.Drawing.Size(105, 16);
			this.cbChkDup.TabIndex = 14;
			this.cbChkDup.Text = "重複登録を禁止";
			this.cbChkDup.UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(553, 568);
			this.Controls.Add(this.cbChkDup);
			this.Controls.Add(this.btnRemove);
			this.Controls.Add(this.statictext_AE5);
			this.Controls.Add(this.statictext_AE4);
			this.Controls.Add(this.statictext_AE3);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.lstImport);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnImport);
			this.Controls.Add(this.statictext_AE2);
			this.Controls.Add(this.lstHis);
			this.Controls.Add(this.lbResult);
			this.Controls.Add(this.btnFind);
			this.Controls.Add(this.edWord);
			this.Controls.Add(this.pnlDir);
			this.Name = "Form1";
			this.Text = "張り込み素材検索";
			this.pnlDir.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.panel_AE pnlDir;
		private bryful.button_AE btnReload;
		private bryful.button_AE btnSetDir;
		private bryful.statictext_AE stDir;
		private bryful.edittext_AE edWord;
		private bryful.button_AE btnFind;
		private bryful.listbox_AE lbResult;
		private bryful.dropdownlist_AE lstHis;
		private bryful.statictext_AE statictext_AE2;
		private bryful.button_AE btnImport;
		private bryful.button_AE btnClose;
		private bryful.listbox_AE lstImport;
		private bryful.button_AE btnAdd;
		private bryful.statictext_AE statictext_AE3;
		private bryful.statictext_AE statictext_AE4;
		private bryful.statictext_AE statictext_AE5;
		private bryful.button_AE btnRemove;
		private bryful.statictext_AE statictext_AE6;
		private bryful.dropdownlist_AE lstExt;
		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.statictext_AE stInfo;
		private bryful.checkbox_AE cbChkDup;
	}
}

