﻿//適当な文字列
var str = 
 "After Effects" + app.version +"\n"
+system.userName +" "+system.machineName +" ";

//引き渡す文字列を一時ファイルに保存
var fileName = "__temp__.tmp";
var text_file = new File(fileName);
text_file.open("w","TEXT","????");
text_file.writeln(str);
text_file.close();

var p = system.callSystem("AE_Clipboard.exe \"" +fileName+"\"");
//一時ファイルを消す
text_file.remove();

//返り値が一時ファイル名なら成功
if (p==fileName)
	alert("成功");

