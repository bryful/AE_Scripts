﻿//引数なしでクリップボードから文字列を獲得
var p = system.callSystem("AE_Clipboard.exe");
alert(p);

