﻿/*
	選択した静止画フッテージの拡張子がsrcExtなものを指定したフォルダ内にある
	dstExtのものと入れ替えるスクリプト。
	
	選択されたフッテージがフォルダの場合は、再帰して中にあるすべてのフッテージが
	対象になる。
	
	ダイアログとしてAE_SelectFolder.exeを使用。
*/
(function(){
	//必ず小文字で指定
	var	srcExt = ".psd";
	var	dstExt = ".pic";
	var targetFiles = new Array;
	
	//------------------------------------------------------------------------------
	function ExtractExt(s)
	{
		if (s=="") return "";
		var idx = s.lastIndexOf(".");
		if (idx==-1) return "";
		return s.substring(idx);
	}
	//------------------------------------------------------------------------------
	function ExtractFileName(s)
	{
		if (s=="") return "";
		var idx = s.lastIndexOf("\\");
		if ( idx==-1) s.lastIndexOf("/");
		if (idx==-1) return s;
		return s.substring(idx+1);
	}
	//------------------------------------------------------------------------------
	function ExtractFileNameWithoutExt(s)
	{
		if (s=="") return "";
		var n = ExtractFileName(s);
		if (n=="") return "";
		var idx = n.lastIndexOf(".");
		if (idx==-1) return n;
		return n.substring(0,idx);
	}

	//---------------------------------------------------------------------------
	//選択したフッテージにに何かする
	//---------------------------------------------------------------------------
	function repDir(tDir,tFtg)
	{
		var tagetName = File.decode(tFtg.file.name);
		var node = ExtractFileNameWithoutExt(tagetName);
		var f = new File (tDir + "/" + node + dstExt);
		if ( f.exists ==true){
			tFtg.replace(f);
			tFtg.name = node + dstExt;
		}
		
		return true;
	}
	//---------------------------------------------------------------------------
	function isTargetFile(fFtg)
	{
	
		if (fFtg == null) return false;
		if (fFtg instanceof FootageItem) {
			if (fFtg.file != null) {
				if (fFtg.mainSource.isStill == true) {
					var w = File.decode(fFtg.file.name);
					w = ExtractExt(w).toLowerCase();
					if ( w == srcExt) {
						return true;
					}
				}
			}
		}
		return false;
	}

	//---------------------------------------------------------------------------
	function listUpTarget(fld)
	{	
		if ( fld.numItems > 0){
			var newFldList = new Array;
			for (var i=1; i<=fld.numItems;i++){
				if (fld.items[i] instanceof FolderItem) {
					newFldList.push(fld.items[i]);
				}
				if (isTargetFile(fld.items[i])==true){
					targetFiles.push(fld.items[i]);
				}
			}
			
			//再帰で探す
			if (newFldList.length>0){
				for (var i=0; i<newFldList.length;i++){
					listUpTarget(newFldList[i]);
				}
			}
			
		}
		
	}
//---------------------------------------------------------------------------
	var selectedItems = app.project.selection;
	if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
		
		targetFiles = new Array;
		for (var i = 0; i < selectedItems.length; i++) {
			if (selectedItems[i] instanceof FootageItem) {
				if (isTargetFile(selectedItems[i])==true) {
					targetFiles.push(selectedItems[i]);
				}
			}else if (selectedItems[i] instanceof FolderItem){
				listUpTarget(selectedItems[i]);
			}
		}
		if (targetFiles.length>0) {
			//自前のダイアログを使用なければ、標準ダイアログを表示
			var ae_sf = new File("AE_SelectFolder.exe");
			if (ae_sf.exists ==true){
				var tDir = system.callSystem("AE_SelectFolder.exe");
			}else{
				var tDir = folderGetDialog(srcExt + "ファイルのあるフォルダを選んでください");
			}
			if (tDir != "") {
				app.beginUndoGroup( srcExt + "から"+dstExt+"へ置き換え");
				for (var i=0; i<targetFiles.length; i++) {
					repDir(tDir,targetFiles[i]);
				}
				app.endUndoGroup();
			}else{
				writeLn("Cancel");
			}
		}else{
			alert("有効なファイルが選択されていません");
		}
		
	}else{
		alert("ない");
	}
	//---------------------------------------------------------------------------
})();;
