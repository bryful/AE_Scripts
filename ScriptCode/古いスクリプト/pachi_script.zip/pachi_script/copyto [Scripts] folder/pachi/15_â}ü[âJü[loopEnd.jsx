﻿(function(){
	//---------------------------------------------------------------------------
	function setMarkerStr(tLayer, tComp)
	{
		var tm = tComp.time;
		var markerProperty = tLayer.property("Marker");
		var mv = new MarkerValue("loop end");
		markerProperty.setValueAtTime(tm , mv);
	
		return true;
	}
	//---------------------------------------------------------------------------
	var activeComp = app.project.activeItem;
	if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
		
		var selectedLayers = activeComp.selectedLayers;
	
		if ( (selectedLayers!=null)&&(selectedLayers.length>0) ){
			app.beginUndoGroup("マーカーloopStart");
			for (var i = 0; i < selectedLayers.length; i++) {
				if ( setMarkerStr(selectedLayers[i],activeComp)==false ){
					//エラー処理
				}else{
				}
			}
		app.endUndoGroup();
		}else{
			//エラー処理
		}
	}else{
		//エラー処理
	}
	//---------------------------------------------------------------------------

})();