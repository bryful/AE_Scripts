﻿//---------------------------------------------------------------------------
//静止画フッテージをコンポへ
/*
	静止画フッテージの名前から連番と判断されたものをまとめてコンポに登録する。
	コンポの長さは2コマ多く作る。addKomaで指定可能。
	
	ゲーム用はシークエンスフッテージが不可なので。
	後ろの空コマは、空セル対策。
*/
//---------------------------------------------------------------------------
(function(){
	var ftgList = new Array;
	var ftgNames = new Array;
	var splitFtg = new Array;

	var addKoma = 2; //空コマ用のフレーム数
	//------------------------------------------------------------------------------
	/*
		ファイルパスから拡張子を返す
	*/
	String.prototype.splitNames = function()
	{
		var o = new Object;
		o.name = "";
		o.frame = "";
		o.ext = "";
		var n = this;
		if (n=="") return o;
		var idx = n.lastIndexOf(".");
		if (idx==0) {
			o.ext = n;
			return o;
		} else if (idx > 0 ) {
			o.ext = n.substring(idx);
			n = n.substring(0,idx);
		}
		idx = -1;
		var len = n.length - 1;
		for (var i = len ; i>=0; i--) {
			var c = n[i];
			if ( (c<"0")||(c>"9") ){
				idx = i;
				break;
			}
		}
		if (idx==len) //数字が無い
		{
			o.name = n;
		}else if (idx == -1) //全部数字
		{
			o.frame = n;
		}else{
			o.name = n.substring(0,idx+1);
			o.frame = n.substring(idx+1);
		}
		return o;
	}

	//---------------------------------------------------------------------------
	function findName(start,name){
		var ret = -1;
		var cnt = ftgNames.length;
		if (cnt<=0) return ret;
		if ( (start<0)||( start>=cnt) ) return ret;
		
		for (var i = start; i<cnt;i++){
			if (ftgNames[i].name == name) {
				ret = i;
				break;
			}
		}
		return ret;
	}
	//---------------------------------------------------------------------------
	function maxFrame(a)
	{
		if (a == null) return -1;
		if (a.length<=0) return -1;
		var f = -1;
		for ( var i=0; i<a.length;i++){
			var o = a[i].name.splitNames();
			var ff = o.frame * 1;
			if (ff>f) f = ff;
		}
		return f;
	}
	//---------------------------------------------------------------------------
	function delLast(s)
	{
		if (s == null) return "";
		var cnt = s.length-1;
		if (cnt<0) return "";
		var idx = -1;
		for ( var i= cnt; i>=0;i--){
			if ( (s[i] != "-")&&(s[i] != "_")&&(s[i] != ".")&&(s[i] != " ")&&(s[i] != "　")){
				idx = i;
				break;
			}
		}
		if ( idx==cnt) {
			return s;
		}else if (idx==-1){
			return "";
		}else{
			return s.substring(0,idx+1);
		}
	}
	function delPicHead(s)
	{
		var idx = s.indexOf("PIC_");
		if (idx==0){
			s = s.substring(4);
		}
		return s;
	}
	//---------------------------------------------------------------------------
	function setupFootage()
	{
		ftgList.sort();
		var cnt = ftgList.length;
		ftgNames = new Array;
		for (var i=0; i<cnt; i++){
			ftgNames.push(ftgList[i].name.splitNames());
			ftgNames[i].flg = false;
			if (ftgNames[i].frame !="") ftgNames[i].flg = true;
		}
		var p=0;
		splitFtg = new Array;
		while(p<cnt){
			if (ftgNames[p].flg == true){
				var a = new Array;
				ftgNames[p].flg = false;
				a.push(ftgList[p]);
				var pp = p+1;
				while(pp<cnt){
					pp = findName(pp,ftgNames[p].name);
					if (pp<0) {
						break;
					}else{
						ftgNames[pp].flg = false;
						a.push(ftgList[pp]);
						pp++;
					}
				}
				splitFtg.push(a);
			}
			p++;
		}
		if (splitFtg.length>0){
			for (var i=0; i<splitFtg.length;i++){
				var b = splitFtg[i];
				if (b.length>1) {
					var f = maxFrame(b);
					var ff = (f+addKoma) / 30;
					var newName = delLast(b[0].name.splitNames().name);
					var fld = b[0].parentFolder.items.addFolder(delPicHead(newName));
					var fldP = fld.parentFolder;
					var cmp = fldP.items.addComp(newName, b[0].width, b[0].height, b[0].pixelAspect , ff, 30);
					cmp.duration = ff; // 再設定しないと長さがおかしくなる
					for ( var j=0; j<b.length;j++){
						var lyr = cmp.layers.add(b[j]);
						lyr.outPoint = 1/30;
						var frm = b[j].name.splitNames().frame * 1;
						lyr.inPoint = (frm - 1) /30;
						b[j].parentFolder = fld;
					}
				}
			}
		}
		return true;
	}
	//---------------------------------------------------------------------------
	
	var selectedItems = app.project.selection;
	if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
		
		ftgList = new Array;
		for (var i = 0; i < selectedItems.length; i++) {
			
			if (selectedItems[i] instanceof FootageItem) {
				if ( (selectedItems[i].mainSource.isStill == true)&&(selectedItems[i].file != null) ) {
					ftgList.push(selectedItems[i]);
				}
			}
		}
		if (ftgList.length>0) {
			app.beginUndoGroup("静止画フッテージをコンポへ");
			setupFootage();
			app.endUndoGroup();
		}
	}else{
		alert("選択されていない。");
	}
	//---------------------------------------------------------------------------
})();
