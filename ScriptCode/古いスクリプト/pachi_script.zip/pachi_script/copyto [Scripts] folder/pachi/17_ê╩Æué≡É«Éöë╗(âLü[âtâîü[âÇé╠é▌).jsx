﻿(function(){
	//選択したレイヤに何かする
	//---------------------------------------------------------------------------
	function posSeisuu(tComp,tLayer)
	{
		var p = tLayer.property("Position");
		//キーフレームがない
		if (p.numKeys<=0) {
			var pos = p.value;
			pos[0] = Math.round(pos[0]);
			pos[1] = Math.round(pos[1]);
			p.setValue(pos);
		}else{
			var skeys = p.selectedKeys;
			var f0;
			var f1;
			//選択されたキーがない。すべてのフレームで
			if ( (skeys==null)||(skeys.length<=0) ){
				f0 = 1;
				f1 = p.numKeys;
			}else{
				var f0 = skeys[0];
				var f1 = skeys[skeys.length-1];
				
			}
			for (var i= f0; i<=f1;i++){
				var pos = p.keyValue(i);
				pos[0] = Math.round(pos[0]);
				pos[1] = Math.round(pos[1]);
				p.setValueAtKey(i,pos);
			}
		}
	
		return true;
	}
	//---------------------------------------------------------------------------
	var activeComp = app.project.activeItem;
	if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
		
		var selectedLayers = activeComp.selectedLayers;
	
		if ( (selectedLayers!=null)&&(selectedLayers.length>0) ){
			app.beginUndoGroup("位置を整数化(キーフレームのみ)");
			for (var i = 0; i < selectedLayers.length; i++) {
				if ( posSeisuu(activeComp,selectedLayers[i])==false ){
					//エラー処理
				}else{
				}
			}
			app.endUndoGroup();
		}else{
			//エラー処理
		}
	}else{
		//エラー処理
	}
	//---------------------------------------------------------------------------
})();
