﻿(function(){
	var targetList = new Array;
	var tagretWidth = 0;
	var tagretHeight = 0;
	var scaleFit = 1;
	var frameRate = 30;
	//picファイルの横幅の限界は1024.縮小率を考えて、限界サイズを決定
	var targetMaxWidth = 1608;//Math.floor(1024 * 1012 / 640);

	//---------------------------------------------------------------------------
	function addEffect(tLayer,effectName)
	{
		var effect_str	= "エフェクト";
		var fxg = tLayer.property(effect_str);
		if (fxg.canAddProperty(effectName)) {
			return  fxg.addProperty(effectName);
		}
		return null;
	}
	//---------------------------------------------------------------------------
	function layerAddEffect(tLayer)
	{
		var fx=addEffect(tLayer,"カラーキー")
		if (fx!=null){
			fx.property("キーカラー").setValue([1,1,1,1]);
		}
		var fx=addEffect(tLayer,"OLM Smoother")
		if (fx!=null){
			//fx.property("Do Smooth Range").setValue(6);
		}
	
	}
	//---------------------------------------------------------------------------
	function ExtractFileNameWithoutExt(s)
	{
		if (s=="") return "";
		var idx = s.lastIndexOf(".");
		if (idx==-1) return s;
		return s.substring(0,idx);
	}
	//---------------------------------------------------------------------------
	//選択したコンポに何かする
	//---------------------------------------------------------------------------
	function resizeFootage(tFtg)
	{
		var w = Math.round(tFtg.width * scaleFit);
		var h = Math.round(tFtg.height * scaleFit);
		//var fld = tFtg.parentFolder.items.addFolder(ExtractFileNameWithoutExt(tFtg.name));
		var duration = 1 / frameRate;
		if (tFtg.mainSource.isStill==false){
			duration = tFtg.duration;
		}
		var cmp = tFtg.parentFolder.items.addComp(ExtractFileNameWithoutExt(tFtg.name), w, h, tFtg.pixelAspect , duration,frameRate);
		cmp.duration = tFtg.duration;
		var lyr = cmp.layers.add(tFtg);
		var s = [0,0];
		s[0] = 100 * scaleFit;
		s[1] = s[0];
		lyr.property("Scale").setValue(s);
		layerAddEffect(lyr);
		return true;
	}
	//---------------------------------------------------------------------------
	var selectedItems = app.project.selection;
	if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
		app.beginUndoGroup("リサイズコンポ");
		
		
		for (var i = 0; i < selectedItems.length; i++) {
			if ( (selectedItems[i] instanceof FootageItem)||(selectedItems[i] instanceof CompItem) ) {
				targetList.push(selectedItems[i]);
				if (tagretWidth<selectedItems[i].width) tagretWidth = selectedItems[i].width;
				if (tagretHeight<selectedItems[i].height) tagretHeight = selectedItems[i].height;
			}
		}
		if (targetList.length>0) {
			if (tagretWidth>targetMaxWidth) {
				scaleFit = targetMaxWidth / tagretWidth;
			}
			for (var i = 0; i < targetList.length; i++) {
				resizeFootage(targetList[i]);
			}
		}
		app.endUndoGroup();
	}else{
		//エラー処理
	}
//---------------------------------------------------------------------------
})();