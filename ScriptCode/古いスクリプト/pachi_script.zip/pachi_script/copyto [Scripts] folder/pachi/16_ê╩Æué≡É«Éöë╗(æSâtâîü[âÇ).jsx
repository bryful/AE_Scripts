﻿(function(){
	//---------------------------------------------------------------------------
	function posSeisuu(tComp,tLayer)
	{
		var p = tLayer.property("Position");
		//キーフレームがない
		if (p.numKeys<=0) {
			var pos = p.value;
			pos[0] = Math.round(pos[0]);
			pos[1] = Math.round(pos[1]);
			p.setValue(pos);
		}else{
			var skeys = p.selectedKeys;
			var f0;
			var f1;
			//選択されたキーがない。すべてのフレームで
			if ( (skeys==null)||(skeys.length<=0) ){
				f0 = p.keyTime(1) * tComp.frameRate;
				f1 = p.keyTime(p.numKeys) * tComp.frameRate;
			}else{
				var f0 = p.keyTime(skeys[0]) * tComp.frameRate;
				var f1 = p.keyTime(skeys[skeys.length-1]) * tComp.frameRate;
				
			}
			var nw = tComp.time;
			for (var i= f0; i<=f1;i++){
				tComp.time = i * tComp.frameDuration;
				var v = p.value;
				p.setValueAtTime(tComp.time,v);
			}
			if (p.numKeys>0){
				for (var i= 1; i<=p.numKeys;i++){
					var pos = p.keyValue(i);
					pos[0] = Math.round(pos[0]);
					pos[1] = Math.round(pos[1]);
					p.setValueAtKey(i,pos);
				}
				//同じキーは削除
				if (p.numKeys>3){
					var delA = new Array;
					for (var i= 2 ; i<p.numKeys;i++){
						var posA = p.keyValue(i-1);
						var posB = p.keyValue(i);
						var posC = p.keyValue(i+1);
						if ( (posA[0]==posB[0])&&(posA[1]==posB[1]) ) {
							if ( (posC[0]==posB[0])&&(posC[1]==posB[1]) ) {
								delA.push(i);
							}
						}
					}
					if (delA.length>0){
						for (var i= delA.length-1 ; i>=0;i--){
							p.removeKey(i);
						}
					}
				}
				
			}
			tComp.time = nw;
		}
	
		return true;
	}
	//---------------------------------------------------------------------------
	var activeComp = app.project.activeItem;
	if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
		
		var selectedLayers = activeComp.selectedLayers;
	
		if ( (selectedLayers!=null)&&(selectedLayers.length>0) ){
			app.beginUndoGroup("位置を整数化(全フレーム)");
			for (var i = 0; i < selectedLayers.length; i++) {
				if ( posSeisuu(activeComp,selectedLayers[i])==false ){
					//エラー処理
				}else{
				}
			}
		app.endUndoGroup();
			}else{
			//エラー処理
		}
	}else{
		//エラー処理
	}
	//---------------------------------------------------------------------------
})();
