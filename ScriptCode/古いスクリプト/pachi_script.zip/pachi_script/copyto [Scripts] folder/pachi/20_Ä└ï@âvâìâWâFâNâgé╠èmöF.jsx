﻿

//---------------------------------------------------------------------------
//フッテージとコンポののアスペクト比とフレームレートの確認
//違ってたら強制的に変更

//あと、背景色とコンポサイズ(奇数になっていないか)の確認も行う。これは警告のみ
//---------------------------------------------------------------------------
(function(){



	//以下の値に強制修正
	var targetAspect =1.0;
	var targetFrameRate =30;
	var finalCompName ="01_FIX";

	//背景色のデフォルト。輪郭線の色。この色より明るければ警告
	var targetBgcolor = [10/255,10/255,10/255];

	var errMes ="";
	var nameArray = new Array;
	//---------------------------------------------------------------------------
	function ExtractExt(s)
	{
		if (s=="") return "";
		var idx = s.lastIndexOf(".");
		if (idx==-1) return "";
		return s.substring(idx);
	}
	//---------------------------------------------------------------------------
	function targetInfo(t)
	{
		if (t == null) return "null";
		
		var rid = app.project .rootFolder.id;
		
		var s = t.name;
		var p = t.parentFolder;
		while(true){
			if (p.id == rid) break;
			s = p.name +"/" + s;
			p = p.parentFolder;
		}
		
		return s;
	}
	//---------------------------------------------------------------------------
	function buildDialog()
	{
		var err_dialog = null;
		err_dialog = new Window("dialog","エラーダイアログだ。");
		err_dialog.bounds = [0,0,600,700];
		err_dialog.center();
		//err_dialog.multiline = true;
		//err_dialog.readonly = true;
		var ed1 =	err_dialog.add("edittext", [ 5, 5, 595, 650], errMes,{multiline:true,readonly:true});
		var btn = err_dialog.add("button", [ 495, 660, 595, 680], "OK");
		btn.onClick = function(){ err_dialog.close();}
		err_dialog.show();
	}
	//---------------------------------------------------------------------------
	function nameStringChk(name)
	{
	//03_Fog _rep2
		if ( (name ==null)||(name=="") ) {
			return false;
		}
		var cnt = name.length;
		for (var i=0;i<cnt;i++){
			var c = name[i];
			if ( (c>="a")&&(c<="z") ){
			}else if ( (c>="A")&&(c<="Z") ){
			}else if ( (c>="0")&&(c<="9") ){
			}else if ( (c=="-")||(c=="_")||(c==".") ){
			}else{
				return false;
			}
		}
		return true;
	}
	//---------------------------------------------------------------------------
	function chkLayer(tLayer,tComp)
	{
		if ((tLayer == null)||(tComp==null)) return;
		
		
		if ( tLayer.enabled == false ){
			errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」不可視状態になっています。\n";
		}
		
		if ( (tLayer.blendingMode == BlendingMode.NORMAL )||(tLayer.blendingMode == BlendingMode.MULTIPLY )||(tLayer.blendingMode == BlendingMode.ADD ) ){
		}else{
			errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」レイヤの合成モードが異常です。\n";
		}
		
		if ( (tLayer.blendingMode == BlendingMode.MULTIPLY )||(tLayer.blendingMode == BlendingMode.ADD ) ){
			if (tLayer.source instanceof FootageItem){
				if (tLayer.source.mainSource.hasAlpha == true) {
					errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」レイヤの元ファイルが乗算加算なのにアルファー付きです。\n";
				}
			}
		}
		if (tLayer.blendingMode == BlendingMode.MULTIPLY ){
			var op = tLayer.property("Opacity");
			if (op.numKeys >0) {
				errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」レイヤは乗算なのにキーフレームがあります。\n";
			}else if (op.value <100){
				errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」レイヤは乗算なのに不透明度が100%でない。\n";
			}

		}
		if (nameStringChk(tLayer.name)==false){
			errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」レイヤ名が不正です。スペースが入ってる可能性があります\n";
		}
		if (tLayer.timeRemapEnabled == true){
			var remap = tLayer.timeRemap;
			var cnt = remap.numKeys;
			if (cnt==0) {
			}else if (cnt==1) {
				errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」リマップキーは必ず２個以上指定。\n";
			}else{
				var rF = true;
				for (var i=1 ; i<=cnt; i++){
					var tm = (remap.keyValue(i)) *30;
					var v = Math.abs(tm - Math.round(tm));
					if (  v >0.00001) {
						rF = false;
						break;
					}
				}
				if (rF==false){
				
				errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」リマップキーが不正です。もしかしたら実機で不具合が起きるかもしれません。\n";
				}
			}
			
		}
		var fx =  tLayer.property("エフェクト");
		if (fx!=null) {
			if (fx.numProperties>0) {
				errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」でエフェクトプラグインが使用されています。\n";
			}
		}
		/*
		if ( (tLayer.inPoint!=0)||(tLayer.startTime!=0) ){
				errMes += "コンポ ["+ targetInfo(tComp)+"] の「"+tLayer.name+"」のイン点がおかしいです\n";
		}
		*/
	}
	//---------------------------------------------------------------------------
	function foo(tItem)
	{
		if ( nameStringChk(tItem.name) == false) {
			errMes += "["+ targetInfo(tItem)+"] は不正な名前です。\n";
		}
		if ( tItem instanceof FootageItem ) {
			//平面は使えない。
			if (tItem.file == null) {
				errMes += "平面 ["+ targetInfo(tItem)+"] があります。\n";
			}else{
				var cap = tItem.name;
				var org =  File.decode(tItem.file.name);
				if (cap != org) {
					errMes += "フッテージ ["+ targetInfo(tItem)+"] の名前が実際のファイルと違います。\n";
				}
				if (tItem.mainSource.isStill == false) {
					errMes += "フッテージ ["+ targetInfo(tItem)+"] の連番です。連番は使えません。\n";
				}
				var ext = ExtractExt(org).toUpperCase();
				if (ext != ".PIC") {
					errMes += "フッテージ ["+ targetInfo(tItem)+"] がpicファイルではありません。\n";
				}
				var head = org.substring(0,4);
				if (head != "PIC_") {
					errMes += "フッテージ ["+ targetInfo(tItem)+"] がファイル名の先頭がPIC_ではありません。\n";
				}
				
			}
			//アスペクトの確認
			if ( tItem.pixelAspect !=targetAspect) {
				errMes += "フッテージ ["+ targetInfo(tItem)+"] のアスペクト比が異常です。\n";
			}
			//フレームレートの確認
			if (tItem.mainSource.isStill == false) {
				if (tItem.frameRate != targetFrameRate) {
					errMes += "フッテージ ["+targetInfo(tItem)+"] のフレームレートが異常です。\n";
				}
			}
			if (tItem.usedIn.length <=0) {
				errMes += "フッテージ ["+targetInfo(tItem)+"] は使用されていません。\n";
			}
			var w = (tItem.width % 2);
			var h = (tItem.height % 2);
			if ( (w>0)||(h>0) ){
				errMes += "\nフッテージ ["+targetInfo(tItem)+"] のフレームサイズが奇数になっています。\n";
			}
		}
		if (tItem instanceof CompItem) {
			if ( tItem.pixelAspect !=targetAspect) {
				errMes += "コンポ ["+targetInfo(tItem)+"] のアスペクト比が異常です。\n";
			}
			if (tItem.frameRate != targetFrameRate) {
				errMes += "コンポ ["+targetInfo(tItem)+"] のフレームレートを異常です。\n";
			}
			var w = (tItem.width % 2);
			var h = (tItem.height % 2);
			if ( (w>0)||(h>0) ){
				errMes += "コンポ ["+targetInfo(tItem)+"] のフレームサイズが奇数になっています。\n";
			}
			if ( (tItem.usedIn.length <=0)&&(tItem.name != finalCompName)) {
				errMes += "コンポ ["+targetInfo(tItem)+"] は使用されていません。\n";
			}
			if (tItem.numLayers <=0) {
				errMes += "コンポ ["+targetInfo(tItem)+"] には、何も登録されていません。\n";
			}else{
				for (var i=1; i<=tItem.numLayers;i++){
					chkLayer(tItem.layer(i),tItem);
				}
			}
			if ( (tItem.workAreaStart != 0)||(tItem.workAreaDuration != tItem.duration) ){
				errMes += "コンポ ["+targetInfo(tItem)+"] のワークエリアが不正です。\n";
			}
		}
		return true;
	}
	//---------------------------------------------------------------------------
	function findNameArray(idx,name){
		
		if (nameArray ==null) return -1;
		var cnt = nameArray.length;
		if (cnt<=0) return -1;
		if (idx>=cnt) return -1;
		var target = name.toUpperCase();
		for (var i=idx; i<cnt;i++){
			var w = nameArray[i].toUpperCase();
			if (target == w) {
				return i;
			}
		}
		return -1;
	}
	//---------------------------------------------------------------------------
	function nameArrayChk()
	{
		if ((nameArray ==null)||(nameArray.length<=1) ){
			errMes += "アイテムがありません。\n";
			return;
		}
		nameArray.sort();
		var cnt = nameArray.length -1;
		for (var i=0; i<cnt;i++){
			var w = findNameArray(i+1,nameArray[i]);
			if ( w>0){
				errMes += "["+ nameArray[i] + "] という名前のアイテムが重複しています\n";
			}
		}
	}
	//---------------------------------------------------------------------------
	var item = app.project.items;
	if ( (item!=null)&&(item.length>0) ) {
		errMes ="";
		app.beginUndoGroup("実機プロジェクトチェック");
		nameArray = new Array;
		for (var i = 1; i <= item.length; i++) {
			nameArray.push(item[i].name);
			foo(item[i]);
		}
		nameArrayChk();
		app.endUndoGroup();
		if (errMes==""){
			alert("異常なし");
		}else{
			errMes +="\n\n以上の項目がすべてなくなるまで確認してください。\n";
			buildDialog();
		}
	}else{
		alert("ない")
	}
//---------------------------------------------------------------------------
})();
