﻿//---------------------------------------------------------------------------
//フッテージのアスペクト比とフレームレートの確認
//違ってたら強制的に変更
//---------------------------------------------------------------------------
(function(){
	//以下の値に強制修正
	var targetAspect =1.0;
	var targetFrameRate =30;

	var errMes ="";
	//---------------------------------------------------------------------------
	function targetInfo(t)
	{
		if (t == null) return "null";
		
		var rid = app.project .rootFolder.id;
		
		var s = t.name;
		var p = t.parentFolder;
		while(true){
			if (p.id == rid) break;
			s = p.name +"/" + s;
			p = p.parentFolder;
		}
		
		return s;
	}
	//---------------------------------------------------------------------------
	function buildDialog()
	{
		var err_dialog = null;
		err_dialog = new Window("dialog","エラーダイアログだ。");
		err_dialog.bounds = [0,0,600,700];
		err_dialog.center();
		//err_dialog.multiline = true;
		//err_dialog.readonly = true;
		var ed1 =	err_dialog.add("edittext", [ 5, 5, 595, 650], errMes,{multiline:true,readonly:true});
		var btn = err_dialog.add("button", [ 495, 660, 595, 680], "OK");
		btn.onClick = function(){ err_dialog.close();}
		err_dialog.show();
	}
	function foo(tItem)
	{
		if ( tItem instanceof FootageItem ) {
			if (tItem.file == null) return true;
			if ( tItem.pixelAspect !=targetAspect) {
				tItem.pixelAspect = targetAspect;
				errMes += "フッテージ ["+ targetInfo(tItem)+"] のアスペクト比を調整した。\n";
			}
			if (tItem.mainSource.isStill == false) {
				if (tItem.frameRate != targetFrameRate) {
					tItem.mainSource.conformFrameRate = targetFrameRate;
					
					errMes += "フッテージ ["+targetInfo(tItem)+"] のフレームレートを調整した。\n";
				}
			}
		}
		return true;
	}
	//---------------------------------------------------------------------------
	var item = app.project.items;
	if ( (item!=null)&&(item.length>0) ) {
		errMes ="";
		app.beginUndoGroup("フッテージチェック");
		for (var i = 1; i <= item.length; i++) {
			foo(item[i]);
		}
		app.endUndoGroup();
		if (errMes==""){
			alert("異常なし");
		}else{
			buildDialog();
		}
	}else{
		alert("ない")
	}
//---------------------------------------------------------------------------
})();
