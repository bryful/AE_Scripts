﻿//---------------------------------------------------------------------------
//フッテージのアスペクト比とフレームレートの確認
//違ってたら強制的に変更
//---------------------------------------------------------------------------
(function(){
	//以下の値に強制修正

	var errMes ="";
	//---------------------------------------------------------------------------
	function targetInfo(t)
	{
		if (t == null) return "null";
		
		var rid = app.project .rootFolder.id;
		
		var s = t.name;
		var p = t.parentFolder;
		while(true){
			if (p.id == rid) break;
			s = p.name +"/" + s;
			p = p.parentFolder;
		}
		
		return s;
	}
	//---------------------------------------------------------------------------
	function buildDialog()
	{
		var err_dialog = null;
		err_dialog = new Window("dialog","確認だだ。");
		err_dialog.bounds = [0,0,600,700];
		err_dialog.center();
		//err_dialog.multiline = true;
		//err_dialog.readonly = true;
		var ed1 =	err_dialog.add("edittext", [ 5, 5, 595, 650], errMes,{multiline:true,readonly:true});
		var btn = err_dialog.add("button", [ 495, 660, 595, 680], "OK");
		btn.onClick = function(){ err_dialog.close();}
		err_dialog.show();
	}
	function foo(tItem)
	{
		if ( tItem instanceof FootageItem ) {
			if (tItem.file == null) return true;
			var m ="";
			switch (tItem.mainSource.alphaMode)
			{
				case AlphaMode.IGNORE:
					m = "無視";
					break;
				case AlphaMode.STRAIGHT:
					m = "ストレート（マットなし)";
					break;
				case AlphaMode.PREMULTIPLIED:
					m = "合成チャンネル（カラーマット)";
					break;
			}
			errMes += m +"\t"+ targetInfo(tItem) +"\n";
		}
		return true;
	}
	//---------------------------------------------------------------------------
	var item = app.project.items;
	if ( (item!=null)&&(item.length>0) ) {
		errMes ="";
		for (var i = 1; i <= item.length; i++) {
			foo(item[i]);
		}
		if (errMes==""){
			alert("異常なし");
		}else{
			buildDialog();
		}
	}else{
		alert("ない")
	}
//---------------------------------------------------------------------------
})();
