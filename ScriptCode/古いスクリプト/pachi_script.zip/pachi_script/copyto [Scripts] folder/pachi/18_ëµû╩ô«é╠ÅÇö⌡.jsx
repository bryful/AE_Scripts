﻿/*
	ゲーム用では、プラグインもエクスプレッションも使用不可なので、
	このスクリプトで画面動を設定する雛形を作る。
	
	画面動が決まったら、「画面動のキーを作成」スクリプトで
	キーフレームに直す。


	ターゲットとなるレイヤを選択してから実行。
	複数のレイヤに同じ数値の画面動を設定できる。
	
	
*/

(function(){
	var expStr = 
	"p =  effect(\"移動量\").param(\"ポイント\");\n"+
	"len = effect(\"大きさ(px)\").param(\"スライダ\");\n"+
	"if ( len<0) len = 0;\n"+
	"rot = (effect(\"方向(r)\").param(\"角度\"));\n"+
	"rnd = effect(\"ランダム(%)\").param(\"スライダ\");\n"+
	"rndR = effect(\"方向のランダム(%)\").param(\"スライダ\");\n"+
	"decF =  effect(\"整数値にする\").param(\"チェックボックス\");\n"+
	"if (rnd<=0){rnd = 0;}else if(rnd>=100){rnd=100;}\n"+
	"lenR = random(len * (100-rnd)/100,len);\n"+
	"rot = rot + random(-rndR,rndR);\n"+
	"if (lenR>0){\n"+
	"frm=timeToFrames(t = time + thisComp.displayStartTime, fps = 1.0 / thisComp.frameDuration, isDuration = false);\n"+
	"if ((frm%2)==1) rot +=180;rot %= 360; if (rot<0) rot += 360;\n"+
	"if ( (rot>=0)&&(rot<90) ) {\n"+
	"dx =Math.sin((Math.PI /180)*rot)*lenR;\n"+
	"dy =Math.cos((Math.PI /180)*rot)*lenR*-1;\n"+
	"}else if ( (rot>=90)&&(rot<180) ) {\n"+
	"dx =Math.cos((Math.PI /180)*(rot-90))*lenR;\n"+
	"dy =Math.sin((Math.PI /180)*(rot-90))*lenR;\n"+
	"}else if ( (rot>=180)&&(rot<270) ) {\n"+
	"dx =Math.sin((Math.PI /180)*(rot-180))*lenR *-1;\n"+
	"dy =Math.cos((Math.PI /180)*(rot-180))*lenR;\n"+
	"}else if ( (rot>=270)&&(rot<360) ) {\n"+
	"dx =Math.cos((Math.PI /180)*(rot-270))*lenR*-1;\n"+
	"dy =Math.sin((Math.PI /180)*(rot-270))*lenR*-1;\n"+
	"}\n"+
	"X=p[0];\n"+
	"Y=p[1];\n"+
	"x=X+dx;\n"+
	"y=Y+dy;\n"+
	"if (decF==true){\n"+
	"x = Math.round(x);\n"+
	"y = Math.round(y);\n"+
	"}\n"+
	"[x,y];\n"+
	"}else{p;}\n";

	//---------------------------------------------------------------------------
	function addEffect(tLayer,effectName)
	{
		var effect_str	= "エフェクト";
		var fxg = tLayer.property(effect_str);
		if (fxg.canAddProperty(effectName)) {
			return  fxg.addProperty(effectName);
		}
		return null;
	}
	//---------------------------------------------------------------------------
	function setupScreenshake(tComp,lyrs)
	{
		var l =  tComp.layers.addText("画面動パラメータ");
		l.guideLayer = true;
		l.property("Opacity").setValue(0);
		l.comment ="画面動パラメータ";
		var markerProperty = l.property("Marker");
		var mv = new MarkerValue("画面動画が決まったら、「画面動のキーを作成」でキーを作成してこのレイヤーは削除してください。");
		markerProperty.setValueAtTime(0 , mv);

		var fx0 = addEffect(l,"スライダ制御");
		fx0.property("スライダ").setValue(10);
		fx0.name = "大きさ(px)";
		
		var fx1 = addEffect(l,"角度制御");
		fx1.property("角度").setValue(25.0);
		fx1.name = "方向(r)";
		
		var fx2 = addEffect(l,"スライダ制御");
		fx2.property("スライダ").setValue(25);
		fx2.name = "ランダム(%)";
		
		var fx3 = addEffect(l,"スライダ制御");
		fx3.property("スライダ").setValue(25);
		fx3.name = "方向のランダム(%)";
		
		var fx4 = addEffect(l,"チェックボックス制御");
		fx4.property("チェックボックス").setValue(true);
		fx4.name = "整数値にする";
		
		var fx5 = addEffect(l,"ポイント制御");
		fx5.name = "移動量";
		fx5.property("ポイント").setValue([0,0]);
		fx5.property("ポイント").expression = expStr;
		
		for (var i=0; i<lyrs.length;i++){
			lyrs[i].property("position").expression = 
			"p=thisComp.layer(\"画面動パラメータ\").effect(\"移動量\")(\"ポイント\");\n[position[0]+p[0],position[1]+p[1]];";
		}
	}
	//---------------------------------------------------------------------------
	var activeComp = app.project.activeItem;
	if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
		var	selectedLayers = activeComp.selectedLayers;
		if (selectedLayers.length>0){
			app.beginUndoGroup("画面動の準備");
			setupScreenshake(activeComp,selectedLayers);
			app.endUndoGroup();
		}else{
			alert("画面動を適応したいレイヤを選択してください。");
		}
	}else{
		alert("コンポジションをアクティブにしてください。");
	}
	//---------------------------------------------------------------------------
})();
