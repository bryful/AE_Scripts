﻿//---------------------------------------------------------------------------
/*
	選択したアイテムを獲得するクラス
	フォルダならば再帰して中身をリストアップする
*/
//---------------------------------------------------------------------------
function getSelectedItems()
{
	this.footageList = new Array;
	this.compList = new Array;
	this.folderList = new Array;
	
	//--------------------------------------------
	this.getFootage = function(target)
	{
		if (target == null) return;
		if (target instanceof FolderItem) {
			this.folderList.push(target);
			if ( target.numItems<=0) return;
			var cnt = target.numItems;
			for (var i=1; i<=cnt; i++){
				this.getFootage(target.item(i));
			}
		}else{
			if (target instanceof CompItem){
				this.compList.push(target);
			}else {
				this.footageList.push(target);
			}
		}
	}
	//--------------------------------------------
	this.selectedListup = function()
	{
		var selectedItems = app.project.selection;
		if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
			for (var i = 0; i < selectedItems.length; i++) {
				this.getFootage(selectedItems[i]);
			}
		}
	}
	//--------------------------------------------
	this.selectedListup();
}
//---------------------------------------------------------------------------
var si = new getSelectedItems;
if (si.footageList.length>0) {
	var cnt =0;
	//var mode = AlphaMode.PREMULTIPLIED;
	var mode = AlphaMode.STRAIGHT;
	//var mode = AlphaMode.IGNORE;
	
	for (var i=0; i<si.footageList.length;i++)
	{
		if (si.footageList[i].mainSource != "[object SolidSource]") {
			if (si.footageList[i].mainSource.hasAlpha==true){
				if (si.footageList[i].mainSource.alphaMode !=mode){
					si.footageList[i].mainSource.alphaMode = mode;
					cnt++;
				}
			}
		}
	}
	writeLn(cnt +"個のフッテージをマットなし合成に変更しました。\n")
}
