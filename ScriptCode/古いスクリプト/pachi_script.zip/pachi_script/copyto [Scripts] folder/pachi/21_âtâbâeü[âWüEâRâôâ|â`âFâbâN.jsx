﻿

//---------------------------------------------------------------------------
//フッテージとコンポののアスペクト比とフレームレートの確認
//違ってたら強制的に変更

//あと、背景色とコンポサイズ(奇数になっていないか)の確認も行う。これは警告のみ
//---------------------------------------------------------------------------
(function(){



	//以下の値に強制修正
	var targetAspect =1.0;
	var targetFrameRate =30;

	//背景色のデフォルト。輪郭線の色。この色より明るければ警告
	var targetBgcolor = [10/255,10/255,10/255];

	var errMes ="";
	//---------------------------------------------------------------------------
	function targetInfo(t)
	{
		if (t == null) return "null";
		
		var rid = app.project .rootFolder.id;
		
		var s = t.name;
		var p = t.parentFolder;
		while(true){
			if (p.id == rid) break;
			s = p.name +"/" + s;
			p = p.parentFolder;
		}
		
		return s;
	}
	//---------------------------------------------------------------------------
	function buildDialog()
	{
		var err_dialog = null;
		err_dialog = new Window("dialog","エラーダイアログだ。");
		err_dialog.bounds = [0,0,600,700];
		err_dialog.center();
		//err_dialog.multiline = true;
		//err_dialog.readonly = true;
		var ed1 =	err_dialog.add("edittext", [ 5, 5, 595, 650], errMes,{multiline:true,readonly:true});
		var btn = err_dialog.add("button", [ 495, 660, 595, 680], "OK");
		btn.onClick = function(){ err_dialog.close();}
		err_dialog.show();
	}
	//---------------------------------------------------------------------------
	function foo(tItem)
	{
		if ( tItem instanceof FootageItem ) {
			if (tItem.file == null) return true;
			if ( tItem.pixelAspect !=targetAspect) {
				tItem.pixelAspect = targetAspect;
				errMes += "フッテージ ["+ targetInfo(tItem)+"] のアスペクト比を調整した。\n";
			}
			if (tItem.mainSource.isStill == false) {
				if (tItem.frameRate != targetFrameRate) {
					tItem.mainSource.conformFrameRate = targetFrameRate;
					
					errMes += "フッテージ ["+targetInfo(tItem)+"] のフレームレートを調整した。\n";
				}
			}
		}
		if (tItem instanceof CompItem) {
			if ( tItem.pixelAspect !=targetAspect) {
				tItem.pixelAspect = targetAspect;
				errMes += "コンポ ["+targetInfo(tItem)+"] のアスペクト比を調整した。\n";
			}
			if (tItem.frameRate != targetFrameRate) {
				tItem.frameRate = targetFrameRate;
				errMes += "コンポ ["+targetInfo(tItem)+"] のフレームレートを調整した。\n";
			}
			var col = tItem.bgColor;
			if ( (col[0]>targetBgcolor[0])||(col[1]>targetBgcolor[1])||(col[2]>targetBgcolor[2]) ){
				var s = "[" + col[0]*255 +","+ col[1]*255 +","+ col[2]*255 +"]"; 
				errMes += "\n確認!!***  コンポ ["+targetInfo(tItem)+"] の背景色が黒でない " +s+"\n"
					+"ハイライト等の特別の素材でなければ要修正！\n\n";
			}
			
			var w = (tItem.width % 2);
			var h = (tItem.height % 2);
			if ( (w>0)||(h>0) ){
				errMes += "\n警告!!***  コンポ ["+targetInfo(tItem)+"] のフレームサイズが奇数になっています。要修正！*******\n\n";
			}
		}
		return true;
	}
	//---------------------------------------------------------------------------
	var item = app.project.items;
	if ( (item!=null)&&(item.length>0) ) {
		errMes ="";
		app.beginUndoGroup("プロジェクトチェック");
		for (var i = 1; i <= item.length; i++) {
			foo(item[i]);
		}
		app.endUndoGroup();
		if (errMes==""){
			alert("異常なし");
		}else{
			buildDialog();
		}
	}else{
		alert("ない")
	}
//---------------------------------------------------------------------------
})();
