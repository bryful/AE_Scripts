﻿(function(){
	var reSize = 1 / 4;
	
	function getLayerPos(lyr,cmp)
	{
		var o = new Object;
		o.anc	= lyr.property("Anchor Point").value;
		o.pos	= lyr.property("Position").value;
		o.scale	= lyr.property("Scale").value;
		o.width	= lyr.width;
		o.height	= lyr.height;
		o.offsetPos = [0,0];
		o.offsetPos[0] =  (cmp.width/2) - o.pos[0];
		o.offsetPos[1] =  (cmp.height/2) -o.pos[1];
		return o;
	}
	//---------------------------------------------------------------------------
	//選択したコンポに何かする
	//---------------------------------------------------------------------------
	function resizeComp(tComp)
	{
		var lyrInfo = new Array;
		var srcWidth = tComp.width;
		var srcHeight = tComp.height;
		var dstWidth = Math.round(tComp.width * reSize);
		var dstHeight = Math.round(tComp.height *reSize);

		if (tComp.numLayers>0) {
			for (var i=1; i<=tComp.numLayers; i++){
				lyrInfo.push(getLayerPos(tComp.layer(i),tComp));
			}
		}
		
		tComp.width  = dstWidth;
		tComp.height = dstHeight;
		var center = [0,0];
		center[0] = dstWidth /2;
		center[1] = dstHeight /2;
		if (tComp.numLayers>0) {
			for (var i=1; i<=tComp.numLayers; i++){
				var lyr = tComp.layer(i);
				var p = [0,0];
				//p[0] = center[0] + lyrInfo[i-1].offsetPos[0] * reSize;
				//p[1] = center[1] + lyrInfo[i-1].offsetPos[1] * reSize;
				p[0] = lyrInfo[i-1].pos[0] * reSize;
				p[1] = lyrInfo[i-1].pos[1] * reSize;
				lyr.property("Position").setValue(p);
				p[0] = lyrInfo[i-1].scale[0] * reSize;
				p[1] = lyrInfo[i-1].scale[1] * reSize;
				lyr.property("Scale").setValue(p);
			}
		}
		
		return true;
	}
	//---------------------------------------------------------------------------
	var selectedItems = app.project.selection;
	if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
		app.beginUndoGroup("何か");
		for (var i = 0; i < selectedItems.length; i++) {
			if (selectedItems[i] instanceof CompItem) {
				if (resizeComp(selectedItems[i])==true) {
				}else{
				}
			}
		}
		app.endUndoGroup();
	}else{
		//エラー処理
	}
//---------------------------------------------------------------------------
})();