﻿/*
	F's GuideFrameで指定された範囲でレイヤを切り取り、
	同じ位置へ再配置するスクリプト。
	
	ペイントサイズとゲーム画面サイズが違うときの事も考慮してある。

*/
(function(){
	//fitScale
	/*
		ペイント画像を実際のゲーム画像のサイズにリサイズするときの数値。
		100%フレームの横幅のピクセル数で求める。
		
		ゲームの時の横幅は640pixel、ペイント時は1012pixelなので以下の数値になる。
		一応ダイアログで設定できる
	*/
	var fitScale = 640 / 1012;
	var errMes = "";
	var selectedLayerOnly = false;	// trueならば、選択されたレイヤのみの切り出しとなる
	var addSmooth = true;	// falseでスムージングを行わない。


	//-----------------------------------------------------------------------------
	function splitDialog(){
		this.myDialog = null;
		this.title ="pachi レイヤの切り出し";
		
		this.gameWidth = 640;
		this.paintWidth = 1012;
		this.selectedLayerOnly = false;
		this.addEffect = true;
		
		this.gameWidthCaption	 ="ゲーム画面サイズ";
		this.paintWidthCaption	 ="ペイントサイズ";
		this.slCaption	 ="選択されたレイヤのみ";
		this.aeCaption	 ="スムージング処理を行う";
		
		//エディットテキストを変数にしてtextを得る
		this.edGameWidth;
		this.edPaintWidth;
		this.cbSelectedLayerOnly;
		this.cbAddEffect;
		
		//-------------------------------------------------
		this.getValue = function()
		{
			this.gameWidth = Math.floor(this.edGameWidth.text *1);
			this.paintWidth = Math.floor(this.edPaintWidth.text *1);
			this.selectedLayerOnly = this.cbSelectedLayerOnly.value;
			this.addEffect = this.cbAddEffect.value;
	
			return true;
		}
		//-------------------------------------------------
		this.buildAndShowDialog = function ()
		{	
			var sideW = 10;
			var topH = 10;
			var capW = 100;
			var inputW = 100;
			var inputH = 24;
			var interW = 2;
			var interH = 2;
	
			// build the dialog
		
			var dlg_w = sideW + capW + interW + inputW + sideW;
			var dlg_h = topH + inputH *5  + interH *4 + topH;
			var dlg_l = 200;
			var dlg_t = 200;
			
			this.myDialog = new Window("dialog",this.title);
	
			this.myDialog.bounds = [dlg_l,dlg_t,dlg_l+dlg_w,dlg_t+dlg_h];
			//center()で画面中央に表示
			this.myDialog.center();
			
			var x0 = sideW;
			var x1 = x0+capW;
			var y0 = topH;
			var y1 = y0+inputH;
			
			var st1				= this.myDialog.add("statictext", [ x0, y0, x1, y1], this.gameWidthCaption);
			st1.justify="right";
			
			x0 += capW + interW; x1 = x0 + inputW;
			this.edGameWidth	= this.myDialog.add("edittext"  , [ x0, y0, x1, y1], this.gameWidth +"");
			
			x0 = sideW; x1 = x0 + inputW;
			y0 += inputH + interH; y1 = y0+inputH;
			var st2				= this.myDialog.add("statictext", [ x0, y0, x1, y1], this.paintWidthCaption);
			st2.justify="right";
			
			x0 += capW + interW; x1 = x0 + inputW;
			this.edPaintWidth	= this.myDialog.add("edittext"  , [ x0, y0, x1, y1], this.paintWidth +"");
	
			x0 = sideW; x1 = x0 + inputW+ capW;
			y0 += inputH + interH; y1 = y0+inputH;
			this.cbSelectedLayerOnly	= this.myDialog.add("checkbox"  , [ x0, y0, x1, y1], this.slCaption);
			this.cbSelectedLayerOnly.value = this.selectedLayerOnly;
			y0 += inputH + interH; y1= y0+inputH;
			this.cbAddEffect			= this.myDialog.add("checkbox"  , [ x0, y0, x1, y1], this.aeCaption);
			this.cbAddEffect.value = this.addEffect;
	
			y0 += inputH + interH; y1 = y0+inputH;
			x0 = sideW; x1 = x0 + inputW;
			var okBtn    		= this.myDialog.add("button",			[ x0, y0, x1, y1], "OK",     {name:'ok'} );
			x0 += capW + interW;x1 = x0 + inputW;
			var cancelBtn		= this.myDialog.add("button",			[ x0, y0, x1, y1], "Cancel", {name:'cancel'});
			
			//statictextで右あわせ
			
			return this.myDialog.show();
		}
		//-----------------------------------
		this.execute =function()
		{
			while (true){
				var r=this.buildAndShowDialog();
				//showの戻り値が１ならOKボタンが押された
				if (r==1){
					if (this.getValue()==true){
						//this.getValue()がfalseを返せば、またダイアログが表示される。
						return true;
					}
				}else{
					return false;
				}
			}
		}
	}
	//-----------------------------------------------------------------------------
	// 
	// The main script.
	//





	//---------------------------------------------------------------------------
	function makeFolder(pFold,name)
	{
		var pf = pFold;
		if ( (pf==null)||(pf !=  "[object FolderItem]" ) ) {
			 pf = app.project.rootFolder;
		}
		
		if (pf.numItems>0) {
			for (var i=1 ;i<=pf.numItems; i++)
			{
				if (pf.item(i) instanceof FolderItem) {
					if (pf.item(i).name == name) return pf.item(i);
				}
			}
		}
		return pf.items.addFolder(name);
	}
	//---------------------------------------------------------------------------
	function ExtractFileNameWithoutExt(s)
	{
		if (s=="") return "";
		var idx = s.lastIndexOf(".");
		if (idx==-1) return s;
		return s.substring(0,idx);
	}
	//---------------------------------------------------------------------------
	function ExtractSquence(s)
	{
		s = ExtractFileNameWithoutExt(s);
		if (s=="") return "";
		var idx0 = s.lastIndexOf("[");
		if (idx0==-1) return s;
		var idx1 = s.lastIndexOf("]");
		if (idx1==-1) return s;
		if ( (idx0>idx1)||(idx0==0) ) return s;
		
		s = s.substring(0,idx0);
		var l = s.length;
		if ( l>1){
			if( (s[l-1]==".")||(s[l-1]=="-")||(s[l-1]=="_") ) {
				s = s.substring(0,l-1);
			}
		}
		return s;
	}
	//---------------------------------------------------------------------------
	function newPartsName(s)
	{
		var ss = ExtractSquence(s);
		if (ss.indexOf("PIC_")!=0){
			ss = "PIC_"+ss;
		}
		return ss;
	}
	//---------------------------------------------------------------------------
	function adjLen(v)
	{
		var vv = Math.round(v/4);
		return vv * 4;
	}
	//---------------------------------------------------------------------------
	function addEffect(tLayer,effectName)
	{
		var effect_str	= "エフェクト";
		var fxg = tLayer.property(effect_str);
		if (fxg.canAddProperty(effectName)) {
			return  fxg.addProperty(effectName);
		}
		return null;
	}
	//---------------------------------------------------------------------------
	/*
		ここではカラーキーとOLM Smootherを登録している
	*/
	function layerAddEffect(tLayer)
	{
		var fx=addEffect(tLayer,"カラーキー")
		if (fx!=null){
			fx.property("キーカラー").setValue([1,1,1,1]);
		}
		var fx=addEffect(tLayer,"OLM Smoother")
		if (fx!=null){
		}
	
	}
	//---------------------------------------------------------------------------
	function getPos(tComp,tLayer)
	{
		var o		= new Object;
		o.scale		= [fitScale*100,fitScale*100];
		o.offset	= [0,0];
		o.pAnc		= [0,0];
		o.pPos		= [0,0];
		o.mAnc		= [0,0];
		o.mPos		= [0,0];
		var anc		= tLayer.property("Anchor Point").value;
		var pos		= tLayer.property("Position").value;
		var x0 = 0;
		var y0 = 0;
		var x1 = 0;
		var y1 = 0;
		
		var name = tLayer.name.toLowerCase();
		//エフェクトを探す
		var fxg = tLayer.property("エフェクト");
		var fx = fxg.property("F's GuideFrame");
		if (fx==null) {
			x0 = anc[0] - pos[0];
			x1 = x0 + tComp.width;
			y0 = anc[1] - pos[1];
			y1 = y0 + tComp.height;
			o.pWidth	= adjLen((x1-x0) * fitScale);
			o.pHeight	= adjLen((y1-y0) * fitScale);
			o.mAnc		= [o.pWidth/2,o.pHeight/2];
			o.mPos		= o.mAnc;
		}else{
			var p = fx.property("TopLeft").value;
			x0 = p[0];
			y0 = p[1];
			p = fx.property("BottomRight").value;
			x1 = p[0];
			y1 = p[1];
			if (x0>x1) { var temp = x0; x0=x1; x1 = temp;}
			if (y0>y1) { var temp = y0; y0=y1; y1 = temp;}

			if (x0<=4) x0=0;
			if (y0<=0) y0=0;
			var ox = anc[0] - pos[0];
			var oy = anc[1] - pos[1];
			if (x1>=tComp.width-4+ox) x1=tComp.width -1 +ox;
			if (y1>=tComp.height-4+oy) y1=tComp.height-1 +oy;

			
			var osX = (anc[0] - pos[0]);
			var osY = (anc[1] - pos[1]);
			x0 = x0;
			y0 = y0;
			x1 = x1+ 1;
			y1 = y1+ 1;
			o.pWidth	= adjLen((x1-x0) * fitScale);
			o.pHeight	= adjLen((y1-y0) * fitScale);

			o.mAnc		= [o.pWidth/2,o.pHeight/2];
			o.mPos[0]		= (x0 -(anc[0] - pos[0]))* fitScale + o.pWidth/2;
			o.mPos[1]		= (y0 -(anc[1] - pos[1]))* fitScale + o.pHeight/2;
			
		}
		o.pAnc[0] = x0;
		o.pAnc[1] = y0;
		
		//小数点があったら、パーツわけコンポの方で位置修正を行い。
		//整数化する。
		var f = Math.floor(o.mPos[0]);
		var d = o.mPos[0] - f;
		if (d >0){
			o.mPos[0] = f;
			o.pPos[0] += d;
		}
		f = Math.floor(o.mPos[1]);
		d = o.mPos[1] - f;
		if (d >0){
			o.mPos[1] = f;
			o.pPos[1] += d;
		}
		return o;
	}	
	//---------------------------------------------------------------------------
	//コンポを切り分ける
	//---------------------------------------------------------------------------
	function splitComp(tComp)
	{
		if (tComp.numLayers<=0) {
			errMes += tComp.name + "にはレイヤがない。\n";
			return false;
		}else{
			//サイズのチェック
			var scaleErr = false;
			var collapseErr = false;
			for (var i=1 ; i<=tComp.numLayers;i++){
				var s = tComp.layer(i).property("Scale").value;
				if ( (s[0]!=100)||(s[1]!=100) ){
					scaleErr = true;
				}
				if (tComp.layer(i).collapseTransformation == true) {
					collapseErr = true;
				}
			}
			if (scaleErr == true){
				errMes += "["+ tComp.name + "] すみませんレイヤのスケールは100%でお願いします。\n";
			}
			if (collapseErr == true){
				errMes += "["+ tComp.name + "] すみませんレイヤのコラップスはOFFでお願いします。\n";
			}
			if ((scaleErr == true)||(collapseErr == true)){
				return false;
			}
		}
		
		
		var partsFdr = makeFolder(tComp.parentFolder ,tComp.name + "-01.parts");
		var mixFdr = makeFolder(tComp.parentFolder,tComp.name + "-02.mixed");
		
		var w = adjLen(tComp.width * fitScale);
		var h = adjLen(tComp.height * fitScale);
		
		var mixedComp = mixFdr.items.addComp("02_CAMERA_pos", w, h, tComp.pixelAspect , tComp.duration, tComp.frameRate);

		var partsCompList = new Array;
		var partsCompPrm = new Array;
		var partsCompBlendingMode = new Array;
		
		for (var i=1; i<=tComp.numLayers;i++){
			var tLayer = tComp.layer(i);
			if (selectedLayerOnly==true)
				if (tLayer.selected == false) continue;
			var o = getPos(tComp,tLayer);
			partsCompPrm.push(o);
			partsCompBlendingMode.push(tLayer.blendingMode);
			
			var duration = tComp.frameDuration;
			if ( (tLayer.source.file !=null)||(tLayer.source  instanceof CompItem)||(tLayer.source.mainSource.isStill ==false) ) {
				duration = tLayer.source.duration;
			}
			//BGコンポ
			var fldN = tLayer.source.parentFolder.name.toLowerCase();
			var newCmpName = newPartsName(tLayer.name);
			var bgFlag =false;
			if ( (newCmpName.toLowerCase().indexOf("book")>-1) || (newCmpName.toLowerCase().indexOf("bg")>-1)||(fldN.indexOf("bg")>-1)||(fldN.indexOf("lo")>-1)||(fldN.indexOf("fr")>-1) ) {
				duration = tComp.frameDuration;
				bgFlag =true;
			}
			if (duration <=0) duration = tComp.frameDuration;
			var cmp = partsFdr.items.addComp(newCmpName, o.pWidth, o.pHeight, tComp.pixelAspect , duration, tComp.frameRate);
			//なんかバグっぽいぞ
			cmp.duration = duration;
			partsCompList.push(cmp);
			var lyr = cmp.layers.add(tLayer.source);
			
			lyr.property("Scale").setValue(o.scale);
			lyr.property("Position").setValue(o.pPos);
			lyr.property("Anchor Point").setValue(o.pAnc);
			
			if ( addSmooth == true){
				if (bgFlag==false) {
					layerAddEffect(lyr);
				}
			}
		}
		
		if (partsCompList.length>0){
			for ( var i = partsCompList.length -1 ; i>=0;i--){
				lyr = mixedComp.layers.add(partsCompList[i]);
				lyr.property("Anchor Point").setValue(partsCompPrm[i].mAnc);
				lyr.property("Position").setValue(partsCompPrm[i].mPos);
				lyr.blendingMode = partsCompBlendingMode[i];
			}
		}else{
			if (selectedLayerOnly==true){
				errMes += tComp.name + "には選択されたレイヤがありません。\n";
				return false;
			}
		}
		
		return true;
	}
	//---------------------------------------------------------------------------
	function exec()
	{
		errMes ="";
		var selectedItems = app.project.selection;
		if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
			app.beginUndoGroup("pachi_レイヤ切り分け");
			var cnt =0;
			for (var i = 0; i < selectedItems.length; i++) {
				if (selectedItems[i] instanceof CompItem) {
					cnt++;
					if (splitComp(selectedItems[i])==false) {
						break;
					}
				}
			}
			if (cnt<=0){
				errMes += "コンポが選択されていない\n";
			}
			app.endUndoGroup();
		}else{
			errMes += "何も選択されていない\n";
		}
		if (errMes != ""){
			alert(errMes);
		}
	}	
	


//---------------------------------------------------------------------------
	var w = new splitDialog;
	
	if (w.execute()==true){
		fitScale = w.gameWidth / w.paintWidth;
		selectedLayerOnly = w.selectedLayerOnly;	// trueならば、選択されたレイヤのみの切り出しとなる
		addSmooth =w.addEffect;	// falseでスムージングを行わない。
		exec();
	}else{
		alert("Cancelされました");
	}
//---------------------------------------------------------------------------
	//上のくだりをコメントアウトしてexecのみを呼び出せば、ダイアログは表示されない。
	//exec();


})();