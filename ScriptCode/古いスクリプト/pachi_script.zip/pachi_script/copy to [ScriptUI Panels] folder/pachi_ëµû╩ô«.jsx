
//---------------------------
function calcXY (len,rot)
{
	var o = [0,0];
	if ( (rot>=0)&&(rot<90) ) {

		o[0] =Math.sin((Math.PI /180)*rot)*len;
		o[1] =Math.cos((Math.PI /180)*rot)*len*-1;
	}else if ( (rot>=90)&&(rot<180) ) {
		o[0] =Math.cos((Math.PI /180)*(rot-90))*len;
		o[1] =Math.sin((Math.PI /180)*(rot-90))*len;
	}else if ( (rot>=180)&&(rot<270) ) {
		o[0] =Math.sin((Math.PI /180)*(rot-180))*len *-1;
		o[1] =Math.cos((Math.PI /180)*(rot-180))*len;
	}else if ( (rot>=270)&&(rot<360) ) {
		o[0] =Math.cos((Math.PI /180)*(rot-270))*len*-1;
		o[1] =Math.sin((Math.PI /180)*(rot-270))*len*-1;
	}
	return o;
}
function execMain (l,r,rr,p,tComp,tLayers)
{
	var lenPrm =
	[
		[1,2], //
		[2,6],
		[4,12],
		[2,4],
		[3,9],
	];
	var rotPrm = [1,8,15,30,45,90];
	var f0 = 0;
	var f1 = tComp.duration * tComp.frameRate;
	//先ず移動距離を作成する
	var offsetTbl = new Array;
	var sMin = lenPrm[l][0];
	var sMax = lenPrm[l][1];
	var rRnd = rotPrm[rr];
	var rot = r;
	for (var i = f0; i<f1;i++){
		//移動距離の作成
		var len = sMin + (sMax-sMin)*Math.random();
		//角度の作成
		rot = r;
		rot += (-rRnd + 2*rRnd*Math.random());
		if ( (i % 2)==1){
			rot += 180;
		}
		if (rot<0) rot +=360;
		if (rot>=360) rot -=360;
		offsetTbl.push(calcXY(len,rot));
	}
	//レイヤー数繰り返す
	for (var j = 0; j<tLayers.length;j++){
		var posTbl = new Array;
		var lp = tLayers[j].property("Position");
		for (var i=f0; i<f1; i++){
			posTbl.push(lp.valueAtTime(i*tComp.frameDuration,true));
		}
		for (var i=f0; i<f1; i++){
			var newPos = [0,0];
			newPos[0] = posTbl[i][0] + offsetTbl[i][0];
			newPos[1] = posTbl[i][1] + offsetTbl[i][1];
			if (p==true){
				newPos[0] = Math.round(newPos[0]);
				newPos[1] = Math.round(newPos[1]);
			}
			lp.setValueAtTime(i*tComp.frameDuration,newPos);
		}
	}
}

function ScreenShake_pad(t)
{
	this.palette	= t;
	this.btnSetup	= null;
	this.stLength	= null
	this.lbLength	= null
	this.stRot		= null;
	this.lbRot		= null;
	this.stRotRnd	= null;
	this.lbRotRnd	= null;
	this.cbPosInt	= null;
	this.btnExec	= null;
	

	this.posInt		= true;

	this.lenPrm =
	[
		[1,1], //
		[2,4],
		[4,8],
		[10,15]
	];

	//-----------------------------
	this.build = function()
	{
		var leftWidth	= 5;
		var topHeihght	= 5;
		
		var btnWidth	= 150;
		var itemWidth	= 100;
		var capWidth	= 72;
		var itemHeight	= 24;
		var itemInter	= 5;



		var b = { left:leftWidth, top:topHeihght, right:leftWidth + capWidth, bottom: topHeihght + itemHeight};

		this.stLength = this.palette.add("statictext",b,"大きさ");
		
		var items = new Array;
		items.push("小");
		items.push("中");
		items.push("大");
		items.push("小と中の間");
		items.push("中と大の間");

		b.left = b.right; b.right = b.left + itemWidth;
		this.lbLength = this.palette.add("dropdownlist",b,items);
		this.lbLength.items[2].selected = true;

		b.left = leftWidth; b.right = b.left + capWidth;
		b.top += itemHeight + itemInter; b.bottom = b.top + itemHeight;
		this.stLength = this.palette.add("statictext",b,"方向(時計方向)");
		items = new Array;
		items.push("０時の方向");
		items.push("０時30分の方向");
		items.push("１時の方向");
		items.push("１時30分の方向");
		items.push("２時の方向");
		items.push("２時30分の方向");
		items.push("３時の方向");
		items.push("３時30分の方向");
		items.push("４時の方向");
		items.push("４時30分の方向");
		items.push("５時の方向");
		items.push("５時30分の方向");
		items.push("６時の方向");
		items.push("６時30分の方向");
		items.push("７時の方向");
		items.push("７時30分の方向");
		items.push("８時の方向");
		items.push("８時30分の方向");
		items.push("９時の方向");
		items.push("９時30分の方向");
		items.push("10時の方向");
		items.push("10時30分の方向");
		items.push("11時の方向");
		items.push("11時30分の方向");
		b.left = b.right; b.right = b.left + itemWidth;
		this.lbRot = this.palette.add("dropdownlist",b,items);
		this.lbRot.items[4].selected = true;

		b.left = leftWidth; b.right = b.left + capWidth;
		b.top += itemHeight + itemInter; b.bottom = b.top + itemHeight;
		this.stLength = this.palette.add("statictext",b,"方向のばらつき");
		items = new Array;
		items.push("なし");
		items.push("小");
		items.push("中");
		items.push("大");
		items.push("特大");
		b.left = b.right; b.right = b.left + itemWidth;
		this.lbRotRnd = this.palette.add("dropdownlist",b,items);
		this.lbRotRnd.items[1].selected = true;


		b.left = leftWidth; b.right = b.left + btnWidth;
		b.top += itemHeight + itemInter; b.bottom = b.top + itemHeight;
		this.cbPosInt = this.palette.add("checkbox",b,"値を整数値にする");
		this.cbPosInt.value = true;

		b.top += itemHeight+itemInter; b.bottom = b.top + itemHeight;
		this.btnExec = this.palette.add("button",b,"実行");
		//
		this.btnExec.onClick = this.btnExecClick;
		this.btnExec.len = this.lbLength;
		this.btnExec.rot = this.lbRot;
		this.btnExec.rotR = this.lbRotRnd;
		this.btnExec.pInt = this.cbPosInt;
		this.btnExec.exec = this.exec;
		
		
	}
	//---------------------------
	this.btnExecClick =function()
	{
		var l = 0;
		var r = 0;
		var rr = 0;
		var p = false;
		for (var i=0; i<this.len.items.length ;i++){
			if (this.len.items[i].selected == true) {
				l=i;
				break;
			}
		}
		for (var i=0; i<this.rot.items.length ;i++){
			if (this.rot.items[i].selected == true) {
				r = i * (360/24);
				break;
			}
		}
		for (var i=0; i<this.rotR.items.length ;i++){
			if (this.rotR.items[i].selected == true) {
				rr = i;
				break;
			}
		}
		p = this.pInt.value;
		this.exec(l,r,rr,p);
	}
	//---------------------------
	this.exec =function(l,r,rr,p)
	{
		var activeComp = app.project.activeItem;
		if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
			var selectedLayers = activeComp.selectedLayers;

			if ( (selectedLayers!=null)&&(selectedLayers.length>0) ){
				app.beginUndoGroup("画面動");
				execMain(l,r,rr,p,activeComp,selectedLayers);
				app.endUndoGroup();
			}else{
				alert("レイヤーを選択してください。");
			}
		}else{
			alert("レイヤーを選択してくださいよ。");
		}
	}
	//---------------------------
	//---------------------------
}
///-----------------------------------------------------------------------

var sp = new ScreenShake_pad(this);
sp.build();
