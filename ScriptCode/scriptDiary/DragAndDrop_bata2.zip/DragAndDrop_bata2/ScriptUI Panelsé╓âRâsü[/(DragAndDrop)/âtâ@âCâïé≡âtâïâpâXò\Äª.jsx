﻿/*
	AE_DragAndDropのサンプルスクリプト
*/
//----------------------------------------------------------------
//関数名は変更しない
function _fileArrayFunc(ary)
{
	//-----------------------------------
	//関数内部で関数定義する
	function dispFileInfo(f)
	{
		var ret = "";
		if ( f instanceof File){
			ret += "    File:" + File.decode(f.fullName);
		}else if ( f instanceof Folder){
			ret += "Folder:" + File.decode(f.fullName);
		}else{
			ret + "unknown!";
		}
		return ret;
	}
	//-----------------------------------
	//引数のチェック
	if ( ( ary instanceof Array)==false) return;

	//-----------------------------------
	var ret = "";
	if ( ary.length<=0) {
		ret ="no Files";
	}else{
		for ( var i=0; i< ary.length; i++){
			ret += dispFileInfo(ary[i]) +"\r\n";
		}
	}
	alert(ret);
}
//----------------------------------------------------------------

