﻿/*
	無名関数外で定義した関数は必ず初期化してから使う。
*/
//AE_DragAndDropから呼び出される関数
//内部でexec関数に上書きされる
var  _fileArrayExec = null;

//作成されるFile/Folderオブジェクトの配列のダミー
var _fileArray = [];

var _stillWords = [];

(function(me){
	//--------------------------------------------------------------------
	//prototype登録
	String.prototype.trim = function(){
		if (this=="" ) return ""
		else return this.replace(/[\r\n]+$|^\s+|\s+$/g, "");
	}
	String.prototype.getParent = function(){
		var r=this;var i=this.lastIndexOf("/");if(i>=0) r=this.substring(0,i);
		return r;
	}
	//ファイル名のみ取り出す（拡張子付き）
	String.prototype.getName = function(){
		var r=this;var i=this.lastIndexOf("/");if(i>=0) r=this.substring(i+1);
		return r;
	}
	
	//文字の置換。（全ての一致した部分を置換）
	String.prototype.replaceAll=function(s,d){ return this.split(s).join(d);}
	
	FootageItem.prototype.nameTrue = function(){ var b=this.name;this.name=""; var ret=this.name;this.name=b;return ret;}
	//拡張子のみを取り出す。
	String.prototype.getExt = function(){
		var r="";var i=this.lastIndexOf(".");if (i>=0) r=this.substring(i);
		return r;
	}
	//指定した書拡張子に変更（dotを必ず入れること）空文字を入れれば拡張子の消去。
	String.prototype.changeExt=function(s){
		var i=this.lastIndexOf(".");
		if(i>=0){
			return this.substring(0,i)+s;
		}else{
			return this;
		}
	}

	//**************************************************************************************
	/*
		Fileオブジェクトから連番情報を獲得するクラス
	*/
	function FsPictureFile(inF)
	{
		var m_file = null;

		var m_node = "";
		var m_frame = "";
		var m_ext = "";

		var m_isPicture = false;
		var m_isMovie = false;
		var m_isSequence = false;
		var m_isPsd = false;
		
		var m_maxFrame = "-1";
		var m_minFrame  = "999999999999";
		var m_Sequence = [];
		//---------------------------------------
		this.file = function(){ return m_file; }
		 this.name = function() {
		 	var ret = "";
			if ((m_file !=null)&&( m_file instanceof File)) {
				ret = m_file.name;
			}
			return ret;
		 }
		 this.exists = function() {
		 	var ret = false;
			if ((m_file !=null)&&( m_file instanceof File)) {
				ret = m_file.exists;
			}
			return ret;
		 }
		this.node = function() { return m_node; }		//AA_001.tgaのAA_の部分を返す
		this.frame = function() { return m_frame; }		//AA_001.tgaの001の部分を返す
		this.ext = function() { return m_ext; }			//AA_001.tgaの.tgaの部分を返す
		this.isPicture = function() { return m_isPicture; }	//画像だったらtrue
		this.isMovie = function() { return m_isMovie; }		//ムービーファイルだったら true
		this.isSequence = function() { return m_isSequence; }	//連番ファイルならtrue
		this.isPsd = function() { return m_isPsd; }					// psdファイルならtrue
		this.maxFrame = function() { return m_maxFrame; }		// 連番時の最大フレーム文字列
		this.minFrame = function() { return m_minFrame; }		//連番時の最小フレーム文字列
		this.dispName = function() { 									//After Effectsに取り込んだときのファイル名
			var ret = m_node;
			if ( m_isSequence == true) {
				ret += "[" + m_minFrame + "-" + m_maxFrame +"]";
			}else{
				ret += m_frame;
			}
			ret += m_ext;
			return ret;
		 }
		 this.importOptions = function(){		//インポートオプション
		 	if(m_file == null){
		 		return null;
		 	}else{
		 		var ret = new ImportOptions(m_file);
		 		if (m_isSequence == true) {
		 			ret.sequence = true;
		 		}
		 		return ret;
		 	}
		 }
		 this.sequence = function(idx)	//連番時のフレーム文字列配列
		 {
		 	var ret = "";
		 	if ( (m_isSequence == true)||(m_isPicture == true)) {
			 	if ( (idx>=0)&&(idx < m_isSequence.length)) {
			 		ret = m_isSequence[idx];
			 	}
			 }
			 return ret;
		 }
		 this.sequenceCount = function() { return m_Sequence.length; }	//上のカウント数
		 
		//---------------------------------------
		//クラス同士の比較。同じ連番ファイルならtrue
		function m_compare(pf)
		{
			return ( (m_node == pf.node())&& (m_ext == pf.ext()) );
		}
		this.compare = m_compare;
		//---------------------------------------
		//コンストラクタの実態
		function init(f)
		{
			m_file = null;
			m_node = "";
			m_frame = "";
			m_ext = "";
			if ( f instanceof File){
				m_file = f;
			}else if ( typeof(f) =="string") {
				m_file = new File(f);
				if ( m_file == null) return;
			}else{
				return;
			}
			
		}
		//---------------------------------------
		//ファイル名からフレーム文字列のindexを探す。
		function lastNumberIndex( inS)
		{
			// -1 数字なし
			var ret = -1;
			var cnt = inS.length;
			if ( cnt>0) {
				for ( var i= cnt-1; i>=0; i--) {
					var c = inS[i];
					if ( (c<"0")||(c>"9")) {
						ret = i;
						break;
					}
				}
				ret += 1;
				if ( ret == cnt) {
					ret = -1;
				}
			}
			
			return ret;
		}
		//---------------------------------------
		//静止画かムービーか判別
		function getPictureType()
		{
			m_isPicture = false;
			m_isMovie = false;
			m_isSequence = false;
			m_isPsd = false;
			if ((m_file !=null)&&( m_file instanceof File)) {
				var ext = m_ext.toLowerCase();
				m_isMovie = ( (ext == ".mov")||(ext == ".qt")||(ext == ".avi")||(ext == ".mpg")||(ext == ".mpeg") );
				m_isPicture = ( (ext == ".png")||(ext == ".tga")||(ext == ".jpg")||(ext == ".jpeg")||(ext == ".tif")||(ext == ".psd") );
				m_isPsd = ( ext == ".psd");
			}
		}
		//---------------------------------------
		//ファイル名をフレーム番号を元に分割
		//フレーム番号の最小最大文字列も獲得
		function splitName()
		{
			m_node = "";
			m_frame = "";
			m_ext = "";
			m_Sequence = [];
			if ((m_file !=null)&&( m_file instanceof File)) {
				var nm = m_file.name;
				var idx = nm.lastIndexOf(".");
				if (idx>=0){
					m_ext = nm.substring(idx);
					nm = nm.substring(0,idx);
					
					var idx= lastNumberIndex(nm);
					if ( idx<0) {
						m_node = nm;
					}else if  (idx==0){
						m_frame = nm;
					}else{
						m_frame = nm.substring(idx);
						m_node = nm.substring(0,idx);
					}
					if ( m_frame != ""){
						var maxV = m_maxFrame * 1;
						var minV = m_minFrame * 1;
						var v = m_frame * 1;
						if ( v > maxV) m_maxFrame = m_frame;
						if ( v < minV) m_minFrame = m_frame;
						m_Sequence.push(m_frame);
					}
				}
			}
		}
		//---------------------------------------
		//同じクラスと比較して同じ連番なら追加してtrue
		//最大最小値を識別も行う
		function m_addSequence(pf)
		{
			var ret = false;
			if ( (m_isPicture == true)||(m_isSequence == true) ){
				if ( pf instanceof FsPictureFile){
					if ( (pf.isPicture() == true)||(pf.isSequence() == true) ){
						if ( (m_node == pf.node())&&(m_ext == pf.ext())){
							if (pf.sequenceCount()>0) {
								var minV = m_minFrame *1;
								var maxV = m_maxFrame *1;
								for ( var i=0; i<pf.sequenceCount(); i++) {
									var s = pf.sequence(i);
									if ( s != "")
										m_Sequence.push(s);
									if ( pf.minFrame()*1 < minV) {
										m_minFrame = pf.minFrame();
										minV = m_minFrame *1;
									}
									if ( pf.maxFrame()*1 > maxV) {
										m_maxFrame = pf.maxFrame();
										maxV = m_maxFrame *1;
									}
								}
								m_isSequence = true;
								ret = true;
							}
						}
					}
				}
			}
			return ret;
		}
		this.addSequence = m_addSequence;
		//---------------------------------------
		//新しいFileオブジェクトを設定
		this.setFile = function(inF)
		{
			init(inF);
			splitName();
			getPictureType();
		}
		//---------------------------------------
		//強制静止画文字列が含まれているか確認。
		function m_inStrillWords(inA)
		{
			var ret = false;
			if ( (m_isPicture == true)||(m_isSequence == true) ){
				if ( inA instanceof Array){
					if ( inA.length>0) {
						for ( var i=0; i<inA.length; i++){
							if (m_node.indexOf(inA[i]) >= 0){
								ret = true;
								break;
							}
						}
					}
				}
			}
			return ret;
		}
		this.inStillWords = m_inStrillWords;
		//---------------------------------------
		//コンストラクタ
		init(inF);
		splitName();
		getPictureType();
	}
	//**************************************************************************************
	//**************************************************************************************
	/*
		フォルダから連番を抜き出すクラス。
	*/
	function FsPictureFiles()
	{
		var m_files = [];	// FsPictureFileの配列
		var m_dir  = null;	//ターゲットのディレクトリ
		var m_stillWords = [];	//強制的に静止画にするファイル名。含まれていたら静止画にする
		//---------------------------------------
		// m_filesのgetter関数
		this.files = function(idx){
			var ret = null;
			if ( (idx>=0)&&(idx<m_files.length)){
				ret = m_files[idx];
			}
			return ret;
		}
		//---------------------------------------
		//importOptionsのgetter関数
		this.importOptions = function(idx){
			var ret = null;
			if ( (idx>=0)&&(idx<m_files.length)){
				ret = m_files[idx].importOptions();
			}
			return ret;
		}
		this.count = function(){ return m_files.length;}
		//---------------------------------------
		// m_dirのgetter関数
		this.dir = function(){return m_dir; }
		//---------------------------------------
		function m_setStillWords(inA)
		{
			m_stillWords = [];
			var sa = [];
			if ( typeof(inA) == "string"){
				sa = inA.split(";");
			}if ( inA instanceof Array){
				sa = inA;
			}
			if ( sa.length>0){
				for ( var i=0; i<sa.length; i++){
					var c = sa[i];
					if ( typeof(c)=="string"){
						c = c.trim();
						if ( c != "") m_stillWords.push(c);
					}
				}
			}
		}
		this.setStillWords = m_setStillWords;
		//---------------------------------------
		function m_listupSub(fld,depth)
		{
			//5階層以下はスキャンしない
			if ( depth>=5) return;
			//ファイルを獲得
			var fls = fld.getFiles();
			if ( fls.length<=0) return;
			var fl = [];
			var dl = [];
			//FileとFolderを分ける
			for ( var i=0; i< fls.length; i++){
				if ( fls[i] instanceof Folder) dl.push(fls[i]);
				else if ( fls[i] instanceof File) fl.push(fls[i]);
			}
			//ファイルの処理
			if (fl.length>0){
				for ( var i=0; i< fl.length; i++){
					var pf = new FsPictureFile(fl[i]);
					if ( pf.isMovie()==true){
						m_files.push(pf);
					}else if ( (pf.isPicture()==true)||(pf.isSequence()==true) ) {
						if (  ( m_files.length<=0)||(pf.inStillWords(m_stillWords) == true)) {
							m_files.push(pf);
						}else{
							if ( m_files[m_files.length-1].addSequence(pf) == false) {
								m_files.push(pf);
							}
						}
					}else{
					}
				}
			}
			//ディレクトリは再帰処理
			if ( dl.length>0){
				for ( var i=0; i< dl.length; i++){
					m_listupSub(dl[i],depth+1);
				}
			}
		}
		//---------------------------------------
		function m_listup(fld)
		{
			var ret = false;
			m_files = [];
			m_dir = null;
			if ( (fld == null)||( !(fld instanceof Folder)) ) return ret;
			
			m_listupSub(fld,0);
			
			var b = (m_files.length>0);
			if ( b) m_dir = fld;
			return b;
		}
		this.listup = m_listup;
		//---------------------------------------
	}
	//**************************************************************************************
	function FsImporter()
	{
		//---------------------------------------
		function ArrayToStr(a)
		{
			var ret = "";
			if ( a instanceof Array) {
				var cnt = a.length;
				if ( cnt>0) {
					for ( var i=0; i<cnt; i++){
						ret += a[i];
						if ( i<cnt-1) ret += ":";
					}
				}
			}
			return ret;
		}
		//---------------------------------------
		function arrayEqu(a0,a1)
		{
			var ret = false;
			if ( (a0 instanceof Array)&&(a1 instanceof Array) )
			{
				if (a1.length>0) {
					if ( a0.length>= a1.length) {
						ret = true;
						for ( var i=0; i<a1.length; i++){
							if ( a0[i].toLowerCase() != a1[i].toLowerCase()) {
								ret = false;
								break;
							}
						}
					}
				}
			}
			return ret;
		}
		//---------------------------------------
		function m_getPathArray(itm)
		{
			var ret = [];
			if ( ( itm instanceof FootageItem)||( itm instanceof FolderItem)||( itm instanceof CompItem) ) {
				var rootID = app.project.rootFolder.id;
				
				ret.push(itm.name);
				var p = itm.parentFolder;
				while( p.id != rootID)
				{
					ret.push(p.name);
					p = p.parentFolder;
				}
				ret = ret.reverse();
			}
			return ret;
		}
		this.getPathArray = m_getPathArray;
		//---------------------------------------
		function m_makeFolder(m)
		{
			var ret = null;
			if (m.length<=0) return ret;
			ret = app.project.rootFolder;
			for ( var i= 0; i<m.length; i++){
				var nf = null;
				if ( ret.numItems>0){
					for ( var p=1; p<=ret.numItems; p++)
					{
						if ( ret.items[p] instanceof FolderItem){
							if ( ret.items[p].name == m[i]){
								nf = ret.items[p];
							}
						}
					}
				}
				if (nf ==null) {
					ret = ret.items.addFolder(m[i]);
				}else{
					ret = nf;
				}
			}
			return ret;
		}
		this.makeFolder = m_makeFolder;
		//---------------------------------------
		function m_findItemsByPathArray(inA)
		{
			var ret = [];
			if ( app.project.numItems>0){
				for ( var i=1; i<=app.project.numItems; i++){
					if ( arrayEqu( m_getPathArray(app.project.items[i]), inA) == true) {
						ret.push(app.project.items[i]);
					}
				}
			}
			return ret;
		}
		this.findItemsByPathArray = m_findItemsByPathArray;
		//---------------------------------------
		function m_findFolderByPathArray(inA)
		{
			var ret = [];
			var a = m_findItemsByPathArray(inA);
			if ( a.length>0){
				for ( var i = 0; i<a.length; i++){
					if ( a[i] instanceof FolderItem) ret.push(a[i]);
				}
			}
			if (ret.length<=0) ret.push(m_makeFolder(inA));
			return ret;
		}
		this.findFolderByPathArray = m_findFolderByPathArray;
		//---------------------------------------
		function m_import(imo,fld)
		{
			var ret = null;
			if ((imo == null)||(imo.file == null)) return ret;
			if ( (fld == null)||(fld == undefined)||(!(fld instanceof FolderItem ) ) ) {
				fld = null;
			}
			try{
				ret = app.project.importFile(imo);
				if ( fld != null){
					ret.parentFolder = fld;
					if ( ret instanceof CompItem){
						if ( ret.numLayers>0){
							var fld2 = ret.layer(1).source.parentFolder;
							fld2.parentFolder = fld;
						}
					}
				}
			}catch( e){
				ret = null;
				return ret;
			}
			return ret;
		}
		this.import = m_import;
		//---------------------------------------
	}


	//**************************************************************************************
	//**************************************************************************************

	//Windows Mac識別
	var isWindows = ($.os.indexOf("Windows")>=0);
	var isMac = ! isWindows;
	//----------------------------------
	var scriptName = File.decode($.fileName.getName().changeExt(""));
	var prefFile = new File($.fileName.changeExt(".pref"));
	//----------------------------------
	//スクリプトを読み込むフォルダ
	var targetFolder = new Folder ( $.fileName.getParent() + "/(" +$.fileName.getName().changeExt("")+ ")");

	//スクリプトのあるフォルダ
	var scriptFolder = new Folder ( $.fileName.getParent());
	var appFolder = Folder.appPackage;
	if ( isMac == true) appFolder = appFolder.parent;
	//毎回上書きされて呼び出される関数ポインタ
	var  _fileArrayFunc = null;

	var jsx_files = [];
	//-------------------------------------------------------------------------
	function listupFiles(ary)
	{
		if ( ( ary instanceof Array)==false) return;
		var ret = "";
		if ( ary.length<=0) {
			ret ="no Files";
		}else{
			for ( var i=0; i< ary.length; i++){
				if ( ary[i] instanceof File){
					ret += "    File:" + ary[i].name +"\r\n";
				}else if ( ary[i] instanceof Folder){
					ret += "Folder:" + ary[i].fullName +"\r\n";
				}else{
					ret + "unknown!\r\n";
				}
			}
		}
		alert(ret);
	}
	//-------------------------------------------------------------------------
	function jsxListupSub(f)
	{
		if ( (f instanceof Folder) ==false) return;
		var files = f.getFiles();
		if (files.length<=0) return;
		var dl =[];
		for ( var i=0; i<files.length; i++)
		{
			if( files[i] instanceof Folder){
				dl.push(files[i]);
			}else if (files[i] instanceof File) {
				var n = files[i].name.getExt().toLowerCase();
				if ( n == ".jsx") {
					jsx_files.push(files[i]);
				}
			}
		}
		if ( dl.length>0) {
			for ( var i=0; i<dl.length; i++) jsxListupSub(dl[i]);
		}
	}
	//-------------------------------------------------------------------------
	function jsxListup()
	{
		jsx_files = [];
		jsxListupSub(targetFolder);
	}
	//-------------------------------------------------------------------------
	var btnOpenDragAndDrop_str = "Open DandD";
	var btnFunctionList_items = [ ];
	var winObj = ( me instanceof Panel) ? me : new Window("palette", "DragAndDrop", [ 0,  0,  180,  150]  ,{resizeable:true, maximizeButton:true, minimizeButton:true});
	//-------------------------------------------------------------------------
	var btnOpenDragAndDrop = winObj.add("button", [  10,   10,   10+ 160,   10+  30], btnOpenDragAndDrop_str );
	btnOpenDragAndDrop.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var lstFunctionList = winObj.add("dropdownlist", [  10,   45,   10+ 160,   45+  30], btnFunctionList_items);
	lstFunctionList.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnReload = winObj.add("button", [  10,   80,   10+  90,   80+  30], "Jsx Reload" );
	btnReload.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var edStillWords = winObj.add("edittext", [  10,   115,   10+  160,   115+  30], "lo;fr;bg;atari;sl" );
	edStillWords.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 14);

	//-------------------------------------------------------------------------
	function fileToCaption(f)
	{
		var ret ="";
		if ( f instanceof File){
			ret = File.decode(f.name).changeExt("");
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function makeFunctionList()
	{
		var nm = "";
		//選択されている項目を確保
		if (jsx_files.length>0){
			var idx = lstFunctionList.selection.index;
			if ( idx>=0) {
				nm = jsx_files[idx].name;
			}
		}
		jsxListup();
		lstFunctionList.removeAll();
		if (jsx_files.length>0){
			for ( var i=0; i<jsx_files.length; i++){
				lstFunctionList.add("item",fileToCaption(jsx_files[i]));
			}
			
			var idx = 0;
			if ( nm !=""){
				//選択されていた項目を復帰
				for ( var i=0; i<jsx_files.length; i++){
					if ( nm == jsx_files[i].name){
						idx =i;
						break;
					}
				}
			}
			lstFunctionList.items[idx].selected = true;
		}
		
	}
	makeFunctionList();
	btnReload.onClick = makeFunctionList;
	//-------------------------------------------------------------------------
	function resizeWin()
	{
		var w = winObj.bounds.width;
		var h = winObj.bounds.height;
		var ob = btnOpenDragAndDrop.bounds;
		ob[0] = 10;
		ob[2] = w -10;
		btnOpenDragAndDrop.bounds = ob;
		var fb = lstFunctionList.bounds;
		fb[0] = 10;
		fb[2] = w -10;
		lstFunctionList.bounds = fb;

		var eb = edStillWords.bounds;
		eb[0] = 10;
		eb[2] = w -10;
		edStillWords.bounds = eb;
	}
	resizeWin();
	winObj.onResize = resizeWin;
	
	//-------------------------------------------------------------------------
	function execError()
	{
		alert("err!");
	}
	//-------------------------------------------------------------------------
	function exec(ary)
	{
		if ( jsx_files.length<=0) {
			alert("none jsx files");
			return;
		}
		var idx = lstFunctionList.selection.index;
		if ( (idx<0)||(idx>=jsx_files.length)){
			alert("Error! lstFunctionList");
			return;
		}
		jsx_files[idx].open("r");
		var lines ="";
		try{
			lines = jsx_files[idx].read();
		}catch(e){
			alert("file open error!");
			return;
		}finally{
			jsx_files[idx].close();
		}
		_fileArrayFunc = null;
		try{
			eval(lines);
		}catch(e){
			alert("eval err");
		}
		
		if ((_fileArrayFunc != null)&&( _fileArrayFunc instanceof Function)) {
			try{
				_stillWords = edStillWords.text;
				_fileArrayFunc(_fileArray);
			}catch(e){
				alert("_fileArrayFunc Execute Error!\r\n"+e.toString());
			}
		}else{
			alert(" Error! _fileArrayFunc is not Function.");
		}
	}
	//無名関数外のobjectにリンク
	_fileArrayExec = exec;
	//-------------------------------------------------------------------------
	//-------------------------------------------------------------------------
	//AE_DragAndDropを呼び出す。
	btnOpenDragAndDrop.onClick = function()
	{
		var bk = Folder.current;
		Folder.current = appFolder;
		if ( isWindows == true){
			//AE_DragAndDrop.exeは、AE_DragAndDropDialog.exeを呼び出してすぐに終了する
			//探せるところは探す
			var f = new File(Folder.system.fullName+"/System32/AE_DragAndDrop.exe");
			if (f.exists == false) f = new File(appFolder.fullName+"/AE_DragAndDrop.exe");
			if (f.exists == false) f = new File(scriptFolder.fullName+"/AE_DragAndDrop.exe");
			if (f.exists == true) {
				system.callSystem(f.fullName);
			}else{
				//諦めてとりあえず実行
				system.callSystem("AE_DragAndDrop.exe");
			}
		}else{
			var f = new File("Applications/AE_DragAndDrop.app");
			if (f.exists == false) f = new File(appFolder.fullName+"/AE_DragAndDrop.app");
			if (f.exists == false) f = new File(scriptFolder.fullName+"/AE_DragAndDrop.app");
			if (f.exists == true) {
				//ターミナルからappを呼び出すにはopenを使う
				system.callSystem("open \"" +f.fullName+"\"");
			}else{
				alert("AE_DragAndDrop.appが見つかりません");
			}
		}
		Folder.current =bk;
	}
	//===============================================================================
	function savePrm()
	{
		var idx = lstFunctionList.selection.index;
		var cap = "";
		if ((idx !=null)&&(idx>=0)&&(idx<jsx_files.length)) {
			cap = jsx_files[idx].name;
		}
		var sw = edStillWords.text;
		prefFile.open("w");
		try{
			prefFile.write(cap);
			prefFile.write(sw);
		}finally{
			prefFile.close();
		}
	
	}
	winObj.onClose = savePrm;
	//===============================================================================
	function loadPrm()
	{
		if (jsx_files.length<=0) return;
		var cap =0;
		if (prefFile.exists == false) return;
		prefFile.open("r");
		try{
			var line = prefFile.readln();
			var sw = prefFile.readln();
		}catch(e){
			return;
		}finally{
			prefFile.close();
		}
		var idx = 0;
		if (line != "") {
			for ( var i=0; i<jsx_files.length; i++)
			{
				if (line == jsx_files[i].name){
					idx = i;
					break;
				}
			}
		}
		lstFunctionList.items[idx].selected = true;
		if (sw == null) sw = "";
		if ( sw == "") sw ="bg;lo;sl;fr";
		edStillWords.text = sw;
	}
	loadPrm();
	//-------------------------------------------------------------------------
	if ( ( me instanceof Panel) == false){
		winObj.center(); 
		winObj.show();
	}
	//-------------------------------------------------------------------------
})(this);



