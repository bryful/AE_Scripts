﻿/*
	選択したシェイプレイヤーのプロパティを書きだす
	このバージョンではプロパティの値ではなく、matchnameとnameを出力
*/

//---------------------------------------------------------------------------
var proList = new Array;
var o = new Object;
//---------------------------------------------------------------------------
function listupPro(o, pro)
{
	if (pro.numProperties>0){
		for ( var i=1; i<=pro.numProperties; i++){
			//nameが変更出来るものはmatchNameではなくnameを優先
			var canNameChange = true;
			try{
				var nm = pro.property(i).name;
				pro.property(i).name = "__TTT___z_____";	//とりあえず適当な名前
				pro.property(i).name = nm
			}catch(e){
				canNameChange = false;
			}
			if (canNameChange == true){
				o[pro.property(i).name] = new Object;
				listupPro(o[pro.property(i).name],pro.property(i));
			}else{
				if (pro.property(i) instanceof Property){
					o[pro.property(i).matchName] = pro.property(i).name;
				}else{
					o[pro.property(i).matchName] = new Object;
					listupPro(o[pro.property(i).matchName],pro.property(i));
				}
			}
		}
	}
}
//---------------------------------------------------------------------------
function tab(c)
{
	var ret = "";
	if ( c>0){
		for ( var j=0; j<c;j++){
			ret += "\t";
		}
	}
	return ret;
}
//---------------------------------------------------------------------------
function exportProperties(tLayer)
{
	
	proList = new Array;
	o = new Object;//
	
	//*******************************************
	if ( tLayer.property("ADBE Root Vectors Group") !=null){
			o["ADBE Root Vectors Group"] = new Object;
			listupPro(o["ADBE Root Vectors Group"], tLayer.property("ADBE Root Vectors Group"));
	}
	if ( tLayer.property("ADBE Transform Group") !=null){
			o["ADBE Transform Group"] = new Object;
			listupPro(o["ADBE Transform Group"], tLayer.property("ADBE Transform Group"));
	}
	//*******************************************
	//こっちを有効にするとプロパティ全部になる
	/*
	if (tLayer.numProperties>0)
	{
		for ( var i=1; i<=tLayer.numProperties;i++)
		{
			listupPro(o, tLayer.property(i));
		}
	}
	*/
	//*******************************************
	
	var myJson = o.toSource();
	//読みやすいように整形する
	var ss = "";
	var tabCount=0;
	var cnt = myJson.length;
	for (var i=0; i<cnt;i++)
	{
		var c = myJson[i];
		
		if ( c=="{"){
			tabCount++;
			ss += "\n"+tab(tabCount)+"{\n"
			tabCount++;
			ss += tab(tabCount);
			tabCount--;
		}else if ( c =="}"){
			ss += "\n"+tab(tabCount)+"}";
			tabCount--;
		}else if ( c ==","){
			ss += ",\n"+tab(tabCount);
		}else if ( c ==")"){
			ss += "\n)";
		}else{
			ss += c;
		}
	}
	
	var fileObj = File.saveDialog("pro.txt");
	//var fileObj = new File("aaa.txt");
	if (fileObj  != null){
		var flag = fileObj.open("w");
		if (flag == true)
		{
			try{
				fileObj.write(ss);
				fileObj.close();
			}catch(e){
			}
		}
	}
}
//---------------------------------------------------------------------------
var activeComp = app.project.activeItem;
if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
	
	var selectedLayers = activeComp.selectedLayers;

	if ( (selectedLayers!=null)&&(selectedLayers.length==1) ){
		exportProperties(selectedLayers[0]);
	}else{
	//エラー処理
		alert("レイヤを一つだけ選択してね?")
	}
}
//---------------------------------------------------------------------------

