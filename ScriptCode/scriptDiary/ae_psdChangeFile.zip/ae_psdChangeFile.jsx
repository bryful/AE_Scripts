﻿
/*
	psdのレイヤー付きフッテージのファイル差し替えの関数。
	
	違うファイルに差し替えではなく、同じレイヤ名のものと差し替えになる。
	
	ファイル名は違っていてもいいが、レイヤ名が違っていると差し替えに失敗する。
	
*/

//*************************************************************************
//フッテージがpsd/aiのレイヤ付きかどうかを判別する
FootageItem.prototype.hasLayer = function()
{
	//平面フッテージは違う。
	if (this.mainSource.color != undefined) return false;
	if ( (this.hasVideo == false)||( this.mainSource.isStill == false)) return false;

	//真名を得る。
	var bak = this.name;
	this.name = "";
	var nt = this.name;
	this.name = bak;

	// /の後ろの文字列を獲得
	var n = ""
	var idx = nt.lastIndexOf("/");
	if (idx >0) n = nt.substring(idx+1).toLowerCase();
	//ファイル名を獲得
	var fn = this.file.name.toLowerCase();
	
	//文字列が同じなら多分レイヤー付きだ。
	return (fn == n);
}
//*************************************************************************
//フッテージ配列から、レイヤ付きのものだけ選び出す。
Array.prototype.getLayered = function()
{
	var ret = [];
	if ( this.length<=0) return ret;
	for ( var i= 0; i<this.length; i++)
		if ( this[i] instanceof FootageItem)
			if (this[i].hasLayer()==true) ret.push(this[i]);
	return ret;
}

//*************************************************************************
//psdファイルを違うパスのpsdに変えるもの
/*
	psdFtg		レイヤー付きフッテージ、又はその配列
	theFile		新しいpsdファイルのFile object
	allMode		psdFtgが単独のフッテージの場合のみ有効。trueのなら同じFileのものが全て対象となる。
				allModeは省略可
	
	
	返り値は、差し替えされなかったフッテージの数。
	つまり、０なら成功
	エラーの場合は　マイナスのNumber objectが返る
	
*/
Project.prototype.psdChangeFile = function(psdFtg,theFile,allMode)
{
	//-----------------------------------------------------------------
	//拡張子
	function getExt(s){ 
		var r="";
		var i=s.lastIndexOf(".");
		if (i>=0) r=s.substring(i);
		return r;
	}
	//-----------------------------------------------------------------
	function getLayerName(s){
		if ( s == "") return "";
		var i=s.lastIndexOf("/");
		if (i>=0) {
			//aaaaa/bb.psd
			//0123456789AB
			return s.substring(0,i);
		}else{
			return "";
		}
		return ret;
	}
	//-----------------------------------------------------------------
	//フッテージの情報
	function getStatus(ftg)
	{
		var bak = ftg.name;
		ftg.name = "";
		var nt = ftg.name;
		ftg.name = bak;
		var o = new Object;
		o.name = nt;
		o.layerName = getLayerName(nt);
		o.footage = ftg;
		o.width = ftg.width;
		o.height = ftg.height;
		o.repFlag = false;
		return o;
	}
	//-----------------------------------------------------------------
	function listupSameFullName(ftg)
	{
		var ret = [];
		if ( (ftg instanceof FootageItem)==false) return ret;
		if ( ftg.hasLayer() == false) return ret;
		var path = ftg.file.fullName;
		for ( var i=1; i<=app.project.numItems;i++){
			var t = app.project.item(i);
			if ( t.hasLayer()==false) continue;
			if ( t.file.fullName != path) continue;
			var o = getStatus(t);
			if (o.layerName != "") ret.push(o);
		}
		return ret;
	}
	//-----------------------------------------------------------------
	function targetsChk(ary)
	{
		var ret = [];
		if ( ary.length<=0) return ret;
		var strat = 0;
		var end = 0;
		if ( ary instanceof ItemCollection){
			start = 1 ; end = ary.length;
		}else{
			start = 0 ; end = ary.length-1;
		}
		var fullName = ary[0].file.fullName;
		for ( var i=start; i<=end;i++){
			if ( (ary[i] instanceof FootageItem)==false) continue;
			if ( ary[i].file.fullName != fullName) continue;
			if ( ary[i].hasLayer()==false) continue;
			var o = getStatus(ary[i]);
			if (o.layerName != "") ret.push(o);
		}
		return ret;
	}
	//-----------------------------------------------------------------
	//使われているFootageItemの挿げ替え
	function useChange(sFtg,dFtg)
	{
		var ftgs = sFtg.usedIn;
		if ( ftgs.length<=0) return false;
		for (var i=0;i<ftgs.length;i++)
		{
			for(var p=1; p<=ftgs[i].numLayers; p++){
				var lyr =ftgs[i].layer(p);
				if(lyr instanceof AVLayer)
					if(lyr.source.id==sFtg.id)
						lyr.replaceSource(dFtg,false);
			}
		}
		return true;
	}
	//-----------------------------------------------------------------
	function importPSD(f)
	{
		var ret = [];
		var fl = f;
		var cmp = null;
		var folder = null;
		this.exec = function(it)
		{
			ret = [];
			folder = null;
			if ( fl.exists == false) return ret;
			var io = new ImportOptions(fl);
			if ( io.canImportAs(it) == true){
				io.importAs = it;
				try{
					cmp = app.project.importFile(io);
					if ( cmp.numLayers>0){
						folder = cmp.layer(1).source.parentFolder;
						for (var i=1; i<=folder.numItems;i++){
							var t = folder.item(i);
							if ( t instanceof FootageItem){
								var o = getStatus(t);
								if ( o.layerName != ""){
									ret.push(o);
								}
							}
						}
					}
					//コンポはいらないから消す。
					if ( cmp != null) cmp.remove();
					
					if ( folder != null)
						if ( folder instanceof FolderItem)
							if (folder.numItems>0)
								for ( var i=folder.numItems; i>=1; i--)
									if ( folder.item(i) instanceof CompItem)
										folder.item(i).remove();
					return ret;
					
				}catch(e){
					alert(e);
				}
			}
			return ret;
		}
		this.footages = function() {return ret;}
		this.footagesParent = function() {return folder;}
	}
	//-----------------------------------------------------------------
	
	if (theFile.exists == false) return -1;
	

	var mode = false;
	if ( (allMode==undefined)||(allMode==null)){
		mode = false;
	}else{
		mode = allMode;
	}

	//同じファイルのフッテージをリストアップ
	var targets = [];
	if (psdFtg instanceof Array){
		targets = targetsChk(psdFtg);
	}else if (psdFtg instanceof FootageItem){
		if ( mode == true){
			targets = listupSameFullName(psdFtg);
		}else{
			targets = targetsChk(new Array(psdFtg));
		}
	}
	if ( targets.length<=0) return -2;
	
	//同じファイルなら中止
	if ( targets[0].footage.file.fullName == theFile.fullName ) return -3;

	//psdファイルをインポートして登録
	var newFtg = [];
	var psd = new importPSD(theFile);
	newFtg = psd.exec(ImportAsType.COMP);
	var cmpF = psd.footagesParent();
	var a = psd.exec(ImportAsType.COMP_CROPPED_LAYERS);
	if ( a.length>0)
		newFtg = newFtg.concat(a);
	var cmpCropF = psd.footagesParent();

	if (newFtg.length<=0) return -6;
	
	//フッテージ名から探す
	for ( var i=0; i<targets.length; i++){
		for ( var j=0; j<newFtg.length; j++){
			if ( newFtg[j].layerName == targets[i].layerName){
				if ( (newFtg[j].width == targets[i].width)&&(newFtg[j].height == targets[i].height)){
					newFtg[j].footage.parentFolder = targets[i].footage.parentFolder;
					useChange(targets[i].footage,newFtg[j].footage);
					targets[i].repFlag = true;
					newFtg[j].repFlag = true;
				}
			}
		}
	}
	//必要なくなったターゲットを消す
	for ( var i=targets.length-1; i>=0; i--){
		if ( (targets[i].repFlag == true)&&(targets[i].footage.usedIn.length<=0)) {
			targets[i].footage.remove();
			targets[i] = null;
		}
	}
	//使われなかったnewFtgを消す。
	for ( var i=newFtg.length-1; i>=0; i--){
		if ((newFtg[i].footage.usedIn.length<=0)) {
			newFtg[i].footage.remove();
			newFtg[i] = null;
		}
	}
	
	//フォルダを消す。
	if ( cmpF.numItems<=0) cmpF.remove();
	if ( cmpCropF.numItems<=0) cmpCropF.remove();
	var cnt = 0;
	//var ary = [];
	for ( var i=0; i<targets.length; i++){
		if ( targets[i] != null) {
			cnt++;
			//ary.push(targets[i]);
		}
	}
	//返り値は指し変わらなかった数。
	//つまり0なら全部差し替わった。
	//return ary;
	return cnt;
}
//*************************************************************************
//レイヤ付きファイルから、指定したレイヤだけをインポートするもの
/*
	theFile		読み込むファイル
	layerName	読み込む
	
	成功すればインポートされたフッテージが返る。失敗時はnull;
*/

Project.prototype.importLayeredFile = function(theFile,layerName,itComp)
{
	//-----------------------------------------------------------------
	function getLayerName(s){
		if ( s == "") return "";
		var i=s.lastIndexOf("/");
		if (i>=0) {
			//aaaaa/bb.psd
			//0123456789AB
			return s.substring(0,i);
		}else{
			return "";
		}
		return ret;
	}
	//-----------------------------------------------------------------
	if ((theFile == null)||(theFile.exists==false)||( (theFile instanceof File)==false)) return null;
	if ( layerName == "") return null;
	var mc = ImportAsType.COMP;
	if ( (itComp != null)&&(itComp != undefined)){
		if ( typeof(itComp) == "boolean") mc = itComp;
	}
	if ( mc == false) mc = ImportAsType.COMP_CROPPED_LAYERS;
	var io = new ImportOptions(theFile);
	if ( io.canImportAs(mc)==false) return null;
	io.importAs = mc;
	try{
		var ftg = null;
		var cmp = app.project.importFile(io);
		if ( cmp.numLayers>0){
			var fld = cmp.layer(1).source.parentFolder;
			var tName = layerName + "/"+theFile.name;
			for(var i=1; i<=fld.numItems; i++){
				var t = fld.item(i);
				if ( t instanceof FootageItem)
					if ( t.name == tName){
						ftg = t;
						t.parentFolder = app.project.rootFolder;
						break;
					}
			}
			if ( fld.numItems>0){
				for(var i=fld.numItems; i>=1; i--){
					fld.item(i).remove();
				}
			}
			fld.remove();
			if ( cmp != null) cmp.remove();
		}
		if ( ftg != null) ftg.selected = true;
		return ftg;
	}catch(e){
		return null;
	}
}
//*************************************************************************
//確認用のコード
//*************************************************************************
me = this;
//-------------------------------------------------------------------------
var winObj = ( me instanceof Panel) ? me : new Window("palette", "実験", [ 800,  396,  800+ 311,  396+ 228] );
//-------------------------------------------------------------------------
var edInfo1 = winObj.add("edittext", [  26,   12,   26+ 268,   12+  67], "レイヤー付きPSDのフッテージのFile差し替えのテスト。\n\n差し替えしたいフッテージを選択して実行。", { multiline:true });
edInfo1.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
var btnExec = winObj.add("button", [  26,   86,   26+ 110,   86+  23], "差し替え実行" );
btnExec.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
var edInfo2 = winObj.add("edittext", [  26,  137,   26+ 268,  137+  34], "指定したレイヤだけをインポートする実験。", { multiline:true });
edInfo2.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
var stLayerName = winObj.add("statictext", [  26,  189,   26+  49,  189+  14], "レイヤ名");
stLayerName.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
edLayerName = winObj.add("edittext", [  81,  185,   81+ 100,  185+  21], "レイヤー 1");
edLayerName.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
var btnExecImport = winObj.add("button", [ 187,  185,  187+ 110,  185+  23], "インポート" );
btnExecImport.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);

btnExec.onClick = function()
{
	var sel = app.project.selection.getLayered();
	if ( sel.length>0){
		var f = File.openDialog("psd");
		if ( f != null){
			var c = app.project.psdChangeFile(sel,f);
			if ( c<0) alert("エラー");
			else if ( c>0) alert(c + "個のフッテージが差し替え出来なかった");
			else alert("成功");
		}
	}
}
btnExecImport.onClick = function()
{
	var ln = edLayerName.text;
	if ( ln == "") {
		alert("レイヤ名を指定して下さい。");
		return;
	}
	var f = File.openDialog("psd");
	
	if ( f != null)
		if ( app.project.importLayeredFile(f,ln) == null)
			alert("インポート失敗！")
}
//-------------------------------------------------------------------------
if ( ( me instanceof Panel) == false){
	winObj.center(); 
	winObj.show();
}
//-------------------------------------------------------------------------
 