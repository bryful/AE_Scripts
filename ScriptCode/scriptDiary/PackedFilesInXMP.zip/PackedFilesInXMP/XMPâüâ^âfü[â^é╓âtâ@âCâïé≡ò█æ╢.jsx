﻿
(function(me){

	//XMPを使うときのおまじない
	if (ExternalObject.AdobeXMPScript == undefined) {
		ExternalObject.AdobeXMPScript = new
		ExternalObject('lib:AdobeXMPScript');
	}
	//xmp関係
	var myNamespace = XMPMeta.getNamespaceURI("xmp");
	var myFilename = "xmp:adata_filename";
	var myData =  "xmp:adata_contents";

	//自動読み込みのターゲット拡張子。小文字で表記
	var targetEXT = [".xps",".sts",".tsh",".ard",".ardj"];
	//-------------------------------------------------------------------------
	function setupXMP()
	{

		try{
			var mdata = new XMPMeta(app.project.xmpPacket);
			var b = false;
			if (mdata.doesPropertyExist(myNamespace, myFilename)== false){
				mdata.setProperty(myNamespace, myFilename,null,XMPConst.PROP_IS_ARRAY);
				b = true;
			}
			if (mdata.doesPropertyExist(myNamespace, myData)== false) {
				mdata.setProperty(myNamespace, myData,null,XMPConst.PROP_IS_ARRAY);
				b = true;
			}
			if ( b) app.project.xmpPacket = mdata.serialize();
	
		}catch(e){
			alert("setupXMP()\n" +e);
		}
	}
	//-------------------------------------------------------------------------
	function clearXMP()
	{
		try{
			var mdata = new XMPMeta(app.project.xmpPacket);
			if (mdata.doesPropertyExist(myNamespace, myFilename)== true){
				mdata.deleteProperty(myNamespace, myFilename);
				b = true;
			}
			if (mdata.doesPropertyExist(myNamespace, myData)== true) {
				mdata.deleteProperty(myNamespace, myData);
				b = true;
			}
			if ( b) app.project.xmpPacket = mdata.serialize();
		}catch(e){
			alert("clearXMP()\n" +e);
		}
	}

	//-------------------------------------------------------------------------
	function appendXMP(name,data)
	{
		try{
			var mdata = new XMPMeta(app.project.xmpPacket);
			if (mdata.doesPropertyExist(myNamespace, myFilename)== false){
				mdata.setProperty(myNamespace, myFilename,null,XMPConst.PROP_IS_ARRAY);
			}
			mdata.appendArrayItem(myNamespace, myFilename,escape(name));
			
			if (mdata.doesPropertyExist(myNamespace, myData)== false) {
				mdata.setProperty(myNamespace, myData,null,XMPConst.PROP_IS_ARRAY);
			}
			mdata.appendArrayItem(myNamespace, myData,escape(data));
			app.project.xmpPacket = mdata.serialize();
		}catch(e){
			alert("appendXMP()\n" +e);
		}
	}
	//-------------------------------------------------------------------------
	function insertXMP(name,data,index)
	{
		try{
			var mdata = new XMPMeta(app.project.xmpPacket);
			mdata.insertArrayItem(myNamespace, myFilename,index,escape(name));
			mdata.insertArrayItem(myNamespace, myData,index,escape(data));
			app.project.xmpPacket = mdata.serialize();
		}catch(e){
			alert("insertXMP()\n" +e);
		}
	}
	//-------------------------------------------------------------------------
	function getXMP(index)
	{
		var ret = new Object;
		try{
			var mdata = new XMPMeta(app.project.xmpPacket);
			ret.name = unescape(mdata.getArrayItem(myNamespace, myFilename,index));
			ret.data = unescape(mdata.getArrayItem(myNamespace, myData,index));
		}catch(e){
			alert("getXMP()\n" +e);
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function deleteXMP(index)
	{
		try{
			var mdata = new XMPMeta(app.project.xmpPacket);
			mdata.deleteArrayItem(myNamespace, myFilename,index);
			mdata.deleteArrayItem(myNamespace, myData,index);
			app.project.xmpPacket = mdata.serialize();
		}catch(e){
			alert("deleteXMP()\n" +e);
		}
	}
	//-------------------------------------------------------------------------
	function listCount()
	{
		var mdata = new XMPMeta(app.project.xmpPacket);
		return mdata.countArrayItems(myNamespace, myFilename);
	}
	//-------------------------------------------------------------------------
	function getList()
	{
		var ret = [];
		var mdata = new XMPMeta(app.project.xmpPacket);
		var cnt = mdata.countArrayItems(myNamespace, myFilename);
		if ( cnt>0){
			for ( var i=1; i<=cnt; i++){
				var s = mdata.getArrayItem(myNamespace, myFilename,i);
				ret.push( unescape(s));
			}
		} 
		return ret;
	}
	//-------------------------------------------------------------------------
	function findSameName(name)
	{
		var ret = 0;
		var lst = getList();
		if ( lst.length>0){
			for ( var i=0;i<lst.length;i++){
				if ( name == lst[i]) {
					ret = i+1;
					break;
				}
			}
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	var winObj = ( me instanceof Panel) ? me : new Window("palette", "xmpメタデータへファイルを保存", [0,  0, 260, 330]  ,{resizeable:true, maximizeButton:true, minimizeButton:true});
	//-------------------------------------------------------------------------
	var btnAdd = winObj.add("button", [  10,   10,   10+ 240,   10+  30], "追加" );
	var stAuto = winObj.add("statictext", [  10,   50,   10+ 190,   50+  20], "xps/tsh/sts/ard/ardj/自動読み込み");
	var btnAuto = winObj.add("button", [ 200,   45,  200+  50,   45+  30], "自動" );

	var btnGET = winObj.add("button", [  10,   80,   10+  50,   80+  30], "表示" );
	var btnDEL = winObj.add("button", [  10,  230,   10+  50,  230+  30], "消去" );

	var dataListbox = winObj.add("listbox", [  65,   80,   65+ 185,   80 + 180], [] );
	var btnOutput = winObj.add("button", [  65,  265,   65+ 185,  265+  30], "書き出し" );
	
	var stWarning = winObj.add("statictext", [  10,  300,   10+ 240,  300+  30], "出力モジュール設定でXMP保存はOFFで！");

	btnAdd.onClick = setupXMP;
	btnDEL.onClick = clearXMP;
	var selectedIndex = -1;
	//-------------------------------------------------------------------------
	function chk()
	{
		selectedIndex = -1;
		if ( dataListbox.selection != null) selectedIndex = dataListbox.selection.index;
	}
	//-------------------------------------------------------------------------
	dataListbox.onChange = function()
	{
		chk();
	}
	//-------------------------------------------------------------------------
	dataListbox.onClick = function()
	{
		chk();
	}
	//-------------------------------------------------------------------------
	function resizeWin()
	{	
		var b = winObj.bounds;
		
		if ( ( me instanceof Panel) == false){
			if (b.width<250) b.width = 250;
			if (b.height<300) b.height = 300;
			winObj.bounds = b;
		}
		
		var a = btnAuto.bounds;
		a[2] = b.width-10;
		btnAuto.bounds = a;
		

		var a = btnAdd.bounds;
		a[2] = b.width-10;
		btnAdd.bounds = a;

		var a = dataListbox.bounds;
		a[2] = b.width-10;
		a[3] = b.height-70;
		dataListbox.bounds = a;

		var a = btnOutput.bounds;
		a[2] = b.width-10;
		a[1] = b.height-65;
		a[3] = b.height-35;
		btnOutput.bounds = a;

		var a = btnDEL.bounds;
		a[1] = b.height-100;
		a[3] = b.height-70;
		btnDEL.bounds = a;



		var a = stWarning.bounds;
		a[2] = b.width-10;
		a[1] = b.height-30;
		a[3] = b.height;
		stWarning.bounds = a;
	}
	resizeWin();
	winObj.onResize = resizeWin;
	//-------------------------------------------------------------------------
	function getFileName()
	{
		chk();
		dataListbox.removeAll();
		
		var ret = getList();
		
		if ( ret.length>0)
		{
			for ( var i=0; i<ret.length;i++) dataListbox.add("item",ret[i]);
			if (selectedIndex>=0) {
				if (selectedIndex<dataListbox.items.length){
					dataListbox.items[selectedIndex].selected = true;
				}else{
					selectedIndex　=dataListbox.items.length -1;
				}
				}
		}
		chk();
	}
	btnGET.onClick = getFileName;
	//-------------------------------------------------------------------------
	function deleteItem()
	{
		chk();
		if ( selectedIndex<0) {
			if ( listCount()==0) {
				clearXMP();
				dataListbox.removeAll();
				alert("項目をすべて削除しました");
			}
			return;
		}
		deleteXMP(selectedIndex+1);
		getFileName();
	}
	btnDEL.onClick = deleteItem;
	//-------------------------------------------------------------------------
	function addFile(f)
	{
		var ret = false;
		if ( !(f instanceof File)) return ret;
		if ( f.exists == false) return ret;

		f.open("r");
		try{
			f.encoding = "BINARY";
			s = f.read();
			if  ( s !="") {
				var fn = File.decode(f.name);
				var idx = findSameName(fn);
				if ( idx <=0){
					appendXMP(fn,s);
				}else{
					insertXMP(fn,idx,s);
				}
				ret = true;
			}
		}catch(e){
			ret  =false;
			return ret;
		}finally{
			f.close();
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function autoImport()
	{
		var f = app.project.file;
		if ( f== null) {
			alert("プロジェクトを保存してください");
			return;
		}
		var files = f.parent.getFiles();
		var targets = []
		//ターゲットのファイルを抜き出す。
		if ( files.length>1){
			for ( var i=0; i<files.length;i++){
				if ( files[i] instanceof File)
				{
					var idx = files[i].name.lastIndexOf(".");
					if ( idx>0) {
						var e = files[i].name.substr(idx).toLowerCase();
						for ( var k=0; k<targetEXT.length; k++)
						{
							if ( e == targetEXT[k]){
								targets.push( files[i]);
								break;
							}
						}
					}
				}
			}
		}
		if ( targets.length>0){
			for ( var i=0; i<targets.length;i++){
				addFile(targets[i]);
			}
			getFileName();
		}
		
	}
	btnAuto.onClick = autoImport;
	//-------------------------------------------------------------------------
	var savePath = "";
	function outFile()
	{
		chk();
		if ( selectedIndex>=0){
			var d = getXMP(selectedIndex+1);
			var ff = new File(savePath +"/" + d.name);
			var f = ff.saveDlg();
			if (f!=null){
				f.open("w");
				try{
					f.encoding = "BINARY";
					f.write((d.data));
					savePath = f.parent.fullName;
				}catch(e){
				}finally{
					f.close();
				}
			}
		}
	}
	btnOutput.onClick = outFile;
	//-------------------------------------------------------------------------
	function execAdd()
	{
		var f = File.openDialog();
		if ( f != null) 
			if (addFile(f))
					getFileName();

	}
	btnAdd.onClick = execAdd;
	//-------------------------------------------------------------------------
	if ( ( me instanceof Panel) == false){
		winObj.center(); 
		winObj.show();
	}
	//-------------------------------------------------------------------------
})(this);