﻿var shapeLayerIO = new Object;
shapeLayerIO.SHP = null;
shapeLayerIO.text = "";;
shapeLayerIO.activeComp = null;
shapeLayerIO.newLayer = null;

//----------------------------------
shapeLayerIO.init = function()
{
	this.activeComp = null;
	this.newLayer = null;
	
	var ac = app.project.activeItem;
	if ((ac == null)||( ( ac instanceof CompItem)==false)) {
		alert("コンポを選択してちょ");
		return false;
	}
	this.activeComp = ac;
	return true;
}
//----------------------------------
shapeLayerIO.loadAsDialog = function()
{
	this.SHP = null;
	this.text = "";
	var fileObj = File.openDialog("Import ShapeLayer file","*.shp");
	if (fileObj == null){
		alert("cancel");
		return false;
	}else if (fileObj.exists == false){
		alert("file none!");
		return false;
	}
	var flag = fileObj.open("r");
	if (flag == true)
	{
		try
		{
			this.text = fileObj.read();
			fileObj.close();
			this.SHP = eval(this.text);
		}catch(e){
			alert("file load error!");
			return false;
		}
	}else{
		alert("file error!");
		return false;
	}
	
	return ( this.SHP != null);
}
//----------------------------------
shapeLayerIO.findProperty = function(p,n)
{
	if ( p==null) {
		return null;
	}
	if ( p.numProperties>0){
		for ( var i=1; i<=p.numProperties;i++)
		{
			if ( (p.property(i).name == n.name)&&(p.property(i).matchName == n.matchName))
			{
				return p.property(i);
			}
		}
	}
	if ( p.canAddProperty(n.matchName)==true){
		var ret = p.addProperty(n.matchName);
		try{
			if ( n.matchName != n.name)
				ret.name = n.name;
		}catch(e){
		}
		return ret;
	}else{
		return null;
	}
}
//----------------------------------
shapeLayerIO.setPro = function(p,o)
{
	if ( (p==null)||(o==null)) return;
	
	if ( o.isProperty ==true)
	{
		var pro = p;
		if ( (o.propertyValueType != null)&&(o.propertyValueType != undefined)){
			try{
				switch(o.propertyValueType)
				{
					case PropertyValueType.NO_VALUE:
						break;
					case PropertyValueType.ThreeD_SPATIAL:
					case PropertyValueType.ThreeD:
						pro.setValue(o.pos3D);
						break;
					case PropertyValueType.TwoD_SPATIAL:
					case PropertyValueType.TwoD:
						pro.setValue(o.pos2D);
						break;
					case PropertyValueType.OneD:
						pro.setValue(o.pos1D);
						break;
					case PropertyValueType.COLOR:
						pro.setValue(o.color);
						break;
					case PropertyValueType.CUSTOM_VALUE:
						break;
					case PropertyValueType.MARKER_MarkerValue:
						break;
					case PropertyValueType.LAYER_INDEX:
						pro.setValue(o.value);
						break;
					case PropertyValueType.MASK_INDEX:
						pro.setValue(o.value);
						break;
					case PropertyValueType.SHAPE:
						var sp = new Shape();
						sp.closed = o.closed;
						sp.vertices = o.vertices;
						sp.inTangents = o.inTangents;
						sp.outTangents = o.outTangents;
						pro.setValue(sp);
						break;
					case PropertyValueType.TEXT_DOCUMENT:
						break;
				}
			}catch(e){
			}
		}
	}else{
		if (o.numProperties>0){
			for (var i=0; i<o.pList.length; i++)
			{
				var pro = o[o.pList[i]];
				var pb = this.findProperty(p,pro);
				if (pb != null){
					this.setPro(pb,pro);
				}else{
				}
			}
		}
	}
}
//----------------------------------
shapeLayerIO.run = function()
{
	if (this.init()==false) return;
	if (this.loadAsDialog() == false) return;

	if ( (this.SHP.header==undefined)||(this.SHP.header==null)||(this.SHP.header!="bry-ful's shape object")){
		alert( "header error!");
		return;
	}
	this.newLayer = this.activeComp.layers.addShape();
	
	if ( (this.SHP.layerName != null)&&(this.SHP.layerName != undefined)){
		this.newLayer.name = this.SHP.layerName;
	}
	
	if ( this.SHP["ADBE Root Vectors Group"] != undefined){
		this.setPro(this.newLayer.property("ADBE Root Vectors Group"),this.SHP["ADBE Root Vectors Group"]);
	}
	
}
//----------------------------------
shapeLayerIO.run();
