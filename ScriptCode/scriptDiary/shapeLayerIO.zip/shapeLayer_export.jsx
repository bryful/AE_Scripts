﻿/*
	選択したシェイプレイヤーのプロパティを書きだす
	このバージョンではプロパティの値ではなく、matchnameとnameを出力
*/
//---------------------------------------------------------------------------

var shapeLayerIO = new Object;
shapeLayerIO.time = 0;
//---------------------------------------------------------------------------
shapeLayerIO.getName = function(tp)
{
	if ( tp instanceof Property){
		return tp.matchName;
	}else{
		try{
			var nm = tp.name;
			tp.name = "_____-----_____";
			tp.name = nm;
		}catch(e){
			return tp.matchName;
		}
		return tp.name;
	}
}
//---------------------------------------------------------------------------
shapeLayerIO.getPro = function(aobj,tp)
{
	var tag = this.getName(tp);
	if (tp instanceof Property){
		aobj[tag] = new Object;
		aobj[tag].name = tp.name;
		aobj[tag].matchName = tp.matchName;
		aobj[tag].isProperty = true;
		aobj[tag].propertyValueType = tp.propertyValueType;
		switch(tp.propertyValueType)
		{
			case PropertyValueType.TEXT_DOCUMENT:
			case PropertyValueType.MARKER_MarkerValue:
			case PropertyValueType.CUSTOM_VALUE:
			case PropertyValueType.NO_VALUE:
				delete aobj[tag];
				break;
			case PropertyValueType.ThreeD_SPATIAL:
			case PropertyValueType.ThreeD:
				aobj[tag].pos3D = tp.valueAtTime(this.time,true);
				break;
			case PropertyValueType.TwoD_SPATIAL:
			case PropertyValueType.TwoD:
				aobj[tag].pos2D = tp.valueAtTime(this.time,true);
				break;
			case PropertyValueType.OneD:
				aobj[tag].pos1D = tp.valueAtTime(this.time,true);
				break;
			case PropertyValueType.COLOR:
				aobj[tag].color = tp.valueAtTime(this.time,true);
				break;
			case PropertyValueType.LAYER_INDEX:
				aobj[tag].value = tp.valueAtTime(this.time,true);
				break;
			case PropertyValueType.MASK_INDEX:
				aobj[tag].value = tp.valueAtTime(this.time,true);
				break;
			case PropertyValueType.SHAPE:
				var sp = tp.valueAtTime(this.time,true);
				aobj[tag].closed = sp.closed;
				aobj[tag].vertices = sp.vertices;
				aobj[tag].inTangents = sp.inTangents;
				aobj[tag].outTangents = sp.outTangents;
				break;
		}
	}else if (tp instanceof PropertyGroup){
		aobj[tag] = new Object;
		aobj[tag].name = tp.name;
		aobj[tag].matchName = tp.matchName;
		aobj[tag].pList = new Array;
		aobj[tag].isProperty = false;
		aobj[tag].numProperties = tp.numProperties;
		if (tp.numProperties>0){
			for(var i=1; i<=tp.numProperties; i++){
				this.getPro(aobj[tag],tp.property(i));
				aobj[tag].pList.push(this.getName(tp.property(i)));
			}
		}
	}
}
//---------------------------------------------------------------------------
shapeLayerIO.exportProperties = function(lyr)
{
	var obj = new Object;
	obj.header = "bry-ful's shape object";
	obj.layerName = lyr.name;
	
	if ( lyr.property("ADBE Root Vectors Group") !=null){
		this.getPro(obj, lyr.property("ADBE Root Vectors Group"));
		var myJson = obj.toSource();
	
		var fileObj = File.saveDialog("*.shp");
		if (fileObj  != null){
			var flag = fileObj.open("w");
			if (flag == true)
			{
				try{
					fileObj.write(myJson);
					fileObj.close();
				}catch(e){
				}
			}
		}
	}
}
//---------------------------------------------------------------------------
shapeLayerIO.run = function()
{
	var activeComp = app.project.activeItem;
	if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
		
		this.time = activeComp.time;
		var selectedLayers = activeComp.selectedLayers;
	
		if ( (selectedLayers!=null)&&(selectedLayers.length==1) ){
			this.exportProperties(selectedLayers[0]);
		}else{
		//エラー処理
			alert("シェイプレイヤを一つだけ選択してね?")
		}
	}
}
//---------------------------------------------------------------------------
shapeLayerIO.run();
