﻿//---------------------------------------------------------------------------
/*
	ファイル名を分割する
*/
//---------------------------------------------------------------------------
function splitFileName(name)
{
	var ret = new Object;
	
	ret.all = name;
	if (name.match(/(.*?)(\d*)(\.(.+)?)/)){
		ret.err		= false;
		ret.node	= RegExp.$1;
		ret.frame	= RegExp.$2;
		ret.ext		= RegExp.$3;
	}else{
		ret.err		= true;
		ret.node	= "";
		ret.frame	= "";
		ret.ext		= "";
	}
	return ret;
}
//---------------------------------------------------------------------------
//選択したフッテージにに何かする
//---------------------------------------------------------------------------
function ftg_util(tFtg)
{
	this.fileList	= new Array;
	this.newNode	= "";
	this.parent		= null;
	
	this.dialog		= null;
	this.edName1	= null;
	this.edName2	= null;
	//-----------
	this.listupFiles = function()
	{
		if (this.enabled){
			if (this.isStill) {
				this.fileList = this.parent.getFiles(this.name);
			}else{
				this.fileList = this.parent.getFiles(this.node +"*" + this.ext);
			}
			if ( this.fileList.length>0) {
				var mnS = "";
				var mxS = "";
				var mn = 99999;
				var mx = 0;
				for (var i=0; i<this.fileList.length; i++){
					var o = splitFileName(this.fileList[i].name);
					if (o.frame*1 > mx) {
						mx = o.frame*1;
						mxS = o.frame;
					}
					if (o.frame*1 < mn) {
						mn = o.frame*1;
						mnS = o.frame;
					}
				}
				this.frameMin	=mnS;
				this.frameMax	=mxS;
			}
		}else{
			this.fileList = new Array;
			this.frameMin	="";
			this.frameMax	="";
		}
	}
	//-----------
	this.setFtg	= function(ftg)
	{
		if ((ftg != null)&&(ftg.file != null)) {
			this.enabled = true;
			var fn = splitFileName(ftg.file.name);
			this.name		= fn.all;
			this.node		= fn.node;
			this.frame		= fn.frame;
			this.ext		= fn.ext;
			this.parent		= ftg.file.parent;
			this.footage	= ftg;
			this.isStill	= ftg.mainSource.isStill;
		}else{
			this.enabled = false;;
			this.name		= "";
			this.node		= "";
			this.frame		= "";
			this.ext		= "";
			this.parent		= null;
			this.footage	= null;
			this.isStill	= false;
		}
		this.frameMin	="";
		this.frameMax	="";
		return this.enabled;
	}
	//-------------------------------------------------
	this.getValue = function()
	{
		var s = this.edName2.text;
		var c = s[s-1];
		if ((c>="0")&&(c<="9")) s+="_";
		this.newNode = s;
		if ( (this.newNode == "")||(this.newNode == this.node)){
			return false;
		}else{
			return true;
		}
	}
	//-------------------------------------------------
	this.buildAndShowDialog = function ()
	{
		this.dialog = new Window("dialog","ファイルのリネーム");
		this.dialog.bounds = [0,0,290,130];
		this.dialog.center();
		var st1			= this.dialog.add("statictext", [  30, 25, 30+ 80, 25+12], "元のファイル名");
		var st2			= this.dialog.add("statictext", [  30, 50, 30+ 80, 50+12], "新しいファイル名");
		this.edName1	= this.dialog.add("edittext"  , [ 118, 22,118+137, 22+19], this.node);
		this.edName1.readonly = true;
		this.edName2	= this.dialog.add("edittext"  , [ 118, 47,118+137,47+19], this.node);

		var okBtn    	= this.dialog.add("button",	[ 41,94, 41+100,94+24], "OK",     {name:'ok'} );
		var cancelBtn	= this.dialog.add("button",	[154,94,154+100,94+24], "Cancel", {name:'cancel'});
		return this.dialog.show();
	}
	//-------------------------------------------------
	this.execute = function()
	{
		if (this.enabled == false) {
			alert("有効なフッテージが選択されていません。");
		}
		while (true){
			var r=this.buildAndShowDialog();
			if (r==1){
				if (this.getValue()==true){
					//this.getValue()がfalseを返せば、またダイアログが表示される。
					this.listupFiles();
					if (this.fileList.length>0) {
						for (var i=0;i<this.fileList.length;i++){
							var fn = splitFileName(this.fileList[i].name);
							this.fileList[i].rename(this.newNode + fn.frame+fn.ext);
						}
						
						//再読み込みする
						if (this.isStill){
							this.footage.replace(this.fileList[0]);
							this.footage.name = this.newNode+this.frame+this.ext;
						}else{
							this.footage.replaceWithSequence(this.fileList[0], false);
							this.footage.name = this.newNode+"["+this.frameMin +"-"+this.frameMax+"]"+this.ext;
						}
					}
					return true;
				}
			}else{
				return false;
			}
		}
	}
	//-------------------------------------------------
	this.setFtg(tFtg);
}
//---------------------------------------------------------------------------
var selectedItems = app.project.selection;
if ( (selectedItems!=null)&&(selectedItems.length>0) ) {
	app.beginUndoGroup("連番フッテージをリネーム");
	var ftgUtil = new ftg_util(null);
	for (var i = 0; i < selectedItems.length; i++) {
		if (selectedItems[i] instanceof FootageItem) {
			if (ftgUtil.setFtg(selectedItems[i])==true){
				ftgUtil.execute();
			}else{
				//エラー処理
			}
		}
	}
	app.endUndoGroup();
}else{
	//エラー処理
}
//---------------------------------------------------------------------------
