﻿/*
	AE_DragAndDropのサンプルスクリプト
*/
//----------------------------------------------------------------
//関数名は変更しない
function _fileArrayFunc(ary)
{
	//-----------------------------------
	//引数のチェック
	if ( ( ary instanceof Array)==false) return;

	//-----------------------------------
	var ret = "";
	if ( ary.length<=0) {
		ret ="no Files";
	}else{
		app.beginUndoGroup("ファイルを静止画としてインポート");

		//自作インポートクラス
		var FsImport = new FsImporter;
		
		//インポートするフォルダを作成。返り値は配列なので注意
		var importFolders = FsImport.findFolderByPathArray(["Import","Footage"]);
		
		var targetFolder = null;
		for ( var i=0; i< ary.length; i++){
			if ( ary[i] instanceof Folder) {
				targetFolder =  ary[i];
				break;
			}
		}
		if (targetFolder == null){
			alert("フォルダが選択されていません");
		}else{
			var pfs = new FsPictureFiles;
			if ( pfs.listup(targetFolder)==true){
				var cnt = pfs.count();
				for ( var i=0; i<cnt; i++){
					FsImport.import(pfs.importOptions(i),importFolders[0]);
				}
			}else{
				alert("読み込む画像がない");
			}
		}
		
		app.endUndoGroup();
	}
}
//----------------------------------------------------------------

