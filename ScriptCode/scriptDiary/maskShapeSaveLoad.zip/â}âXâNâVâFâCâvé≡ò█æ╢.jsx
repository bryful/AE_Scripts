﻿//選択したマスクシェイプを保存
//---------------------------------------------------------------------------
function shapeData(sp)
{
	var maskShape = null;
	//-------------------------------
	this.setValue = function(ms)
	{
		if ( ms instanceof Shape)
		{
			maskShape = ms
		}else{
			maskShape = null;
		}
	}
	//-------------------------------
	//コンストラクタの処理
	this.setValue(sp);
	//-------------------------------
	this.getValue = function()
	{
		return maskShape;
	}
	//-------------------------------
	this.toLine = function()
	{
		var line = "";
		if (maskShape == null) return line;
		for ( var i=0; i<maskShape.vertices.length; i++)
		{
			line += maskShape.vertices[i][0] + ",";
			line += maskShape.vertices[i][1] + ",";
		}
		for ( var i=0; i<maskShape.inTangents.length; i++)
		{
			line += maskShape.inTangents[i][0] + ",";
			line += maskShape.inTangents[i][1] + ",";
		}
		var ot = new Array;
		for ( var i=0; i<maskShape.outTangents.length; i++)
		{
			line += maskShape.outTangents[i][0] + ",";
			line += maskShape.outTangents[i][1] +",";
		}
		line += maskShape.closed +"";
		return line;
	}
	//-------------------------------
	this.fromLine = function(s)
	{
		maskShape = null;
		if ( s == "") return maskShape;
		var sa = s.split(",");
		
		var cl = true;
		if ( sa[sa.length-1] == "false") cl = false;
		
		var cnt = Math.floor((sa.length-1) / (3*2));
		var offset = cnt * 2;
		var vt = new Array;
		
		var p = 0;
		for ( var i=0; i<cnt; i++){
			var o = new Array;
			o.push(sa[p]*1);p++;
			o.push(sa[p]*1);p++;
			vt.push(o);
		}
		var it = new Array;
		for ( var i=0; i<cnt; i++){
			var o = new Array;
			o.push(sa[p]*1);p++;
			o.push(sa[p]*1);p++;
			it.push(o);
		}
		var ot = new Array;
		for ( var i=0; i<cnt; i++){
			var o = new Array;
			o.push(sa[p]*1);p++;
			o.push(sa[p]*1);p++;
			ot.push(o);
		}
		maskShape = new Shape;
		maskShape.vertices = vt;
		maskShape.inTangents = it;
		maskShape.outTangents = ot;
		maskShape.closed = cl;
		return maskShape;
	}
}

//---------------------------------------------------------------------------


var targetMask = null;
var activeComp = app.project.activeItem;
if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
	var selectedLayers = activeComp.selectedLayers;

	if ( (selectedLayers!=null)&&(selectedLayers.length == 1) ){
		var maskG = selectedLayers[0].mask;
		if ( maskG.numProperties>0) {
			var mk = null
			for ( var i=1; i<maskG.numProperties; i++)
			{
				if ( maskG(i).selected == true)
				{
					mk = maskG(i).maskShape;
					break;
				}
			}
			if (mk == null) mk = maskG(1).maskShape;
			if (mk.numKeys >0){
				for ( var i=1; i<mk.numKeys; i++)
				{
					if ( mk.keySelected(i) == true) {
						targetMask = mk.keyValue(i);
						break;
					}
				}
				//if (targetMask == null) targetMask = mk.keyValue(1);
			}else{
				targetMask = mk.value;
			}
		}
	}
}
if ( targetMask != null){
	var sd = new shapeData(targetMask);

	if ( sd.getValue() != null){
		var f = File.saveDialog("マスクパスの保存","*.mask");
		if ( f != null){
			f.open("w");
			f.write( sd.toLine());
			f.close();
		}
	}
}else{
	alert("マスクパスを選択してください。");
}
