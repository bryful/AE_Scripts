﻿//選択したマスクシェイプを保存
//---------------------------------------------------------------------------
function shapeData(sp)
{
	var maskShape = null;
	//-------------------------------
	this.setValue = function(ms)
	{
		if ( ms instanceof Shape)
		{
			maskShape = ms
		}else{
			maskShape = null;
		}
	}
	//-------------------------------
	//コンストラクタの処理
	this.setValue(sp);
	//-------------------------------
	this.getValue = function()
	{
		return maskShape;
	}
	//-------------------------------
	this.toLine = function()
	{
		var line = "";
		if (maskShape == null) return line;
		for ( var i=0; i<maskShape.vertices.length; i++)
		{
			line += maskShape.vertices[i][0] + ",";
			line += maskShape.vertices[i][1] + ",";
		}
		for ( var i=0; i<maskShape.inTangents.length; i++)
		{
			line += maskShape.inTangents[i][0] + ",";
			line += maskShape.inTangents[i][1] + ",";
		}
		var ot = new Array;
		for ( var i=0; i<maskShape.outTangents.length; i++)
		{
			line += maskShape.outTangents[i][0] + ",";
			line += maskShape.outTangents[i][1] +",";
		}
		line += maskShape.closed +"";
		return line;
	}
	//-------------------------------
	this.fromLine = function(s)
	{
		maskShape = null;
		if ( s == "") return maskShape;
		var sa = s.split(",");
		
		var cl = true;
		if ( sa[sa.length-1] == "false") cl = false;
		
		var cnt = Math.floor((sa.length-1) / (3*2));
		var offset = cnt * 2;
		var vt = new Array;
		
		var p = 0;
		for ( var i=0; i<cnt; i++){
			var o = new Array;
			o.push(sa[p]*1);p++;
			o.push(sa[p]*1);p++;
			vt.push(o);
		}
		var it = new Array;
		for ( var i=0; i<cnt; i++){
			var o = new Array;
			o.push(sa[p]*1);p++;
			o.push(sa[p]*1);p++;
			it.push(o);
		}
		var ot = new Array;
		for ( var i=0; i<cnt; i++){
			var o = new Array;
			o.push(sa[p]*1);p++;
			o.push(sa[p]*1);p++;
			ot.push(o);
		}
		maskShape = new Shape;
		maskShape.vertices = vt;
		maskShape.inTangents = it;
		maskShape.outTangents = ot;
		maskShape.closed = cl;
		return maskShape;
	}
}

//---------------------------------------------------------------------------


var targetMask = null;
var activeComp = app.project.activeItem;
if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
	var selectedLayers = activeComp.selectedLayers;

	if ( (selectedLayers!=null)&&(selectedLayers.length >0) ){
		var f = File.openDialog("マスクパスファイルを選んでください。","*.mask");
		
		if ( f != null){
			f.open("r");
			var line = f.read();
			f.close();
			var sd = new shapeData();
			sd.fromLine(line);
			if (sd.getValue() != null){
				for ( var i=0; i<selectedLayers.length; i++){
					var maskG = selectedLayers[i].mask;
					if (maskG.canAddProperty("mask")==true){
						var mp = maskG.addProperty("mask");
						mp.property("マスクパス").setValue(sd.getValue());
					}
				}
			}
		}
	}
}
