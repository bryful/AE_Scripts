﻿/*
	レイヤのプロパティを選択して実行。
	そのプロパティにアクセスするコードを作成する。
*/

function showPropertyPath()
{
	//---------------
	//プロパティのアクセス配列を得る
	function proPath(p)
	{
		var ret = [];
		if ( ( p== null)||(p==undefined)) return ret;
		if (  p instanceof Property ) {
			var pp = p;
			while ( pp != null){
				ret.push(pp);
				pp = pp.parentProperty;	//このメソッドがキモ
			}
			//配列をひっくり返す
			if ( ret.length>1) ret = ret.reverse();
		}
		//返されるObjectは、Layerからになる
		return ret;
	}
	//---------------
	//Javascriptのコードに変換
	function proPathToString(ary,idx)
	{
		if ( !(ary instanceof Array) ) return "";
		if ( ary.length <=2) return "";
		
		var ret = "var p = ";
		ret += "app.project.item("+ idx + ")";		//CompItem

		for ( var i=0; i<ary.length; i++){
			if ( ( ary[i] instanceof AVLayer)||( ary[i] instanceof ShapeLayer)||(ary[i] instanceof TextLayer)){
				ret += ".layer(\"" + ary[i].name +"\")";
			}else if ( ary[i] instanceof PropertyGroup){
					
					//無理やり名前が変更できるか確認
					var nm = ary[i].name;
					var canNameChange = true;
					try{
						ary[i].name = "AAA_AAA_AAA";
						ary[i].name = nm;
					}catch(e){
						canNameChange = false;
					}

			
				switch(ary[i].propertyType)
				{
					case PropertyType.PROPERTY:
						ret += ".property(\"" + ary[i]matchName +"\")";
						break;
					case PropertyType.INDEXED_GROUP:
						ret += ".property(\"" + ary[i].matchName +"\")";
						break;
					case PropertyType.NAMED_GROUP:
						//名前が変更できるならnameを採用
						if (canNameChange ==true){
							ret += ".property(\"" + ary[i].name +"\")";
						}else{
							ret += ".property(\"" + ary[i].matchName +"\")";
						}
						//
						break;
				}
			}else if ( ary[i] instanceof Property){
				ret += ".property(\"" + ary[i].matchName +"\")";
			}
		}
		ret +=";\n";
		return ret;

	}
	//---------------
	//作成したコードを収納する
	var codeList = "";
	//ターゲットのコンポのインデックス
	var compIndex = -1;
	var layerIndex = -1;
	//アクティブなアイテムを得る
	var ac = app.project.activeItem;
	if ( ac instanceof CompItem)
	{
		//姑息なやり方でインデックスを獲得
		var idBk = ac.id;
		for ( var i=1; i<=app.project.numItems; i++)
		{
			if (app.project.item(i).id == idBk) {
				compIndex = i;
				break;
			}
		}
	
		var prA = ac.selectedProperties;
		var cnt = ac.selectedProperties.length
		if ( cnt>0){
			for (var i = 0; i < cnt; i++)
			{
				var a = proPath(prA[i]);
				if ( a.length>0){
					codeList += "//-----------------------------------------------------\n";
					codeList += proPathToString(a,compIndex) +"\n";
				}
			}
			if (codeList != "")
			codeList += "//-----------------------------------------------------\n";
		}
	}
	if ( codeList == ""){
		codeList = "レイヤーのプロパティを何か選択してくださいまし。";
	}
	//---------------
	//ダイアログを作成して表示。
	//カット＆ペーストしやすいようにedittextに表示
	this.winObj = new Window("dialog", "Propertyへのアクセス", [154, 203, 154+905, 203+248]);
	this.gb1 = this.winObj.add("panel", [13, 13, 13+880, 13+198], "After Effects Properties" );
	this.tbProp = this.gb1.add("edittext", [15, 18, 15+848, 18+163], codeList,{multiline: true,readonly:true } );
	this.btnOK = this.winObj.add("button", [759, 217, 759+98, 217+23], "OK", {name:'ok'});
	//this.label1 = this.winObj.add("statictext", [26, 224, 26+300, 224+12], "item/layerのindexは、状況によって変化するから注意すること" );
	this.winObj.center();


	//---------------
	this.show = function()
	{
		return this.winObj.show();
	}
	//---------------
}
var dlg = new showPropertyPath;
dlg.show();


