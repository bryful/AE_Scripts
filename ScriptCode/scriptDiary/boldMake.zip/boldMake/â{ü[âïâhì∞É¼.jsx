﻿
(function(me){
	#include "json2.js"
	var titleDef = ["none","BS","Y"];
	var memoDef = ["none","本編","内部チェック","カットチェック","タイミング","演出チェック","監督チェック"];
	var itemDef = ["none"];
	var prefData = {
		txt:[
			"",/*作品名*/
			"",/*話数*/
			"",/*カットNo*/
			"",/*秒数*/
			"",/*テイク*/
			"",/*メモ１*/
			"",/*メモ２*/
			"",/*メモ３*/
			"",/*メモ４*/
			""/*メモ５日付*/
		],
		his:[
			titleDef,
			itemDef,
			itemDef,
			itemDef,
			itemDef,
			memoDef,
			itemDef,
			itemDef,
			itemDef,
			itemDef,
		],
		selectedFoler:"",
		size: 5
	};
	//1280 3
	//1440 4
	//1980 5
	11
	var boldObject = {
		"data":[
			"",/*作品名*/
			"",/*話数*/
			"",/*カットNo*/
			"",/*秒数*/
			"",/*テイク*/
			"",/*メモ１*/
			"",/*メモ２*/
			"",/*メモ３*/
			"",/*メモ４*/
			""/*メモ５日付*/
		],
		"bs":{
			"WidthIndex":5,
			"Aspect":0,
			"D1":false,
		},
		"OutputPath":"",/*OutputFileName.jpg*/
		"QuitAfterOutputFlag":true,
		"clear" : function()
		{
			for (var i=0; i<this.data.length;i++) this.data[i] ="";
			this.bs.WidthIndex = 5;
			this.bs.Aspect = 0;
			this.bs.D1 = false;
		}
	};


	//-------------------------------------------------------------------------
	//prototype登録
	String.prototype.trim = function(){
		if (this=="" ) return ""
		else return this.replace(/[\r\n]+$|^\s+|\s+$/g, "");
	}
	//ファイル名のみ取り出す（拡張子付き）
	String.prototype.getName = function(){
		var r=this;var i=this.lastIndexOf("/");if(i>=0) r=this.substring(i+1);
		return r;
	}
	//拡張子のみを取り出す。
	String.prototype.getExt = function(){
		var r="";var i=this.lastIndexOf(".");if (i>=0) r=this.substring(i);
		return r;
	}
	//指定した書拡張子に変更（dotを必ず入れること）空文字を入れれば拡張子の消去。
	String.prototype.changeExt=function(s){
		var i=this.lastIndexOf(".");
		if(i>=0){return this.substring(0,i)+s;}else{return this + s; }
	}
	//文字の置換。（全ての一致した部分を置換）
	String.prototype.replaceAll=function(s,d){ return this.split(s).join(d);}
	
	//----------------------------------
	var scriptName = File.decode($.fileName.getName().changeExt(""));
	var prefFile = new File($.fileName.changeExt(".pref"));
	var winObj = null;
	var dlist = [];
	var edText = [];
	var btnExec = null;
	var dlSizw = null;
	//-------------------------------------------------------------------------
	//-------------------------------------------------------------------------
	function prefLoad()
	{
		if ( (prefFile ==null)||(prefFile.exists ==false)) return;
		var str ="";
		if (prefFile.open("r")){
			try{
				prefData = eval(prefFile.read());
				if ( !(prefData instanceof Object) ) {
					prefData = new Object;
				}
				if ( prefData.txt == undefined){
					prefData.txt = [ "","","","","","","","","",""];
				}
				if ( prefData.his == undefined){
					prefData.his = [ 
						titleDef,
						itemDef,
						itemDef,
						itemDef,
						itemDef,
						memoDef,
						itemDef,
						itemDef,
						itemDef,
						itemDef];
				}
				if ( prefData.selectedFoler == undefined){
					prefData.selectedFoler = "";
				}
				if (prefData.size == undefined){
					prefData.size = 5;
				}
			}catch(e){
				return;
			}finally{
				prefFile.close();
			}
		}
	}
	prefLoad();
	//-------------------------------------------------------------------------
	function prefSave()
	{
		pushPrefData();
		var json = prefData.toSource();
		if (prefFile.open("w")){
			try{
				prefFile.encoding = "UTF-8";
				prefFile.write(json);
			}catch(e){
			}finally{
				prefFile.close();
			}
		}
	}
	//-------------------------------------------------------------------------
	function buildPanel()
	{
		var x0 = 10;
		var x1 = x0+40;
		var x2 = x1+5;
		var x3 = x2+20;
		var x4 = x3+5;
		var x5 = x4+160;
		var iy = 4;
		var dy = 20;

		var y0 = 5;
		var y1 = y0 + dy;

		var w = x5 + 5;
		var h = y0 +(iy + dy) * 11 + 40 +5;
		winObj = ( me instanceof Panel) ? me : new Window("palette", "ボールド作成", [ 0, 0,  w, h]  ,{resizeable:true, maximizeButton:true, minimizeButton:true});
		winObj.add("statictext", [  x0,   y0,   x1,   y1], "作品名");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "話数");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "カットNo");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "秒数");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "テイク");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "メモ1");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "メモ2");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "メモ3");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "メモ4");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "日付");
		y0 = y1 + iy; y1 = y0 + dy;
		winObj.add("statictext", [  x0,  y0,   x1, y1], "サイズ");

		y0 = 5; y1 = y0 +dy;
		for ( var i=0; i<10;i++){
			var dl = winObj.add("dropdownlist", [  x2,   y0,   x3,  y1], prefData.his[i]);
			dl.index = i;
			dl.onChange = function()
			{
				if ( this.selection != null) {
					var idx = this.selection.index;
					if ( idx>0){
						var s = this.selection;
						if ( s != edText[this.index].text){
							edText[this.index].text = s;
							this.selection = null;
						}
					}
				}
			}
			dlist.push(dl);
			y0 = y1 + iy; y1 = y0 + dy;
		}
		y0 = 5; y1 = y0 +dy;
		for ( var i=0; i<9;i++){
			var ed = winObj.add("edittext", [  x4,   y0,   x5,  y1], prefData.txt[i]);
			ed.index = i;
			ed.onChange= function()
			{
				dlist[this.index].selection  = null;
			}
			edText.push(ed);
			y0 = y1 + iy; y1 = y0 + dy;
		}
		edText.push(winObj.add("edittext", [  x4 ,y0,   x5-50,  y1], prefData.txt[9]));

		btnDay = winObj.add("button", [  x5-45,  y0,   x5,  y1], "日付" );
		y0 = y1 + iy; y1 = y0 + dy
		dlSize = winObj.add("dropdownlist", [  x2,   y0,   x5,  y1], ["1920x1080","1440x810","1280x720"]);
		switch(prefData.size)
		{
			case 3:
				dlSize.items[2].selected = true;
				break;
			case 4: 
				dlSize.items[1].selected = true;
				break;
			case 5: 
			default:
				dlSize.items[0].selected = true;
				break;
		}
		y0 = y1 + iy; y1 = y0 + 40;
		btnExec = winObj.add("button", [  x4,  y0,   x5,  y1], "保存" );
	}
	buildPanel();
	//-------------------------------------------------------------------------
	dlSize.onChange = function()
	{
		var idx = dlSize.selection.index;
		switch(idx){
			case 2:
				prefData.size = 3;
				break;
			case 1:
				prefData.size = 4;
				break;
			case 0:
			default:
				prefData.size = 5;
				break;
		}
	}
	//-------------------------------------------------------------------------
	function resizeWin()
	{
		var b = winObj.bounds;
		for ( var i=0; i<9;i++){
			var a = edText[i].bounds;
			a[2] = b.width -5;
			edText[i].bounds = a;
		}
		var a = edText[9].bounds;
		a[2] = b.width -50;
		edText[9].bounds = a;
		var a = btnDay.bounds;
		a[0] = b.width -45;
		a[2] = b.width -5;
		btnDay.bounds = a;
		var a = dlSize.bounds;
		a[2] = b.width -5;
		dlSize.bounds = a;
		var a = btnExec.bounds;
		a[2] = b.width -5;
		btnExec.bounds = a;
		
	}
	resizeWin();
	winObj.onResize = resizeWin;
	//-------------------------------------------------------------------------
	btnDay.onClick = function()
	{
		pushPrefData();
		var d = new Date;
		var s = d.getFullYear()  +"年" + (d.getMonth()+1) + "月" + d.getDate() +"日";
		edText[9].text = s;
	}
	
	//-------------------------------------------------------------------------
	function pushPrefData()
	{
		for ( var i=0; i<10; i++){
			var s = edText[i].text.trim();
			prefData.txt[i] = s;
			if (  s != ""){
				if ( prefData.his[i].length<=1){
					prefData.his[i].push(s);
					dlist[i].add("item",s);
				}else{
					var idx =-1;
					for ( var k=1; k<prefData.his[i].length; k++){
						if (prefData.his[i][k] == s){
							idx = k;
							break;
						}
					}
					if ( idx==-1) {
						prefData.his[i].push(s);
						dlist[i].add("item",s);
					}
				}
				if (prefData.his[i].length>12) {
					 prefData.his[i].splice(0,1);
					 dlist[i].items[1].remove();
				}
			}
			
		}
	}
	winObj.onClose = prefSave;
	//-------------------------------------------------------------------------
	function unescapeUnicode(str)
	{
		return str.replace(
			/\\u([a-fA-F0-9]{4})/g,
			function(m0,m1)
			{
				return String.fromCharCode(parseInt(m1,16));
			}
		);
	}
	//-------------------------------------------------------------------------
	function saveBold(f)
	{
		var e = f.fullName.getExt().toLowerCase();
		if ( e != ".jpg"){
			f = new File(f.fullName.changeExt(".jpg"));
		}
		var b =  boldObject;
		b.clear();
		for ( var i=0; i<10; i++){
			b.data[i] = prefData.txt[i];
		}
		b.bs.WidthIndex = prefData.size;

		b.OutputPath = f.fsName;
		prefData.selectedFoler = f.fullName;
		var json = JSON.stringify(b);
		var fileObj = new File(Folder.temp.fullName +"\\__tmp__.bdj");
		if ( fileObj.exists==true) fileObj.remove();
		if (fileObj.open("w")){
			try{
				fileObj.encoding = "UTF-8";
				fileObj.write(json);
				
			}catch(e){
				alert(e.toString());
			}finally{
				fileObj.close();
			}
		}
		if ( fileObj.exists==true) {
			//PATHが通った場所にボールド作成.exeをインストールできないときはこっちでも出来る
			if ( f.exists == true) f.remove();
			fileObj.execute();
			$.sleep(1000);
			
			/*
			//ボールド作成.exeをPATHの通った場所にインストール
			var cmd = "ボールド作成.exe" + " \""+ fileObj.fsName + "\" \"" + f.fsName +"\" -q";
			system.callSystem(cmd);
			*/
			var idx = 0;
			while (idx<1000){
				if ( f.exists == true){
					var im = new ImportOptions(f);
					app.project.importFile(im);
					idx = 1000;
					break;
				}
				$.sleep(500);
				idx++;
			}
		}
	}
	//-------------------------------------------------------------------------
	function execAsDialog()
	{
		pushPrefData();
		var f = null;
		if (prefData.selectedFoler !=""){
			sd = new File(prefData.selectedFoler);
			f = sd.saveDlg("","*.jpg");
		}else{
			f = File.saveDialog("","*.jpg");
		}
		if ( f != null) saveBold(f);
	}
	btnExec.onClick = execAsDialog;
	//-------------------------------------------------------------------------
	if ( ( me instanceof Panel) == false){
		winObj.center(); 
		winObj.show();
	}
	//-------------------------------------------------------------------------
})(this);