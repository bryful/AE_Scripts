﻿(function(me){
	//----------------------------------
	//prototype登録
	String.prototype.trim = function(){
		if (this=="" ) return ""
		else return this.replace(/[\r\n]+$|^\s+|\s+$/g, "");
	}
	//ファイル名のみ取り出す（拡張子付き）
	String.prototype.getName = function(){
		var r=this;var i=this.lastIndexOf("/");if(i>=0) r=this.substring(i+1);
		return r;
	}
	//拡張子のみを取り出す。
	String.prototype.getExt = function(){
		var r="";var i=this.lastIndexOf(".");if (i>=0) r=this.substring(i);
		return r;
	}
	//指定した書拡張子に変更（dotを必ず入れること）空文字を入れれば拡張子の消去。
	String.prototype.changeExt=function(s){
		var i=this.lastIndexOf(".");
		if(i>=0){return this.substring(0,i)+s;}else{return this + s; }
	}
	//文字の置換。（全ての一致した部分を置換）
	String.prototype.replaceAll=function(s,d){ return this.split(s).join(d);}
	//----------------------------------
	var scriptName = File.decode($.fileName.getName().changeExt(""));
	var prefFile = new File($.fileName.changeExt(".pref"));
	var rcfFile  = new File($.fileName.changeExt(".rcf"));

	//----------------------------------
	//フッテージをコピーする先フォルダ名
	var footageRootName = "(Footage)";
	//フッテージを収集するフォルダ
	var footageRootFolder = null;
	
	//マシンの最大数
	var PCCount = 5;
	//RCFを書き出すか
	var RCF = false;
	
	var noneFolderON = false;
	var noneFolderNameDef = "収集しないフッテージ";
	var noneFolderName = noneFolderNameDef;
	var nonePathON = false;
	
	//除外するフォルダ
	var dirlistArray = [];
	//除外フォルダの履歴
	var selectDir = "";
	//コピー先フォルダの履歴
	var selectCollectDir = "";
	
	//コピーするフッテージ
	var copyFootage = [];	//FootageItem
	//コピーしないフッテージ
	var noCopyFootage = [];	//FootageItem
	//コピー終わったフッテージ
	var copyFile = [];	//File
	//コピー終わったフッテージが連番かどうか
	var copyFileRenban = [];	//Boolean
	
	//収集ファイルを上書きするか？
	var repFolder = false;
	//コピー時に同名ファイルがあったら上書きするか
	var repFile = false;


	//このRCFはCS4専用。
	//この文字列を変えれば、他のバージョンにも対応できるはず。
	//起動時に???.rcfファイルとして保存され、実行するたびに
	//読み込み直すので注意の事。
	var RCF_FILE =	"After Effects 9.0v1 Render Control File\r\n"+
					"max_machines=$PCCount\r\n"+
					"num_machines=0\r\n"+
					"init=0\r\n"+
					"html_init=0\r\n"+
					"html_name=\"\"\r\n";
	//-------------------------------------------------------------------------
	function showHelp()
	{
		var s =
		"[" + scriptName +"]\n"+
		"\n"+
		"☆about\n"+
		"指定したものを除いたフッテージファイルを収集するスクリプト。\n"+
		"\n"+
		"☆option\r\n"+
		"「収集先のフォルダ」ボタン\n\t収集フォルダを作るフォルダの指定。\n\n"+
		"「上書きを許可」\n\t収集先に同名フォルダがあっても実行する。\r\n"+
		"「同名ファイルは強制上書きする」\n\t強制上書き。offならばサイズ・タイムスタンプを判断して上書きするか決める。\n\n"+
		"「『フォルダの監視』レンダリング可能」\n\tRCFも同時に作成する。\n\n"+
		"「マシンの最大数」\n\tRCFのmax_machinesの設定値\n\n"+
		"「収集除外フォルダ(Projectウィンドウのルート)」\n\t以下で指定されたフォルダ(Projectウィンドウ)の中にあるフッテージは収集しない。\n"+
		"\tこのフォルダは必ずルートにあること！\n\n"+
		"「獲得」ボタン\n\t選択されたフォルダの名前を獲得。ルートにあるフォルダ意外は無効。\n\n"+
		"「作成」ボタン\n\tテキストエディトで指定されたフォルダをルートに作成。\n\n"+
		"「規定」ボタン\n\tデフォルトの収集除外フォルダ名称に設定。フォルダがなければ作成します。\n\n"+
		"「収集所がパス(ドライブ)」\n\t以下で指定されたパス(ディレクトリ)で始まるファイルは収集しない。\n\n"+
		"「追加」ボタン\n\t除外パスを追加。パスは自動ソートされます。\n\n"+
		"「削除」ボタン\n\t除外パスを削除。\n\n"+
		"「実行」ボタン\n\t収集を開始する。\n\n";
		alert(s,"["+scriptName +"]のヘルプ");
	}
	//-------------------------------------------------------------------------
	//デバッグ用の配列の中身を表示する関数
	function dispArray(s,cap)
	{
		var ret = cap+"\r\n";
	
		if ( s.length<=0) {
			alert(ret + "なし");
			return;
		}
		for ( var i=0; i<s.length; i++){
			if ( typeof(s[i]) == "string"){
				ret += i.toString() + ": String = " + s[i];
				if (s[i].fIndex != undefined) ret += " fi=" +s[i].fIndex;
				ret += "\r\n";
			}else if ( s[i] instanceof File){
				ret += i.toString() + ": File = " + File.decode(s[i].fullName);
				if (s[i].fIndex != undefined) ret += " fi=" +s[i].fIndex;
				ret += "\r\n";
			}else if ( s[i] instanceof FootageItem){
				ret += i.toString() + ": Footage = " + s[i].name;
				if (s[i].fIndex != undefined) ret += " fi=" +s[i].fIndex;
				ret += "\r\n";
			}else{
				ret += i.toString() + ": "+typeof(s[i])+" = " + s[i].toString();
				ret += "\r\n";
			}
		}
		alert(ret);
	}
	//-------------------------------------------------------------------------
	var winObj = ( me instanceof Panel) ? me : new Window("palette", "ファイルを一部だけ収集", [ 804,  326,  804+ 304,  326+ 368]  ,{resizeable:true});
	//-------------------------------------------------------------------------
	var btnHelp = winObj.add("button", [ 262,    3,  262+  32,    3+  23], "?" );
	btnHelp.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnCollect = winObj.add("button", [  12,    3,   12+ 102,    3+  23], "収集先のフォルダ" );
	btnCollect.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var edCollectPath = winObj.add("edittext", [   0,   28,    0+ 304,   28+  21], "");
	edCollectPath.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var stProject = winObj.add("statictext", [   6,   52,    6+  79,   52+  17], "収集フォルダ名");
	stProject.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var stProjectName = winObj.add("statictext", [  89,   52,   89+ 213,   52+  15], "statictext_AE2");
	stProjectName.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var cbRep = winObj.add("checkbox", [  12,   70,   12+  92,   70+  20], "上書きを許可");
	cbRep.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var cbRepFile = winObj.add("checkbox", [ 111,   72,  111+ 172,   72+  18], "同名ファイルは強制上書きする");
	cbRepFile.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var cbWatch = winObj.add("checkbox", [  12,   94,   12+ 209,   94+  18], "「フォルダの監視」レンダリング使用可能");
	cbWatch.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var stPCCount = winObj.add("statictext", [  50,  116,   50+  85,  116+  13], "マシンの最大数");
	stPCCount.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var edPCCount = winObj.add("edittext", [ 141,  113,  141+  55,  113+  21], PCCount);
	edPCCount.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var cbNoneFolder = winObj.add("checkbox", [  12,  137,   12+ 244,  137+  16], "収集除外フォルダ(Projectウィンドウのルート)");
	cbNoneFolder.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnGetFolder = winObj.add("button", [   9,  155,    9+  40,  155+  23], "獲得" );
	btnGetFolder.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnSetFolder = winObj.add("button", [  53,  155,   53+  40,  155+  23], "作成" );
	btnSetFolder.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnDefFolder = winObj.add("button", [  98,  155,   98+  40,  155+  23], "規定" );
	btnDefFolder.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var edNoneFolder = winObj.add("edittext", [ 141,  155,  141+ 161,  155+  21], noneFolderName);
	edNoneFolder.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var cbNonePath = winObj.add("checkbox", [  12,  192,   12+ 140,  192+  17], "収集除外パス(ドライブ)");
	cbNonePath.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnSelect = winObj.add("button", [ 168,  186,  168+  60,  186+  23], "追加" );
	btnSelect.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var btnDelete = winObj.add("button", [ 234,  186,  234+  60,  186+  23], "削除" );
	btnDelete.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var dirlist = winObj.add("listbox", [   0,  212,    0+ 304,  212+  95], dirlistArray );
	dirlist.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);
	var progBar1 = winObj.add("progressbar", [   6,  313,    6+ 190,  313+  20],    0 ,   0,  100 );
	var progBar2 = winObj.add("progressbar", [   6,  338,    6+ 190,  338+  20],    0 ,   0,  100 );
	var btnExec = winObj.add("button", [ 210,  313,  210+  83,  313+  43], "実行" );
	btnExec.graphics.font = ScriptUI.newFont("Tahoma",ScriptUI.FontStyle.REGULAR, 11);


	var dirlistBak = winObj.add("listbox", [   0,  189,    0+ 304,  189+ 186], [] );
	//-------------------------------------------------------------------------
	//初期状態の設定
	btnGetFolder.enabled = false;
	btnSetFolder.enabled = false;
	btnDefFolder.enabled = false;
	edNoneFolder.enabled = false;
	
	
	btnSelect.enabled = false;
	btnDelete.enabled = false;
	dirlist.enabled = false;
	dirlistBak.visible = false;
	stPCCount.enabled = false;
	edPCCount.enabled = false;
	stProjectName.text = "";
	cbRepFile.enabled = false;
	
	btnHelp.onClick = showHelp;
	//-------------------------------------------------------------------------
	function repChange()
	{
		cbRepFile.enabled = cbRep.value;
	}
	cbRep.onClick = repChange;
	//-------------------------------------------------------------------------
	function watchChange()
	{
		stPCCount.enabled = edPCCount.enabled = cbWatch.value;
	}
  	cbWatch.onClick = watchChange;
	//-------------------------------------------------------------------------
	function noneFolderChange()
	{
		btnGetFolder.enabled = btnSetFolder.enabled = btnDefFolder.enabled 
		= edNoneFolder.enabled = cbNoneFolder.value;
	}
	cbNoneFolder.onClick = noneFolderChange;
	//-------------------------------------------------------------------------
	//dirlistの選択状態が変更された時の処理
	function dirlistChange()
	{
		if ( cbNonePath.value ==false){
			btnDelete.enabled = false;
		}else{
			if ( (dirlist.selection ==null)||(dirlist.selection =="")){
				btnDelete.enabled = false;
			}else{
				btnDelete.enabled =  ( dirlist.selection.index>=0);
			}
		}
	}
	dirlist.onChange = dirlistChange;//dirlistは作り直しがある
	
	//-------------------------------------------------------------------------
	function nonePathChange()
	{
		btnSelect.enabled = dirlist.enabled = cbNonePath.value;
		dirlistChange();
	}
	cbNonePath.onClick = nonePathChange;
	//-------------------------------------------------------------------------
	function enabledChk()
	{
		repChange();
		watchChange();
		noneFolderChange();
		nonePathChange();
	}
	//-------------------------------------------------------------------------
	//listboxとdirlistをシンクロ
	function dirlistNew()
	{
		if ( dirlistArray.length>1){
			dirlistArray.sort();
		}
		dirlistBak.bounds = dirlist.bounds;
		dirlistBak.visible = true;
		dirlist.visible = false;
		winObj.remove(dirlist);
		dirlist = winObj.add("listbox",dirlistBak.bounds , dirlistArray );
		dirlist.onChange = dirlistChange;
		dirlist.enabled = cbNonePath.value;
		dirlist.visible = true;
		dirlistBak.visible = false;
	}
	//-------------------------------------------------------------------------
	function toVar()
	{	
		repFolder = cbRep.value;
		repFile = cbRepFile.value;
		RCF =  cbWatch.value;
		if ( isNaN(edPCCount.text)==false){
			PCCount = edPCCount.text*1;
			if (PCCount<=0) PCCount = 1;
		}else{
			PCCount = 5;
		}
		noneFolderON = cbNoneFolder.value;
		noneFolderName = edNoneFolder.text.trim();
		nonePathON = cbNonePath.value;
		
	}
	//-------------------------------------------------------------------------
	function fromVar()
	{	
		cbRep.value = repFolder;
		cbRepFile.value = repFile;
		cbWatch.value = RCF;
		edPCCount.text = PCCount +"";
		cbNoneFolder.value = noneFolderON;
		edNoneFolder.text = noneFolderName;
		cbNonePath.value = nonePathON;
		dirlistNew();
		enabledChk();
	}
	//-------------------------------------------------------------------------
	function prefSave()
	{
		toVar();
		var o = new Object;
		
		o.repFolder = repFolder;
		o.repFile = repFile;
		o.RCF = RCF;
		o.PCCount = PCCount;
		o.noneFolderON = noneFolderON;
		o.noneFolderName = noneFolderName;
		o.nonePathON = nonePathON;
		o.dirlistArray = [].concat(dirlistArray);
		o.selectDir = selectDir;
		o.selectCollectDir = selectCollectDir;
		var str = o.toSource();
		if (prefFile.open("w")){
			try{
				prefFile.write(str);
			}catch(e){
			}finally{
				prefFile.close();
			}
		}
	}
	//-------------------------------------------------------------------------
	function prefLoad()
	{
		if ( (prefFile ==null)||(prefFile.exists ==false)) return;
		var str ="";
		if (prefFile.open("r")){
			try{
				str = prefFile.read();
			}catch(e){
				return;
			}finally{
				prefFile.close();
			}
		}
		if ( str == "") return;
		var o = eval(str);
		if (o!=null){
			if (o.repFolder != undefined) { repFolder = o.repFolder; }
			if (o.repFile != undefined) { repFile = o.repFile; }
			if (o.RCF != undefined) { RCF = o.RCF; }
			if (o.PCCount != undefined) { PCCount = o.PCCount; }
			if (o.noneFolderON != undefined) { noneFolderON = o.noneFolderON; }
			if (o.noneFolderName != undefined) { noneFolderName = o.noneFolderName; }
			if (noneFolderName =="") noneFolderName = noneFolderNameDef;
			if (o.nonePathON != undefined) { nonePathON = o.nonePathON; }
			if (o.dirlistArray != undefined) { dirlistArray = [].concat( o.dirlistArray); }
			if (o.selectDir != undefined) { selectDir = o.selectDir; }
			if (o.selectCollectDir != undefined) { selectCollectDir = o.selectCollectDir; }
			fromVar();
		}
	}
	prefLoad();
	//-------------------------------------------------------------------------
	function rcfLoad()
	{
		if ( rcfFile.exists == false){
			if (rcfFile.open("w")){
				try{
					rcfFile.write(RCF_FILE);
				}catch(e){
				}finally{
					rcfFile.close();
				}
			}
			return RCF_FILE;
		}
		var str ="";
		if (rcfFile.open("r")){
			try{
				str = rcfFile.read();
			}catch(e){
				str ="";
			}finally{
				rcfFile.close();
			}
		}
		return str;
	}
	rcfLoad();
	//-------------------------------------------------------------------------
	function isInList(f)
	{
		var ret = false;
		if (dirlistArray.length<=0) return ret;
		var p = Folder.decode(f.fullName);
		for ( var i=0; i<dirlistArray.length; i++)
		{
			if ( p.indexOf(dirlistArray[i])>=0){
				ret = true;
				break;
			} 
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function findNoneFolder()
	{
		noneFolderName = edNoneFolder.text;
		if ( noneFolderName == "") {
			return null;
		}
		if ( app.project.rootFolder.numItems>0){
			for ( var i=1; i<=app.project.rootFolder.numItems; i++){
				if ( app.project.rootFolder.item(i).name ==noneFolderName){
					return app.project.rootFolder.item(i);
				}
			}
		}
		return null;
	}
	//-------------------------------------------------------------------------
	function isInFolder(f)
	{
		var ret = false;
		if ((noneFolderName =="")||(noneFolderON==false)) return false;
		
		var l = getFolderItemPath(f);
		if (l.length<=0) return false;
		return ( l[0] == noneFolderName);
	}
	//-------------------------------------------------------------------------
	//フッテージのフォルダ構成(プロジェクトウィンドウ)を配列で返す
	function getFolderItemPath(ftg)
	{
		var ret = [];
		if ((ftg instanceof FootageItem)==false){
			alert("getFolderItemPath. not Footage");
			return ret;
		}
		var rid = app.project.rootFolder.id;
		var p = ftg;
		while(p != null)
		{
			p = p.parentFolder;
			if (( p.id == rid)||(p==null)) break;
			ret.push(p.name+"");
			
		}
		ret.reverse();
		return ret;
	}

	//-------------------------------------------------------------------------
	function fldName(s)
	{
		if ( s=="") return "";
		var ret = "";
		for ( var i=0; i<s.length; i++){
			var c = s[i];
			if ( (c=="\\")||(c=="/")||(c==":")||(c=="*")||(c=="*")||(c=="\"")||(c=="<")||(c==">")||(c=="|")){
				c = "-";
			}
			ret += c;
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	//配列で指定されたフォルダ(ディスクの)構成を作成
	//一番奥のFolder objectを返す
	function createFolder(ary,fld)
	{
		var ret = fld;
		if ( ary.length<=0) return ret;
		if ( ret.exists == false) ret.create();
		for (var i=0; i<ary.length; i++)
		{
			ret = new Folder(ret.fullName+"/"+fldName(ary[i]));
			if ( ret.exists ==false ) ret.create();
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function isRenban(ftg)
	{
		//静止画は違う
		if (ftg.mainSource.isStill==true) return false;
		//拡張子で判別
		var e = ftg.name.getExt().toLowerCase();
		if ( (e==".mov")||(e==".qt")||(e==".avi")) {
			return false;
		}
		//一応念のため
		var nf = ftg.mainSource.nativeFrameRate;
		if ( (nf == ftg.mainSource.conformFrameRate)&&(nf == ftg.mainSource.displayFrameRate)){
			return true;
		}else{
			return false;
		}
	}
	//-------------------------------------------------------------------------
	//ファイルコピーの基本関数。
	function copySrc(s,d)
	{
		var b = true;
		if ((d.exists==true)&&(repFile==false)){
			if ( s.length == d.length) b = false;
			if (s.modified.getTime() <= d.modified.getTime()) b = false;
		}
		if (b==true){
			var r = s.copy(d);
			if ( r==false){
				
			}
			return r;
		}else{
			return true;
		}
	}
	//-------------------------------------------------------------------------
	//静止画・ムービーフッテージのコピー
	function copyFileOne(ftg,dstFolder)
	{
		var ps = getFolderItemPath(ftg);
		var d = createFolder(ps,dstFolder);
		var dst = new File(d.fullName + "/" + ftg.file.name);
		if ( copySrc( ftg.file,dst)==true){
			return dst;
		}else{
			alert("コピーに失敗しました！ One \r\n\r\n"+File.decode(ftg.file.fullName));
			return null;
		}
	}
	//-------------------------------------------------------------------------
	//フッテージからフレーム番号を除いた名前を得る
	function splitFrameNumber(s,op)
	{
		if (s =="") return "";
		var ss = s.changeExt("");
		if (ss =="") return "";
		
		var idx = -1;
		for ( var i= ss.length-1;i>=0; i--){
			var c = ss[i];
			if ( (c<"0")||(c>"9")){
				idx = i;
				break;
			}
		}
		//AAA_0001
		//01234567
		if (idx > -1){
			ss = ss.substr(0,idx+1);
		}
		
		if ((op==true)&&( ss.length>1)){
			var c = ss[ss.length-1];
			if ( (c=="_")||(c=="-")) ss = ss.substr(0,ss.length-1);
			ss = ss.trim();
		}
		return ss;
	}
	//-------------------------------------------------------------------------
	function copyFiles(ftg,dstFolder)
	{
		var ps = getFolderItemPath(ftg);
		var sub = splitFrameNumber(ftg.file.name,true);
		ps.push(sub);

		var d = createFolder(ps,dstFolder);
		var targetName = splitFrameNumber(ftg.file.name,false)+"*"+ftg.file.name.getExt();
		var files = ftg.file.parent.getFiles(targetName);

		if ((files==null)||(files.length<=0)){
			alert("コピーする連番ファイルがありません！\r\n\r\n" + File.decode(ftg.file.fullName));
			return null;
		}
		progBar2.value = 0;
		progBar2.maxvalue = files.length-1;
		
		var ret = null;
		for ( var i=0; i<files.length; i++)
		{
			winObj.update();
			progBar2.value = i;
			var dF = new File(d.fullName + "/" + files[i].name);
			
			if ( copySrc(files[i],dF)==false){
				alert("コピーに失敗しました！ files\r\n\r\n"+File.decode(files[i].fullName));
				return null;
			}else{
				if ( i==0) ret = dF;
			}
			
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function copyFootages()
	{
		copyFile = [];
		copyFileRenban = [];
		if ( copyFootage.length<=0) return false;
		
		progBar1.minvalue = 0;
		progBar1.maxvalue = copyFootage.length-1;
		
		for ( var i=0; i<copyFootage.length; i++)
		{
			progBar1.value = i;
			progBar2.value = 0;
			var fIdx = copyFootage[i].fIndex;
			if (  fIdx < i){
				copyFile.push(copyFile[fIdx]);
				copyFileRenban.push(copyFileRenban[fIdx]);
			}else{
				if ( isRenban(copyFootage[i])==false){
					var n = copyFileOne(copyFootage[i],footageRootFolder);
					if ( n == null) break;
					copyFile.push(n);
					copyFileRenban.push(false);
				}else{
					var n = copyFiles(copyFootage[i],footageRootFolder);
					if ( n == null) break;
					copyFile.push(n);
					copyFileRenban.push(true);
				}
			}
			copyFile[i].fIndex = fIdx;
		}
		progBar1.value = 0;
		progBar2.value = 0;
		
		var v = ( (copyFootage.length == copyFile.length)&&(copyFootage.length == copyFileRenban.length));
		return v;
	}
	//-------------------------------------------------------------------------
	function replaceFootage()
	{
		if ( copyFootage.length>0){
			for ( var i=0; i<copyFootage.length; i++)
			{
				if ( copyFileRenban[i]==true){
					copyFootage[i].replaceWithSequence(copyFile[i],false);
				}else{
					copyFootage[i].replace(copyFile[i]);
				}
			}
		}
		if (noCopyFootage.length>0){
			noneFolderName = edNoneFolder.text;
			if (noneFolderName =="") { noneFolderName = edNoneFolder.text = noneFolderNameDef;}
			var f = findNoneFolder();
			if ( f== null){
				f = app.project.rootFolder.addFolder(noneFolderName);
			}
			for ( var i=0; i<noCopyFootage.length; i++)
				noCopyFootage[i].parentFolder = f;
			
		}
	}
	//-------------------------------------------------------------------------
	function exec()
	{
		toVar();
		repFolder = cbRep.value;
		repFile = ((cbRep.value==true)&&(cbRepFile.value == true));
		//projectが保存されているか
 		if ( app.project.file == null)
 		{
 			alert("プロジェクトが保存されていません。保存して下さい。");
 			app.project.saveWithDialog();
 			getProjectName();
 			return;
 		}
 		//とりあえず保存
 		app.project.save();
 		var aepOrg = app.project.file.fullName;

 		//収集するファイル名
 		var collectedFolderName = getProjectName();
 		
 		//収集先のチェック
 		var collectPath = new Folder(File.encode(edCollectPath.text));
 		if ((collectPath == null)||(collectPath.exists == false)){
 			alert("収集先のフォルダが指定されていない or ありません");
 			return;
 		}
 		var baseFolder = new Folder(Folder.encode(collectPath.fullName + "/" + collectedFolderName));
 		if (baseFolder.exists == true){
 			if (repFolder == false) {
	 			alert("収集先に同じ名前の収集フォルダがあります。確認して下さい。\r\n\r\n["+ Folder.decode(baseFolder.fullname)+"]");
	 			return;
 			}
 		}else{
 			baseFolder.create();
 		}
 		//新しいaepのFile object
 		//フッテージを収集するフォルダ。
 		footageRootFolder = new Folder(baseFolder.fullName + "/"+ footageRootName);
 		if ( footageRootFolder.exists ==false ) {
 			if (footageRootFolder.create() == true){
 			}
 		}

 		//有効なRQがあるか
 		var RQ = true;
 		if ( app.project.renderQueue.numItems<=0) { RQ = false; }
 		else {
 			var b = false;
 			for ( var i=1; i<=app.project.renderQueue.numItems; i++){
 				if ( app.project.renderQueue.item(i).status == RQItemStatus.QUEUED) b = true;
 			}
 			if ( b == false) RQ = false;
 		}
 		if ( b==false){
 			alert("有効なレンダーキューが登録されていません！");
 			return;
 		}
 		//フッテージを調べる。
 		var footageList = [];
 		var cnt = app.project.numItems;
 		if ( cnt>0){
	 		for ( var i=1; i<=cnt; i++)
	 		{
	 			var t = app.project.item(i);
	 			//フッテージで、平面じゃなくて、使われているもの
	 			if ((t instanceof FootageItem)&&(t.mainSource.color == undefined)&&(t.usedIn.length>0)) {
 					if (t.footageMissing == true){
			 			alert("失われたフッテージがあります\r\n\r\n"+ File.decode(t.mainSource.missingFootagePath));
			 			return;
 					}else{
	 					footageList.push(t);
	 				}
	 			}
	 		}
 		}
 		//コピーするものしないものに分ける。
 		if ( noneFolderON ==true){
 			var nf = findNoneFolder();
 			if (nf==null){
	 			alert("指定された収集除外フォルダが存在しません！");
	 			return;
 			}
 		}
 		
 		copyFootage = [];
 		noCopyFootage = [];
 		if (footageList.length>0){
 			for ( var i=0; i<footageList.length; i++)
 			{
 				var cpGo = true;
 				
 				if ( nonePathON==true){
	 				if ( isInList(footageList[i])==true) cpGo = false;
 				}
 				if ( noneFolderON==true){
	 				if ( isInFolder(footageList[i])==true) cpGo = false;
 				}
 				if ( cpGo==true){
 					copyFootage.push(footageList[i]);
 				}else{
 					noCopyFootage.push(footageList[i]);
 				}
 			}
 		}
 		//ファイルの重複を確認
 		if ( copyFootage.length>0){
			//インデックスをつける
			for ( var i=0; i<copyFootage.length;i++) copyFootage[i].fIndex = i;
			//重複の確認
			if ( copyFootage.length>1){
				for ( var i= copyFootage.length-1; i>=1; i--){
					var p = copyFootage[i].file.fullName;
					var isS = copyFootage[i].mainSource.isStill;
					for ( var j= 0; j<i; j++){
						if ((copyFootage[j].file.fullName == p)&&(copyFootage[j].mainSource.isStill == isS)){
							copyFootage[i].fIndex = j;
							break;
						}
					}
				}
			}
			if (copyFootages()==false){
				return;
			}
		}
		replaceFootage();
		var aepPath = new File(baseFolder.fullName + "/" + app.project.file.name );
		app.project.save(aepPath);
		if ( cbWatch.value == true){
			var str = rcfLoad();
			if ( isNaN(edPCCount.text)==false){
				PCCount = edPCCount.text *1;
			}else{
				PCCount = 5;
			}
			str = str.split("$PCCount").join(PCCount+"");
			var rcfPath = new File(baseFolder.fullName + "/" + app.project.file.name.changeExt("") +"_RCF.txt" );
			if (rcfPath.open("w")){
				try{
					rcfPath.write(str);
				}catch(e){
				}finally{
					rcfPath.close();
				}
			}
		}
		
		//元に戻す
		app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES);
		app.open(new File(aepOrg)); 

 	}

	//-------------------------------------------------------------------------
	function getProjectName()
	{
 		if ( app.project.file == null)
 		{
 			stProjectName.text = "";
 		}else{
 			stProjectName.text = Folder.decode(app.project.file.name).changeExt("")+"フォルダ";
 		}
 		return stProjectName.text;
	}
 	getProjectName();
	//-------------------------------------------------------------------------
	function selectCollectPath()
	{
 		var fld = Folder.selectDialog("収集先のフォルダを指定して下さい。",selectCollectDir);
 		if ( fld != null)
 		{
 			edCollectPath.text = File.decode(fld.fullName);
 			selectCollectDir = edCollectPath.text;
 		}
 		getProjectName();
	 }
	//-------------------------------------------------------------------------
	//項目追加
	function addDirList()
	{
 		var fld = Folder.selectDialog("除外するフォルダを指定して下さい。",selectDir);
 		if ( fld != null)
 		{
 			selectDir = fld.fullName;
 			var p = Folder.decode(fld.fullName);
 			var b = true;
 			if (dirlistArray.length>0){
 				for ( var i=0; i<dirlistArray.length; i++){
 					if (dirlistArray[i] == p) {
 						b = false;
 						break;
 					}
 				}
 			}
			if ( b==true){
	 			dirlistArray.push(p);
	 			dirlistNew();
			}
		}
	 }
	//-------------------------------------------------------------------------
	//項目削除
	function deleteDirList()
	{
		var idx = dirlist.selection.index;
		if ( idx>=0){
			dirlistArray.splice(idx,1);
			dirlistNew();
 		}
	}
	//-------------------------------------------------------------------------
	function getNoneFolder()
	{
		var ac = app.project.activeItem;
		if ( (ac instanceof FolderItem)==false){
			alert("FolderItemを選択して下さい。");
			return;
		}
		if ( app.project.rootFolder.id != ac.parentFolder.id){
			alert("必ずルートにあるFolderItemを選択して下さい。");
			return;
		}
		edNoneFolder.text = ac.name;
		if (ac.name.trim() !=ac.name){
			alert("名称の頭尻にスペースがあります。注意してください！")
		}
	}
	//-------------------------------------------------------------------------
	function setNoneFolder()
	{
		var s = edNoneFolder.text;
		if (s.trim() !=s){
			alert("名称の頭尻にスペースがあります。注意してください！");
		}
		var f = findNoneFolder();
		if (f == null){
			var f = app.project.rootFolder.items.addFolder(s);
		}else{
			alert("同名フォルダが既に存在します。");
		}
	}
	//-------------------------------------------------------------------------
	function defNoneFolder()
	{
		edNoneFolder.text = noneFolderNameDef;
		setNoneFolder();
	}
	//-------------------------------------------------------------------------
	function resize()
	{
		var b = winObj.bounds;
		var w = b[2] -b[0];
		var h = b[3] -b[1];
		if ( w<300) w=300;
		if ( h<300) h=300;
		winObj.text = w +"."+h;

		var b = btnHelp.bounds; 
		b[0] = w -42;
		b[2] = b[0] + 32;
		btnHelp.bounds = b;

		var b = edCollectPath.bounds; 
		b[2] = w;
		edCollectPath.bounds = b;

		var b = edNoneFolder.bounds; 
		b[2] = w;
		edNoneFolder.bounds = b;


		var b = dirlist.bounds;
		b[2] = w;
		b[3] = h-55;
		dirlist.bounds = b;

		var b = btnExec.bounds;
		b[0] = w - 90;
		b[2] = w - 10;
		b[1] = h - 50;
		b[3] = h - 5;
		btnExec.bounds = b;


		var b = progBar1.bounds;
		b[0] = 0;
		b[2] = w - 100;
		b[1] = h - 50;
		b[3] = h - 30;
		progBar1.bounds = b;

		var b = progBar2.bounds;
		b[0] = 0;
		b[2] = w - 100;
		b[1] = h - 25;
		b[3] = h - 5;
		progBar2.bounds = b;

	}
	resize();
	//-------------------------------------------------------------------------
	//イベント関係の登録
	winObj.addEventListener("resize",resize);
	winObj.onResize = resize;
	btnExec.onClick = exec;
	btnCollect.onClick = selectCollectPath;
	btnSelect.onClick = addDirList;
	btnDelete.onClick = deleteDirList;
	winObj.onClose = prefSave;
	
	btnGetFolder.onClick = getNoneFolder; 
	btnSetFolder.onClick = setNoneFolder; 
	btnDefFolder.onClick = defNoneFolder; 
	//-------------------------------------------------------------------------
	if ( ( me instanceof Panel) == false){
		winObj.center(); 
		winObj.show();
	}
	//-------------------------------------------------------------------------
})(this);

