﻿
(function(me){
	#include "json2.js"
	#include "FsPO.jsxinc"
	var resultObj = null;
	//-------------------------------------------------------------------------
	function getComp()
	{
		var ret = null;
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem){
			ret = ac;
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function getLayer()
	{
		var ret = null;
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem){
			if ( ac.selectedLayers.length>0){
				ret = ac.selectedLayers[0];
			}
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	function getProperty()
	{
		var ret = null;
		var lyr = getLayer();
		if ( lyr != null){
			if ( lyr.selectedProperties.length>0){
				for ( var i=0; i<lyr.selectedProperties.length; i++){
					if
					( (lyr.selectedProperties[i] instanceof PropertyGroup)||(lyr.selectedProperties[i] instanceof MaskPropertyGroup))
					{
						ret = lyr.selectedProperties[i];
						break;
					}else if (lyr.selectedProperties[i] instanceof Property){
						ret = lyr.selectedProperties[i];
						break;
					}
				}
			}
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	var winObj = ( me instanceof Panel) ? me : new Window("palette", "getParamObject", [ 0,  0,  461,  455]  ,{resizeable:true, maximizeButton:true, minimizeButton:true});
	//-------------------------------------------------------------------------
/*
			opt.marker = true;
			opt.mask = true;
			opt.contents = truek
			opt.effects = true;
			opt.transform = true;
*/

	var btnGetLayer = winObj.add("button", [  10,   10,   10+ 100,   10+  30], "Layerを獲得" );
	var x = 120;
	var dx = 50;
	var cbLayer = winObj.add("checkbox", [ x,   10,  x+ dx,   10+  30], "Base");
	 x += dx;
	dx = 60;
	var cbMarker = winObj.add("checkbox", [ x,   10,  x+ dx,   10+  30], "Marker");
	 x += dx;
	dx = 50;
	var cbMask = winObj.add("checkbox", [ x,   10,  x + dx,   10+  30], "Mask");
	 x += dx;
	dx = 70;
	var cbContents = winObj.add("checkbox", [ x,   10,  x+ dx,   10+  30], "Contents");
	 x += dx;
	dx = 60;
	var cbEffects = winObj.add("checkbox", [ x,   10,  x+ dx,   10+  30], "Effects");
	 x += dx;
	dx = 80;
	var cbTransform = winObj.add("checkbox", [ x,   10,  x+ dx,   10+  30], "Transform");

	var btnGetProperty = winObj.add("button", [ 10,   45,  10+ 100,   45+  30], "Propertyを獲得" );
	var cbJson2js = winObj.add("checkbox", [ 230,   45,  230+ 180,   45+  30], "json2.jsを使う");
	var edResult = winObj.add("edittext",    [   10,    80,   10+ 400,   80+ 400], "", { multiline:true, scrollable:true });
	var btnRedo = winObj.add("button", [ 415,   80,  415+  60,   80 + 270], "設定" );
	var btnSave = winObj.add("button", [ 415,  355,  415+  60,  350+  100], "保存" );
	cbJson2js.value = true;

	cbLayer.value = true;
	cbMarker.value = true;
	cbMask.value = true;
	cbContents.value = true;
	cbEffects.value = true;
	cbTransform.value = true;
	//-------------------------------------------------------------------------
	function resizeWin()
	{
		var b = winObj.bounds;
		var eb = edResult.bounds;
		eb[2] = b.width - 70;
		eb[3] = b.height - 5;
		edResult.bounds = eb;
		
		var rb = btnRedo.bounds;
		rb[0] = b.width - 65;
		rb[2] = b.width - 5;
		rb[3] = b.height - 110;
		btnRedo.bounds = rb;
		var sb = btnSave.bounds;
		sb[0] = b.width - 65;
		sb[2] = b.width - 5;
		sb[1] = b.height - 105;
		sb[3] = b.height - 5;
		btnSave.bounds = sb;
	}
	resizeWin();
	winObj.onResize =resizeWin;
	btnSave.onClick = function() { alert("");}
	//-------------------------------------------------------------------------
	function getLayerPO()
	{
		var lyr = getLayer();
		if ( lyr != null){

			var opt = new Object;
			opt.layer =  cbLayer.value;
			opt.marker =  cbMarker.value;
			opt.mask =  cbMask.value;
			opt.contents =  cbContents.value;
			opt.effects =  cbEffects.value;
			opt.transform =  cbTransform.value;


			resultObj = lyr.getLayerPO(opt);
			var js = "";
			if ( cbJson2js.value == true){
				js =  JSON.stringify(resultObj,null," ");
			}else{
				js = resultObj.toSource();
			}
			edResult.text = js;
		}else{
			alert("レイヤーをひとつ選んでください。");
		}
	}
	btnGetLayer.onClick = getLayerPO;
	//-------------------------------------------------------------------------
	function getPropertyPO()
	{
		var pg = getProperty();
		if ( pg != null){
			resultObj = null;
			resultObj = pg.getPO();
			var js = "";
			if ( cbJson2js.value == true){
				js =  JSON.stringify(resultObj,null," ");
			}else{
				js = resultObj.toSource();
			}
			edResult.text = js;
		}else{
			alert("プロパティを選んでください。");
		}
	}
	btnGetProperty.onClick = getPropertyPO;
	//-------------------------------------------------------------------------
	function redo()
	{
		var js = edResult.text;
		var obj = null;
		if ( cbJson2js.value == true){
			obj = JSON.parse(js);
		}else{
			obj = eval(js);
		}
		var mn = null;
		if (obj.matchName != undefined) mn = obj.matchName;
		if ( mn == null){
			alert("不正なコードです");
		}else{
			if ( (obj.matchName == "ADBE Vector Layer") || (obj.matchName == "ADBE Text Layer") || (obj.matchName == "ADBE AV Layer")){
				var ac = getComp();
				if ( ac == null){
					alert("コンポを選んでください！");
				}else{
					ac.addLayerPO(obj);
				}
			}else{
				var pg = getProperty();
				if ( pg != null){
					if ( pg.matchName == obj.matchName){
						pg.setPO(obj);
					}else{
						alert("プロパティの型が違います。\n target = " +pg.matchName +"\ninsert = " + obj.matchName);
					}
				}else{
					alert("プロパティを選んでください。");
				}
			}
		}
	}
	btnRedo.onClick = redo;
	//-------------------------------------------------------------------------
	function saveCode()
	{
		var code = edResult.text;
		if ( code != ""){
			var f = File.saveDialog("SampleCode","*.jsx");
			if ( f!=null){
				f.encoding = "UTF-8";
				f.open("w");
				try{
					f.write(code);
				}finally{
					f.close();
				}
			}
		}else{
			alert("コードがない");
		}
	}
	btnSave.onClick = saveCode;
	
	//-------------------------------------------------------------------------
	if ( ( me instanceof Panel) == false){
		winObj.center(); 
		winObj.show();
	}
	//-------------------------------------------------------------------------
})(this);


