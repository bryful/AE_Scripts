﻿//getPropertyAccessCode.jsxの確認用のスクリプト
/*
	getPropertyAccessCode.jsxで作ったコードを確認するためのスクリプト
*/
//-------------------------
//ここから

var p = app.project.item(2).layer(1).property(6).property(2); 

//ここまでを挿げ替える
//-------------------------
var v = p.value;

var s = "";
if ( v instanceof Array){
	if ( v.length>0){
		for ( var i=0; i<v.length;i++){
			s += i + ": "+ v[i] +"\n";
		}
	}else{
		s = "Array Length zero\n";
	}
}else{
	s = v + "";
}

alert(s);

