﻿//選択したマスクシェイプをあれこれする
//---------------------------------------------------------------------------
function shapeUtil(sp)
{
	var maskShape = null;
	this.centerX = 0;
	this.centerY = 0;
	//-------------------------------
	this.setValue = function(ms)
	{
		if ( ms instanceof Shape)
		{
			maskShape = ms
		}else{
			maskShape = null;
		}
	}
	//-------------------------------
	//コンストラクタの処理
	this.setValue(sp);
	//-------------------------------
	this.getValue = function()
	{
		return maskShape;
	}
	//-------------------------------
	//上下反転したShapeを返す
	this.flipVur = function()
	{
		var y = this.centerY;
		if (maskShape == null) return null;
		var vt = new Array;
		for ( var i=0; i<maskShape.vertices.length; i++)
		{
			var o = new Array;
			o.push(maskShape.vertices[i][0]);
			o.push(y - (maskShape.vertices[i][1] -y));
			vt.push(o);
		}
		var it = new Array;
		for ( var i=0; i<maskShape.inTangents.length; i++)
		{
			var o = new Array;
			o.push(maskShape.inTangents[i][0]);
			o.push(maskShape.inTangents[i][1] *-1);
			it.push(o);
		}
		var ot = new Array;
		for ( var i=0; i<maskShape.outTangents.length; i++)
		{
			var o = new Array;
			o.push(maskShape.outTangents[i][0]);
			o.push(maskShape.outTangents[i][1] *-1);
			ot.push(o);
		}
		var myShape = new Shape();
		myShape.vertices = vt;
		myShape.inTangents = it;
		myShape.outTangents =ot;
		myShape.closed = maskShape.closed;
		return myShape;
	}
	//-------------------------------
	//左右反転したShapeを返す
	this.flipHor = function ()
	{
		if (maskShape == null) return null;
		var x = this.centerX;
		var vt = new Array;
		for ( var i=0; i<maskShape.vertices.length; i++)
		{
			var o = new Array;
			o.push(x - (maskShape.vertices[i][0] - x));
			o.push(maskShape.vertices[i][1]);
			vt.push(o);
		}
		var it = new Array;
		for ( var i=0; i<maskShape.inTangents.length; i++)
		{
			var o = new Array;
			o.push(maskShape.inTangents[i][0] *-1);
			o.push(maskShape.inTangents[i][1]);
			it.push(o);
		}
		var ot = new Array;
		for ( var i=0; i<maskShape.outTangents.length; i++)
		{
			var o = new Array;
			o.push(maskShape.outTangents[i][0] *-1);
			o.push(maskShape.outTangents[i][1]);
			ot.push(o);
		}
		var myShape = new Shape();
		myShape.vertices = vt;
		myShape.inTangents = it;
		myShape.outTangents =ot;
		return myShape;
	}
	//-------------------------------
	//半回転したShapeを返す
	this.halfTurn = function ()
	{
		if (maskShape == null) return null;
		var x = this.centerX;
		var y = this.centerY;
		var vt = new Array;
		for ( var i=0; i<maskShape.vertices.length; i++)
		{
			var o = new Array;
			o.push(x - (maskShape.vertices[i][0] -x));
			o.push(y - (maskShape.vertices[i][1] -y));
			vt.push(o);
		}
		var it = new Array;
		for ( var i=0; i<maskShape.inTangents.length; i++)
		{
			var o = new Array;
			o.push(maskShape.inTangents[i][0] *-1);
			o.push(maskShape.inTangents[i][1] *-1);
			it.push(o);
		}
		var ot = new Array;
		for ( var i=0; i<maskShape.outTangents.length; i++)
		{
			var o = new Array;
			o.push(maskShape.outTangents[i][0] *-1);
			o.push(maskShape.outTangents[i][1] *-1);
			ot.push(o);
		}
		var myShape = new Shape();
		myShape.vertices = vt;
		myShape.inTangents = it;
		myShape.outTangents =ot;
		return myShape;	
	}
}


function shapeToLine(tShape)
{
	var line = "";
	for ( var i=0; i<tShape.vertices.length; i++)
	{
		line += tShape.vertices[i][0] +",";
		line += tShape.vertices[i][1] +",";
	}
	for ( var i=0; i<tShape.inTangents.length; i++)
	{
		line += tShape.inTangents[i][0] +",";
		line += tShape.inTangents[i][1] +",";
	}
	for ( var i=0; i<tShape.outTangents.length; i++)
	{
		line += tShape.outTangents[i][0] +",";
		line += tShape.outTangents[i][1];
		if ( i < tShape.outTangents.length -1) line +=",";
	}
	return line;
}
//---------------------------------------------------------------------------
function msDialog()
{	//---------------

	this.winObj = new Window("dialog", "MaskShape", [22, 29, 22+240, 29+171]);
	this.groupBox1 = this.winObj.add("panel", [12, 12, 12+209, 12+106], "マスクシェイプをあれこれする" );
	this.rbFlipHor = this.groupBox1.add("radiobutton", [41, 28, 41+90, 28+16], "左右反転する" );
	this.rbFlipVur = this.groupBox1.add("radiobutton", [41, 50, 41+90, 50+16], "上下反転する" );
	this.rbHarfTurn = this.groupBox1.add("radiobutton", [41, 72, 41+78, 72+16], "半回転する" );
	this.btnOK = this.winObj.add("button", [56, 130, 56+75, 130+23], "OK", {name:'ok'});
	this.btnCancel = this.winObj.add("button", [146, 130, 146+75, 130+23], "Cancel", {name:'cancel'});

	var resultvalue = 0;
	this.rbFlipHor.value = true;
	this.rbFlipHor.onClick = function (){resultvalue = 0;}
	this.rbFlipVur.onClick = function (){resultvalue = 1;}
	this.rbHarfTurn.onClick = function (){resultvalue = 2;}

	this.result = function()
	{
		return resultvalue;
	}
	//---------------
	this.show = function()
	{
		this.winObj.center();
		return this.winObj.show();
	}
	//---------------
}


//---------------------------------------------------------------------------
var targetMask = new Array;
var activeComp = app.project.activeItem;
if ( (activeComp!=null)&&(activeComp instanceof CompItem) ) {
	var selectedLayers = activeComp.selectedLayers;

	if ( (selectedLayers!=null)&&(selectedLayers.length>0) ){
		for (var i = 0; i < selectedLayers.length; i++) {
			var maskG = selectedLayers[i].mask;
			if ( maskG.numProperties>0) {
				for ( var j=1; j<=maskG.numProperties;j++){
					var msk = maskG(j).maskShape;
					//選択されたマスクシェイプを配列へ
					if ( msk.selected == true){
						targetMask.push(msk);
					}
				}
			}
		}
	}
}
if ( targetMask.length>0){

	var dlg = new msDialog;
	if ( dlg.show() == 1){

		
		var su = new shapeUtil();
		//反転の中心を指定
		su.centerX = activeComp.width/2;
		su.centerY = activeComp.height/2;
		//関数の切り替え
		//execって適当な関数を動的に作成
		var execCaption = "";
		switch(dlg.result())
		{
			case 1 : 
				su.exec = su.flipVur;
				execCaption = "マスクシェイプを上下反転";
				break;
			case 2 :
				su.exec = su.halfTurn;
				execCaption = "マスクシェイプを半回転";
				break;
			default:
				su.exec = su.flipHor;
				execCaption = "マスクシェイプを左右反転";
				break;
		}
		app.beginUndoGroup(execCaption);
		for (var i=0; i<targetMask.length; i++)
		{
			if (targetMask[i].numKeys >0)
			{
				for ( var k=1; k<=targetMask[i].numKeys;k++)
				{
					su.setValue(targetMask[i].keyValue(k));
					targetMask[i].setValueAtKey(k,su.exec());
				}
			}else{
				su.setValue(targetMask[i].value);
				targetMask[i].setValue(su.exec());
				
			}
		}
		app.endUndoGroup();
	}
}else{
	alert("Maskが選択されていません");
}
