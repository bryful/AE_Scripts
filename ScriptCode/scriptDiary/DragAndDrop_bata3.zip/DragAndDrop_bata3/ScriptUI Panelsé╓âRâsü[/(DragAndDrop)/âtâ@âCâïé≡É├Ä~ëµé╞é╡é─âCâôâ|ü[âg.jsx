﻿/*
	AE_DragAndDropのサンプルスクリプト
*/
//----------------------------------------------------------------
//関数名は変更しない
function _fileArrayFunc(ary)
{
	//-----------------------------------
	//引数のチェック
	if ( ( ary instanceof Array)==false) return;

	//-----------------------------------
	var ret = "";
	if ( ary.length<=0) {
		ret ="no Files";
	}else{
		//自作インポートクラス
		var FsImport = new FsImporter;
		
		app.beginUndoGroup("ファイルを静止画としてインポート");
		//インポートするフォルダを作成。返り値は配列なので注意
		var p = ["01_src","_import"];
		if ( (_importPath != undefined)&&(_importPath instanceof Array)){
			p = _importPath;
		}
		var importFolders = FsImport.findFolderByPathArray(p);
		
		for ( var i=0; i< ary.length; i++){
			if ( ary[i] instanceof File) {
				//自作クラスで画像識別
				var pf = new FsPictureFile(ary[i]);
				if ( (pf.isPicture() == true)||(pf.isMovie() == true)){
					//指定したフォルダにインポート
					FsImport.import(pf.importOptions(),importFolders[0]);
				}
			}
		}
		app.endUndoGroup();
	}
}
//----------------------------------------------------------------

