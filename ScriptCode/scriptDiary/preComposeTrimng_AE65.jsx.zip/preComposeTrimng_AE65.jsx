﻿//**********************************************************
// After Effects 6.5用に修正
// マスクパスの機能は都合で削除
//**********************************************************
function preComposeTriming()
{
	//エラーメッセージ
	var errMes = "";
	var scriptName = "preComposeTriming";
	
	var useGuideFrame = false;
 	var isGuideFrame = false;
	//---------------------------------------------
	function getTarget()
	{
		var ret = new Object;
		ret.enabled = false;
		ret.cmp = null;
		ret.lyr = null;
		if ( app.project.activeItem instanceof CompItem){
			ret.cmp = app.project.activeItem;
		}else{
			errMes += "コンポをアクティブにして、レイヤを選択してください。\n";
			return ret;
		}
		if ( ret.cmp.selectedLayers.length==1) {
			var p = ret.cmp.selectedLayers[0].source;
			if ( ( p ==null)||( p ==undefined)){
				errMes += "普通のレイヤのみ対応です。\n";
				return ret;
			}
			//F's GuideFrameを使ってるか確認
			var fx = ret.cmp.selectedLayers[0].property("エフェクト").property("F's GuideFrame");
			isGuideFrame = ( fx != null);

			if ( isGuideFrame==true) {
				if ( (fx.property("F's GuideFrame-0002").numKeys>1)||(fx.property("F's GuideFrame-0003").numKeys>1)){
					errMes += "F's GuideFrameにキーフレームがあります。\n";
					return ret;
				}
				useGuideFrame = true;
			}
			var p = ret.cmp.selectedLayers[0];
			if ( p.threeDLayer == true){
				errMes += "3Dレイヤには対応していません。\n";
				return ret;
			}
			if ( p.collapseTransformation == true){
				errMes += "コラップストランスフォームはOFFにしてください\n";
				return ret;
			}
			if ( 
				(p.property("Anchor Point").numKeys>1)||
				(p.property("Scale").numKeys>1)||
				(p.property("Position").numKeys>1) ||
				(p.property("Rotation").numKeys>1)
				){
				errMes += "キーフレームがあります。\n";
				return ret;
			}
			if ( p.property("Rotation").value !=0){
				errMes += "回転の数値が０じゃない\n";
				return ret;
			}
			ret.lyr = ret.cmp.selectedLayers[0];
		}else{
			errMes += "レイヤは一つだけ選択してください。\n";
			return ret;
		}
		ret.enabled = true;
		ret.newName = ret.cmp.name + "_" + ret.lyr.name;
		if (ret.newName.length>16) ret.newName = ret.newName.substr(0,16);

		ret.duration	= ret.cmp.duration;		//長さ
		ret.startTime	= ret.lyr.startTime;	//スタート
		ret.inPoint		= ret.lyr.inPoint;		//
		ret.outPoint	= ret.lyr.outPoint;		//
		
		return ret;
	}
	//---------------------------------------------
	function getGuideFrameToRect(target)
	{
		var fx = target.lyr.property("エフェクト").property("F's GuideFrame");
		var ret = new Object;
		ret.x0 =0;
		ret.y0 =0;
		ret.x1 =0;
		ret.y1 =0;
		if ( (fx==null)||(fx==undefined)) return ret;
		fx.enabled = false;
		//切り取り範囲を求める
		var tl = fx.property("F's GuideFrame-0002").value;
		ret.x0 = Math.floor(tl[0]);
		ret.y0 = Math.floor(tl[1]);
		var br = fx.property("F's GuideFrame-0003").value;
		ret.x1 = Math.floor(br[0]);
		ret.y1 = Math.floor(br[1]);
		if ( ret.x0>ret.x1) { var tmp = ret.x0; ret.x0 = ret.x1; ret.x1 = tmp;}
		if ( ret.y0>ret.y1) { var tmp = ret.y0; ret.y0 = ret.y1; ret.y1 = tmp;}
		return ret;
	
	}
	//---------------------------------------------
	//CompItemのサイズを偶数にする
	function compSizeToInt(target)
	{
		if ( target.cmp instanceof CompItem){
			if ( (target.cmp.width % 2) == 1 ) target.cmp.width -= 1;
			if ( (target.cmp.height % 2) == 1 ) target.cmp.height -= 1;
		}
	}
	//---------------------------------------------
	//Layerの位置・アンカーポイントを整数化
	function layerPosToInt(target)
	{
		function pointToInt(ary)
		{
			ary[0] = Math.floor(ary[0]);
			ary[1] = Math.floor(ary[1]);
			return ary;
		}
		if ( target.cmp.numLayers>0){
			for ( var i=1; i<=target.cmp.numLayers; i++){
				var lyr = target.cmp.layer(i);
				if ( lyr instanceof AVLayer){
					var oAnc = lyr.property("Anchor Point");
					var oPos = lyr.property("Position");
					var oPosV = pointToInt(oPos.value);
					oAnc.setValue(pointToInt(oAnc.value));
					oPos.setValue(pointToInt(oPos.value));
				}
			}
		}
	}
	//---------------------------------------------
	function executeMain(target)
	{
		if (( target.cmp instanceof CompItem)==false){
			errMes += "executeMain CompItem引数エラー\n";
			return;
		}
		else if (( target.lyr instanceof AVLayer)==false){
			errMes += "executeMain AVLayer引数エラー\n";
			return;
		}
		var cccc = 0
		
		//compSizeToInt(target.cmp);
		//layerPosToInt(target.lyr);
		
		var prm = new Object;
		prm = getGuideFrameToRect(target);
		prm.x0 = Math.floor(prm.x0/4) * 4;
		prm.y0 = Math.floor(prm.y0/4) * 4;
		prm.x1 = Math.floor(prm.x1/4 + 1) * 4;
		prm.y1 = Math.floor(prm.y1/4 + 1) * 4;
		
		//範囲の確認
		if ( prm.x0<0) prm.x0 = 0;
		if (prm.x1>target.lyr.width) prm.x1 = target.lyr.width;
		if ( prm.y0<0) prm.y0 = 0;
		if (prm.y1>target.lyr.height) prm.y1 = target.lyr.height;

		//大きさを求める。大きさは必ず偶数になるように調整
		var w = prm.x1 - prm.x0;
		var h = prm.y1 - prm.y0;
		if ( (w<=16)||(h<=16)) {
			errMes += "切り取り範囲が小さすぎる\n";
			return;
		}
		//コンポ作成
		var preCompCell =  target.cmp.parentFolder.items.addComp(
			target.newName,
			w,
			h,
			target.cmp.pixelAspect,
			target.cmp.duration,
			target.cmp.frameRate);
		preCompCell.duration = target.cmp.duration;
		//コンポに追加
		var nLayer = preCompCell.layers.add(target.lyr.source);
		
		//位置を修正
		var anc = nLayer.property("Anchor Point");
		var ancV = anc.value;
		ancV[0] = prm.x0 + w/2;
		ancV[1] = prm.y0 + h/2;
		anc.setValue(ancV);

		nLayer.startTime = target.startTime;
		//開始終わり位置を設定
		nLayer.inPoint = target.lyr.inPoint;
		nLayer.outPoint = target.lyr.outPoint;
		
		//元のコンポに張りなおす
		var n2Layer = target.cmp.layers.add(preCompCell);
		n2Layer.startTime = 0;
		n2Layer.moveBefore(target.lyr);
		n2Layer.inPoint = target.lyr.inPoint;
		n2Layer.outPoint = target.lyr.outPoint;
		
		var oAnc = target.lyr.property("Anchor Point");
		var oPos = target.lyr.property("Position");
		var oAncV = oAnc.value;
		var oPosV = oPos.value;
		var nAnc = n2Layer.property("Anchor Point");
		var nPos = n2Layer.property("Position");

		var ax = oAncV[0] - prm.x0;
		var ay = oAncV[1] - prm.y0;

		nAnc.setValue([ax,ay]);
		nPos.setValue(oPosV);
		
		//アンカーを調整して位置を合わせてあるので、スケールはただコピーするだけ
		n2Layer.property("Scale").setValue(
			target.lyr.property("Scale").value
			);
			
		//全部無事に終わった。
	}
	//---------------------------------------------
	this.dispErrMes = function()
	{
		if ( errMes != "") alert ( errMes );
	}
	//---------------------------------------------
	////////////////////////////////////////////////////////////////////////////////////////////////
	this.showDialog = function()
	{
		errMes = "";
		var target = getTarget();
		if ( target.enabled == false ){
			this.dispErrMes();
			return;
		}
		//---------------
		var winObj = new Window("dialog", "プリコンポーズトリミング", [  88,  116,   88+ 337,  116+ 194]);
		
		var pnlNewCompName = winObj.add("panel", [   5,   12,    5+ 320,   12+  53], "新しく作るコンポ名");
		var tbNewCompName = pnlNewCompName.add("edittext", [   7,   18,    7+ 307,   18+  19], "", {readonly:false, multiline:false});
		var btnExec = winObj.add("button", [ 160,  149,  160+  73,  149+  33], "実行");
		var btnClose = winObj.add("button", [ 246,  149,  246+  73,  149+  33], "閉じる");

		//---------------
		tbNewCompName.text = target.newName;
		btnExec.dispErrMes = this.dispErrMes;
		
		btnExec.onClick = function()
		{
			target.newName = tbNewCompName.text;
			if ( target.newName != ""){
				app.beginUndoGroup(scriptName);
				executeMain(target);
				app.endUndoGroup();
			}else{
				errMes += "コンポ名を入力してください\n";
			}
			winObj.close();
			this.dispErrMes();
		}
		btnClose.onClick = function()
		{
			winObj.close();
		}
		winObj.center(); 
		winObj.show();
	}
	////////////////////////////////////////////////////////////////////////////////////////////////

}
//**********************************************************


var preComposeTrimingDlg = new preComposeTriming();
preComposeTrimingDlg.showDialog();
