﻿///////////////////////////////////////////////////////////////////////////////
//*****************************************************************************
/*
	時間を便利に扱うObject
*/
//*****************************************************************************
function jTime()
{
	//*************************************************************
	//明示的に数値と宣言
	var value = 0;
	var mode = 3;
	 /*
	 0"時間",
	 1"Frm",
	 2"秒+Frm",
	 3"P+Frm",
	 4"P+秒+Frm"
	 */
	//数値が負数かどうか
	var frameRate = 24;
	var page = 144;
	var startFrame = app.project.displayStartFrame;
	
	//*************************************************************
	function strToNum(s)
	{
		var v = 0;
		try
		{
			v = eval(s);
			return v;
		}catch(e){
			//alert("strToNum: "+e);
			return Number.NaN;
		}
	}
	//*************************************************************
	function chkStr(s)
	{
		var ret = "";
		if (s == "") return ret;
		for ( var i=0; i<s.length; i++){
			var c =  s.charAt(i);
			if ( (c>="0")&&( c<="9")) {ret += c;}
			else if ( (c==".")||(c=="+")||(c=="p") ) {ret += c;}
			else if ( i==0){
				if ( (c=="-")||(c=="－")||(c=="ー")){
					ret +="-";
				}
			}
			else
			{
				switch(c){
					case "０": c = "0";break;
					case "１": c = "1";break;
					case "２": c = "2";break;
					case "３": c = "3";break;
					case "４": c = "4";break;
					case "５": c = "5";break;
					case "６": c = "6";break;
					case "７": c = "7";break;
					case "８": c = "8";break;
					case "９": c = "9";break;
					case "。": c = ".";break;
					case "P": c = "p";break;
					case "ｐ": c = "p";break;
					case "Ｐ": c = "p";break;
					case "＋": c = "+";break;
					default:
						c = "";
						break;
				}
				ret +=c;
			}
		}
		return ret;
	}
	//*************************************************************
	function strToDur(s)
	{
		if (s.indexOf("+")>=0){
			var sa = s.split("+");
			var s = strToNum(sa[0]);
			var k = strToNum(sa[1]) - startFrame;
		
			return s + ( k / frameRate);
		}else if (s.indexOf(".")<0) {
			return ( strToNum(s)- startFrame) / frameRate;
		}else{
			return strToNum(s);
		}
	}
	//*************************************************************
	this.setValueStr = function(line)
	{
		var ret = 0;
		var _line = chkStr(line);
		if ( (_line == "")||(_line == "-")) {
			value = 0;
			return true;
		}
		//－対策
		var minus = 1;
		if (_line[0] == "-") {
			minus = -1;
			_line = _line.substr(1);
		}
		var lp = _line.split("p");

		if ( lp.length>2) return false;
		
		
		if (lp.length == 1){
			ret = strToDur(lp[0]);
		}else if (lp.length == 2){
			if ( (lp[0].indexOf("+")>=0)||(lp[0].indexOf(".")>=0) ) {
				return false;
			}
			var pg = 0;
			try{
				var pp = eval(lp[0]) -1;
				if ( pp<0) pp=0;
				pg =  pp * (page/frameRate);
			}catch(e){
				return false;
			}
			
			ret = pg + strToDur(lp[1]);
		}
		if ( isNaN(ret)==false){
			value = ret * minus;
			return true;
		}else{
			return false;
		}
	}
	//*************************************************************
	this.getValueStr = function()
	{
		var line ="";
		switch(mode)
		{
		case 0: 
			line = (value ) +"";
			if ( line.indexOf(".")<0) line +=".0";
			break;
		case 1:
			line = Math.round(value * frameRate) + startFrame;
			break;
		case 2:
			var frm = Math.round(value * frameRate);
			var s = Math.floor(frm / frameRate);
			var k = Math.round(frm % frameRate) + startFrame;
			line = s + "+" + k;
			break;
		case 3:
			var frm = Math.round(value * frameRate);
			var p = Math.floor(frm / page) + 1;
			var k = Math.round(frm % page) + startFrame;
			if ( p > 1){
				line = p + "p" + k;
			}else{
				line = k;
			}
			break;
		case 4:
			var frm = Math.round(value * frameRate);
			var p = Math.floor(frm / page) + 1;
			var s = Math.floor( (frm % page) / frameRate);
			var k = Math.round( (frm % page) % frameRate)+ startFrame;
			if ( p>1){
				line = p + "p" + s + "+" + k;
			}else{
				line = s + "+" + k;
			}
			break;
		}
		return line;
	}
	//*************************************************************
	this.setDuration = function(v)
	{
		if ( isNaN(v) ==false){
			value = v;
		}
	}
	//*************************************************************
	this.getDuration = function()
	{
		return value;
	}
	//*************************************************************
	this.setFrameRate = function(v)
	{
		if ( isNaN(v) ==false){
			frameRate = v;
		}
	}
	//*************************************************************
	this.getFrameRate = function()
	{
		return frameRate;
	}
	//*************************************************************
	this.setPage = function(v)
	{
		if ( isNaN(v) ==false){
			page = v;
		}
	}
	//*************************************************************
	this.getPage = function()
	{
		return page;
	}
	//*************************************************************
	this.getMode = function()
	{
		return mode;
	}
	//*************************************************************
	this.setMode = function(v)
	{
		if (v<=0) mode = 0;
		else if (v>=4) mode = 4;
		else mode = v;
	}
	//*************************************************************
	this.clear = function()
	{
		value = 0;
	}
	//*************************************************************
	this.getTime = function()
	{
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem)
		{
			value = ac.time;
		}else{
			alert("コンポを選択してください。")
		}
	}
	//*************************************************************
	this.setTime = function()
	{
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem)
		{
			var v = value;
			if ( ( v>=0)&&(v<ac.duration)) 
				if (ac.time != v)
					ac.time = v;
		}else{
			alert("コンポを選択してください。")
		}
	}
	//*************************************************************
	this.setTimePluss = function()
	{
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem)
		{
			var v = ac.time + value;
			if ( ( v>=0)&&(v<ac.duration)) 
				if (ac.time != v)
					ac.time = v;
		}else{
			alert("コンポを選択してください。")
		}
	}
	//*************************************************************
	this.setTimeMinus = function()
	{
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem)
		{
			var v = ac.time - value;
			if ( ( v>=0)&&(v<ac.duration)) 
				if (ac.time != v)
					ac.time = v;
		}else{
			alert("コンポを選択してください。")
		}
	}
}
///////////////////////////////////////////////////////////////////////////////
function timeBankDlg(me)
{	
	//--------------------------------------------
	function getTime()
	{
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem)
		{
			return ac.time;
		}else{
			alert("コンポを選択してください。");
			return 0;
		}
	}

	var btnCount = 8;
	//---------------
	this.winObj = ( me instanceof Panel) ? me : new Window("palette", "timeBank", [88, 116, 88+131, 116+260]);

	this.btnPush0 = this.winObj.add("button", [3, 25, 3+28, 25+26], "+");
	this.btnPush1 = this.winObj.add("button", [3, 54, 3+28, 54+26], "+");
	this.btnPush2 = this.winObj.add("button", [3, 83, 3+28, 83+26], "+");
	this.btnPush3 = this.winObj.add("button", [3, 112, 3+28, 112+26], "+");
	this.btnPush4 = this.winObj.add("button", [3, 141, 3+28, 141+26], "+");
	this.btnPush5 = this.winObj.add("button", [3, 170, 3+28, 170+26], "+");
	this.btnPush6 = this.winObj.add("button", [3, 199, 3+28, 199+26], "+");
	this.btnPush7 = this.winObj.add("button", [3, 228, 3+28, 228+26], "+");
	this.btnPop0 = this.winObj.add("button", [32, 25, 32+52, 25+26], "Pop");
	this.btnPop1 = this.winObj.add("button", [32, 54, 32+52, 54+26], "Pop");
	this.btnPop2 = this.winObj.add("button", [32, 83, 32+52, 83+26], "Pop");
	this.btnPop3 = this.winObj.add("button", [32, 112, 32+52, 112+26], "Pop");
	this.btnPop4 = this.winObj.add("button", [32, 141, 32+52, 141+26], "Pop");
	this.btnPop5 = this.winObj.add("button", [32, 170, 32+52, 170+26], "Pop");
	this.btnPop6 = this.winObj.add("button", [32, 199, 32+52, 199+26], "Pop");
	this.btnPop7 = this.winObj.add("button", [32, 228, 32+52, 228+26], "Pop");
	this.tbMemo0 = this.winObj.add("edittext", [86, 28, 86+40, 28+22], "" );
	this.tbMemo1 = this.winObj.add("edittext", [86, 56, 86+40, 56+22], "" );
	this.tbMemo2 = this.winObj.add("edittext", [86, 85, 86+40, 85+22], "" );
	this.tbMemo3 = this.winObj.add("edittext", [85, 114, 85+40, 114+22], "" );
	this.tbMemo4 = this.winObj.add("edittext", [86, 143, 86+40, 143+22], "" );
	this.tbMemo5 = this.winObj.add("edittext", [85, 172, 85+40, 172+22], "" );
	this.tbMemo6 = this.winObj.add("edittext", [86, 201, 86+40, 201+22], "" );
	this.tbMemo7 = this.winObj.add("edittext", [85, 230, 85+40, 230+22], "" );
	this.lbMemo = this.winObj.add("statictext", [88, 13, 88+35, 13+12], "Memo" );

	var cmbMode = this.winObj.add("dropdownlist", [3, 2, 3+81, 2+20], ["時間","Frm","秒+Frm","P+Frm","P+秒+Frm" ] );


	//---------------
	var pushArray = new Array;
	var popArray = new Array;
	var bankArray = new Array;
	var mode =3;

	pushArray.push(this.btnPush0);
	pushArray.push(this.btnPush1);
	pushArray.push(this.btnPush2);
	pushArray.push(this.btnPush3);
	pushArray.push(this.btnPush4);
	pushArray.push(this.btnPush5);
	pushArray.push(this.btnPush6);
	pushArray.push(this.btnPush7);

	popArray.push(this.btnPop0);
	popArray.push(this.btnPop1);
	popArray.push(this.btnPop2);
	popArray.push(this.btnPop3);
	popArray.push(this.btnPop4);
	popArray.push(this.btnPop5);
	popArray.push(this.btnPop6);
	popArray.push(this.btnPop7);

	
	//--------------------------------------------
	for (var i=0; i<btnCount; i++){
		bankArray.push(new jTime());
		bankArray[i].setDuration(i);
	}
	//--------------------------------------------
	function pushT()
	{
		var idx = this.id;
		bankArray[idx].setDuration(getTime());
		popArray[idx].flag = true;;
		popArray[idx].disp();
	}
	//--------------------------------------------
	function dispT()
	{
		var idx = this.id;
		if ( this.flag == false){
			this.text = "pop";
		}else{
			this.text = bankArray[idx].getValueStr();
		}
	}
	//--------------------------------------------
	function popT()
	{
		var idx = this.id;
		if ( popArray[idx].flag == true){
			bankArray[idx].setTime();
		}
	}
	//--------------------------------------------
	for (var i=0; i<btnCount; i++){
		pushArray[i].id = i;
		popArray[i].id = i;
		popArray[i].flag = false;
		
		popArray[i].disp = dispT;
		pushArray[i].onClick = pushT;
		popArray[i].onClick = popT;
	}
	//--------------------------------------------
	this.getTime = function()
	{
		var ac = app.project.activeItem;
		if ( ac instanceof CompItem)
		{
			return ac.time;
		}else{
			alert("コンポを選択してください。");
			return 0;
		}
	}
	//--------------------------------------------
	function setMode(v)
	{
		var cnt = cmbMode.items.length;
		
		//for ( var i=0;i<cnt; i++) cmbMode.items[i].selected = false;
		if ( v<0) return;
		if ( v<cnt)
		{
			mode = v;
			cmbMode.items[v].selected = true;
			for ( var i=0;i<btnCount;i++){
				bankArray[i].setMode(v);
				popArray[i].disp();
			}
		}
	}
	setMode(3);
	//--------------------------------------------
	function getMode()
	{
		var cnt = cmbMode.items.length;
		
		var ret = -1;
		for ( var i=0;i<cnt; i++) {
			if (cmbMode.items[i].selected == true){
				ret = i;
				break;
			}
		}
		return ret;
	}
	//---------------
	cmbMode.onChange  = function()
	{
		var v = getMode();
		if ( mode != v){
			setMode(v);
		}
	}
	//---------------
	if ( ( me instanceof Panel) == false){ this.winObj.center(); this.winObj.show(); }
}


var dlg = new timeBankDlg(this);

