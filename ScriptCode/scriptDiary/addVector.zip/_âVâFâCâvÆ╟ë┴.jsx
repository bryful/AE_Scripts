﻿(function(me){
	//-------------------------------------------------------------------------
	var addShapeLayer = function()
	{
		var ret = false;
		var targetLayer = null;
		var ac = app.project.activeItem;
		if ( !( ac instanceof CompItem) ) {
			alert("コンポを選択して下さい。")
			return ret;
		}
		if ( ac.selectedLayers.length>0){
			targetLayer = ac.selectedLayers[0];
		}
		app.beginUndoGroup("新規シェイプレイヤー")
		var sl = ac.layers.addShape();
		if ( targetLayer != null)
		{
			sl.moveBefore(targetLayer); 
		}
		app.endUndoGroup();
		return (sp != null);
	}
	//-------------------------------------------------------------------------
	var getVG = function()
	{
		var ret = [];
			var addPB = function(pb)
			{
				var r = false;
				if (ret.length<=0) {
					ret.push(pb);
					r = true;
				}else{
					var b = true;
					for (var i = ret.length-1; i>=0; i--) {
						if ( (ret[i].name == pb.name)&&(ret[i].propertyDepth == pb.propertyDepth)&&(ret[i].propertyIndex == pb.propertyIndex)){
							b = false;
							break;
						}
					}
					if (b) {
						ret.push(pb);
						r = true;
					}
				}
				return r;
			}
		var ac = app.project.activeItem;
		if ( !( ac instanceof CompItem) ) return ret;
		var sel = ac.selectedProperties;
		if (sel.length<=0) {
			if (ac.selectedLayers.length==1) {
				if (ac.selectedLayers[0] instanceof ShapeLayer) {
					ret.push(ac.selectedLayers[0].property("ADBE Root Vectors Group"));
				}
			}
			return ret;
		}
		var info = "";
		for (var i=0; i<sel.length; i++) {
			var p = sel[i];
			while(p!= null) {
				if ( (p.matchName=="ADBE Root Vectors Group" )||(p.matchName=="ADBE Vector Group" )||(p.matchName=="ADBE Vectors Group" )) {
					if (p.matchName=="ADBE Vector Group" ) {
						p = p.property("ADBE Vectors Group");
					}
					addPB(p);
					break;
				}
				p = p.parentProperty;
			}
		}
		return ret;
	}
	//-------------------------------------------------------------------------
	var addVector = function(nm)
	{
		var sel = getVG();
		if (sel.length>0) {
			writeLn("sel.length=" + sel.length);
			var p = sel[sel.length-1];
			app.beginUndoGroup("add: [" + nm+"]");
			var p2 = p.addProperty(nm);
			if (p2.matchName =="ADBE Vector Group"){
				var p3 = p2.property("ADBE Vector Materials Group");
				if (p3.enabled == true) p3.enabled = false;
			}
			
			app.endUndoGroup();
		}
	}
	//-------------------------------------------------------------------------
	var ws = 150;
	var hs = 20;
	var interH = 25;
	var winObj = ( me instanceof Panel) ? me : new Window("palette", "シェイプ追加メニュー", [ 0,  0,  ws+10,  interH *21+40]  ,{resizeable:true, maximizeButton:true, minimizeButton:true});

	//----------------------------------------
	var t = 5;
	var l = 5;
	var btnShape = winObj.add("button",	[  l,   t,   l+ ws,  t +hs+5], "新規シェイプレイヤ" );
	t += interH + 20;
	var btnGroup = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "空のグループ" );
	t += interH + 10;
	var btnRect = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "長方形" );
	t += interH;
	var btnEllipse = winObj.add("button", [  l,   t,   l+ ws,  t +hs], "楕円形" );
	t += interH;
	var btnStar = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "多角形" );
	t += interH;
	var btnPath = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "パス" );
	t += interH + 10;
	var btnFill = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "塗り" );
	t += interH;
	var btnStroke = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "線" );
	t += interH;
	var btnGFill = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "グラデーションの塗り" );
	t += interH;
	var btnGStroke = winObj.add("button", [ l,   t,   l+ ws,  t +hs], "グラデーションの線" );
	t += interH;
	var btnMerge = winObj.add("button", [l,   t,   l+ ws,  t +hs], "パスを結合" );
	t += interH + 10;
	var btnOffset = winObj.add("button", [l,   t,   l+ ws,  t +hs], "パスのオフセット" );
	t += interH;
	var btnPB = winObj.add("button", [l,   t,   l+ ws,  t +hs], "パンク・膨張" );
	t += interH;
	var btnRepeater = winObj.add("button", [l,   t,   l+ ws,  t +hs], "リピーター" );
	t += interH;
	var btnRC = winObj.add("button", [l,   t,   l+ ws,  t +hs], "角を丸くする" );
	t += interH;
	var btnTrim = winObj.add("button", [l,   t,   l+ ws,  t +hs], "パスのトリミング" );
	t += interH;
	var btnTwist = winObj.add("button", [l,   t,   l+ ws,  t +hs], "旋回" );
	t += interH;
	var btnRoughen = winObj.add("button", [l,   t,   l+ ws,  t +hs], "パスのウィグル" );
	t += interH;
	var btnWiggler = winObj.add("button", [l,   t,   l+ ws,  t +hs], "トランスフォームのウィグル" );
	t += interH;
	var btnZigzag = winObj.add("button", [l,   t,   l+ ws,  t +hs], "ジグザグ" );
	t += interH;
	
	//----------------------------------------
	btnShape.onClick = addShapeLayer;
	
	btnGroup.onClick = function(){ addVector("ADBE Vector Group");}
	btnRect.onClick = function(){ addVector("ADBE Vector Shape - Rect");}
	btnEllipse.onClick = function(){ addVector("ADBE Vector Shape - Ellipse");}
	btnStar.onClick = function(){ addVector("ADBE Vector Shape - Star");}
	btnPath.onClick = function(){ addVector("ADBE Vector Shape - Group");}

	btnFill.onClick = function(){ addVector("ADBE Vector Graphic - Fill");}
	btnStroke.onClick = function(){ addVector("ADBE Vector Graphic - Stroke");}
	btnGFill.onClick = function(){ addVector("ADBE Vector Graphic - G-Fill");}
	btnGStroke.onClick = function(){ addVector("ADBE Vector Graphic - G-Stroke");}

	btnMerge.onClick = function(){ addVector("ADBE Vector Filter - Merge");}
	btnOffset.onClick = function(){ addVector("ADBE Vector Filter - Offset");}
	btnPB.onClick = function(){ addVector("ADBE Vector Filter - PB");}
	btnRepeater.onClick = function(){ addVector("ADBE Vector Filter - Repeater");}
	btnRC.onClick = function(){ addVector("ADBE Vector Filter - RC");}
	btnTrim.onClick = function(){ addVector("ADBE Vector Filter - Trim");}

	btnTwist.onClick = function(){ addVector("ADBE Vector Filter - Twist");}
	btnRoughen.onClick = function(){ addVector("ADBE Vector Filter - Roughen");}
	btnWiggler.onClick = function(){ addVector("ADBE Vector Filter - Wiggler");}
	btnZigzag.onClick = function(){ addVector("ADBE Vector Filter - Zigzag");}


	//----------------------------------------
	var resize = function ()
	{
		var btnSet = function(btn,ww) {
			var b = btn.bounds;
			b[2] = ww - 5;
			btn.bounds = b;
		}
		var b = winObj.bounds;
		var w = b[2] - b[0];
		btnSet(btnShape,w);
		btnSet(btnGroup,w);
		btnSet(btnRect,w);
		btnSet(btnEllipse,w);
		btnSet(btnStar,w);
		btnSet(btnPath,w);
		btnSet(btnFill,w);
		btnSet(btnStroke,w);
		btnSet(btnGFill,w);
		btnSet(btnGStroke,w);
		btnSet(btnPath,w);

		btnSet(btnMerge,w);
		btnSet(btnOffset,w);
		btnSet(btnPB,w);
		btnSet(btnRepeater,w);
		btnSet(btnRC,w);
		btnSet(btnTrim,w);

		btnSet(btnTwist,w);
		btnSet(btnRoughen,w);
		btnSet(btnWiggler,w);
		btnSet(btnZigzag,w);

	}
	resize();
	winObj.onResize = resize;
	//-------------------------------------------------------------------------
	if ( ( me instanceof Panel) == false){
		winObj.center(); 
		winObj.show();
	}

})(this);
