﻿(function (me)
{
	var isEditMode		= false;
	var targetComp		= null;
	var targetLayer		= null;
	var targetProperty	= null;
	
	var isPanel = ( me instanceof Panel);
	///////////////////////////////////////////////////////////////////////////////////////////////
	var eleListIndex = -1;
	var eleList = new Array(
		"グローバルオブジェクト",
		"Time Conversion",
		"Vector Math",
		"Random Numbers",
		"Color Conversion",
		"その他の演算メソッド",
		"Comp",
		"Footage",
		"Layer サブオブジェクト",
		"Layer General",
		"Layer Properties",
		"Layer 3D",
		"Layer Space Transforms",
		"Camera",
		"Effect",
		"Mask",
		"Key",
		"Property",
		"MarkerKey"
	);
	var eleSubList = new Array;
eleSubList.push(new Array(
"comp(name)",
"footage(name)",
"thisComp",
"thisLayer",
"thisProperty",
"time",
"colorDepth",
"posterizeTime(framesPerSecond)",
"value"
));
eleSubList.push(new Array(
"timeToFrames(t = time + thisComp.displayStartTime, fps = 1.0 / thisComp.frameDuration, isDuration = false)",
"framesToTime(frames, fps = 1.0 / thisComp.frameDuration)",
"timeToTimecode(t = time + thisComp.displayStartTime, timecodeBase = 30, isDuration = false)",
"timeToNTSCTimecode(t = time + thisComp.displayStartTime, ntscDropFrame = false, isDuration = false)",
"timeToFeetAndFrames(t = time + thisComp.displayStartTime, fps = 1.0 / thisComp.frameDuration, framesPerFoot = 16, isDuration = false)",
"timeToCurrentFormat(t = time + thisComp.displayStartTime, fps = 1.0 / thisComp.frameDuration, isDuration = false)"
));
eleSubList.push(new Array(
"add(vec1, vec2)",
"sub(vec1, vec2)",
"mul(vec, amount)",
"div(vec, amount)",
"clamp(value, limit1, limit2)",
"dot(vec1, vec2)",
"cross(vec1, vec2)",
"normalize(vec)",
"length(vec)",
"length(point1, point2)",
"lookAt(fromPoint, atPoint)"
));
eleSubList.push(new Array(
"seedRandom(offset, timeless=false)",
"random()",
"random(maxValOrArray)",
"random(minValOrArray, maxValOrArray)",
"gaussRandom()",
"gaussRandom(maxValOrArray)",
"gaussRandom(minValOrArray, maxValOrArray)",
"noise(valOrArray)"
));
eleSubList.push(new Array(
"linear(t, tMin, tMax, value1, value2)",
"linear(t, value1, value2)",
"ease(t, value1, value2)",
"ease(t, tMin, tMax, value1, value2)",
"easeIn(t, value1, value2)",
"easeOut(t, value1, value2)",
"easeOut(t, tMin, tMax, value1, value2)"
));
eleSubList.push(new Array(
"rgbToHsl(rgbaArray)",
"hslToRgb(hslaArray)"
));
eleSubList.push(new Array(
"degreesToRadians(degrees)",
"radiansToDegrees(radians)"
));
eleSubList.push(new Array(
"layer(index)",
"layer(name)",
"layer(otherLayer, relIndex)",
"marker",
"marker.key(index)",
"marker.key(name)",
"marker.nearestKey(t)",
"marker.numKeys",
"numLayers",
"activeCamera",
"width",
"height",
"duration",
"displayStartTime",
"frameDuration",
"shutterAngle",
"shutterPhase",
"bgColor",
"pixelAspect",
"name"
));
eleSubList.push(new Array(
"width",
"height",
"duration",
"frameDuration",
"pixelAspect",
"name"
));
eleSubList.push(new Array(
"effect(name)",
"effect(index)",
"mask(name)",
"mask(index)"
));
eleSubList.push(new Array(
"anchorPoint",
"position",
"scale",
"rotation",
"opacity",
"audioLevels",
"timeRemap",
"marker.key(index)",
"marker.key(name)",
"marker.nearestKey(t)",
"marker.numKeys",
"name"
));
eleSubList.push(new Array(
"orientation",
"rotationX",
"rotationY",
"rotationZ",
"lightTransmission",
"castsShadows",
"acceptsShadows",
"acceptsLights",
"ambient",
"diffuse",
"specular",
"shininess",
"metal",
));
eleSubList.push(new Array(
"toComp(point, t=time)",
"fromComp(point, t=time)",
"toWorld(point, t=time)",
"fromWorld(point, t=time)",
"toCompVec(vec, t=time)",
"fromCompVec(vec, t=time)",
"toWorldVec(vec, t=time)",
"fromWorldVec(vec, t=time)",
"fromCompToSurface(point, t=time)"
));
eleSubList.push(new Array(
"pointOfInterest",
"zoom",
"depthOfField",
"focusDistance",
"aperture",
"blurLevel",
"active"
));
eleSubList.push(new Array(
"pointOfInterest",
"intensity",
"color",
"coneAngle",
"coneFeather",
"shadowDarkness",
"shadowDiffusion"
));
eleSubList.push(new Array(
"active",
"param(name)",
"param(index)"
));
eleSubList.push(new Array(
"MaskOpacity",
"MaskFeather",
"maskExpansion",
"invert"
));
eleSubList.push(new Array(
"value",
"valueAtTime(t)",
"velocity",
"velocityAtTime(t)",
"speed",
"speedAtTime(t)",
"wiggle(freq, amp, octaves=1, amp_mult=.5, t=time)",
"temporalWiggle(freq, amp, octaves=1, amp_mult=.5, t=time)",
"smooth(width=.2, samples=5, t=time)",
"loopIn(type=\"cycle\", numKeyframes=0)",
"loopOut(type=\"cycle\", numKeyframes=0)",
"loopInDuration(type=\"cycle\", duration=0)",
"loopOutDuration(type=\"cycle\", duration=0)",
"key(index)",
"key(markerName)",
"nearestKey(t)",
"numKeys",
"propertyGroup(countUp = 1)",
"propertyIndex",
"name"
));
eleSubList.push(new Array(
"value",
"time",
"index"
));
eleSubList.push(new Array(
"duration",
"comment",
"chapter",
"url",
"eventCuePoint",
"cuePointName",
"parameters"
));

//-------
	///////////////////////////////////////////////////////////////////////////////////////////////
	//プロパティのアクセス配列を得る
	function proPath(p)
	{
		var ret = [];
		if ( ( p== null)||(p==undefined)) return ret;
		if (  (p instanceof Property )||(p instanceof PropertyGroup )||(p instanceof MaskPropertyGroup )) {
			var pp = p;
			while ( pp != null){
				ret.push(pp);
				pp = pp.parentProperty;	//このメソッドがキモ
			}
			//配列をひっくり返す
			if ( ret.length>1) ret = ret.reverse();
		}
		//返されるObjectは、Layerからになる
		return ret;
	} 
	///////////////////////////////////////////////////////////////////////////////////////////////
	//Javascriptのコードに変換
	function proPathToString(ary,o)
	{
		if ( !(ary instanceof Array) ) return "";
		if ( ary.length <=2) return "";
		
		var ret = "";
		if (( o.comp.name == targetComp.name) && (o.layer.name == targetLayer.name) ){
			ret = "";
		}else if ( o.comp.name == targetComp.name){
			ret = "thisComp";
			//Layer名
			ret += ".layer(\"" + ary[0].name +"\")";
		}else{
			if ( ( targetLayer.source instanceof CompItem)&&(targetLayer.name == o.comp.name) ) {
				ret = "comp(name)";
			}else{
				ret = "comp(\"" + o.comp.name + "\")";
			}
			//Layer名
			ret += ".layer(\"" + ary[0].name +"\")";
		}
		if ( ret != "") ret +=".";

		if ( ary[1].matchName == "ADBE Transform Group") {
			switch(ary[2].matchName)
			{
				case "ADBE Anchor Point" :
					if ( ary[0] instanceof LightLayer) {
						ret += "transform.pointOfInterest";
					}else{
						ret += "transform.anchorPoint";
					}
					break;
				case "ADBE Orientation" : ret += "transform.orientation";  break;
				case "ADBE Position" :
				case "ADBE Position_0" : 
				case "ADBE Position_1" :
				case "ADBE Position_2" : ret += "transform.position";  break;
				case "ADBE Scale" : ret += "transform.scale"; break;
				case "ADBE Rotate X" :
					if (( ary[0] instanceof CameraLayer)||( ary[0].threeDLayer == true)){
						ret += "transform.xRotation";
					}else{
						ret += "transform.rotation";
					}
					break;
				case "ADBE Rotate Y" :
					if (( ary[0] instanceof CameraLayer)||( ary[0].threeDLayer == true)){
						ret += "transform.yRotation";
					}else{
						ret += "transform.rotation";
					}
					break;
				case "ADBE Rotate Z" :
					if (( ary[0] instanceof CameraLayer)||( ary[0].threeDLayer == true)){
						ret += "transform.zRotation";
					}else{
						ret += "transform.rotation";
					}
					break;
				case "ADBE Opacity" : ret += "transform.opacity";break;
			}
		}else if ( ary[1].matchName == "ADBE Effect Parade") {
			ret += "effect";
			for ( var i=2; i<ary.length; i++){
				if (( ary[i] instanceof PropertyGroup)||( ary[i] instanceof MaskPropertyGroup)){
					
					var canNameChange = (ary[i].propertyType == PropertyType.NAMED_GROUP);
					
					if (canNameChange ==true){
						ret += "(\"" + ary[i].name +"\")";
					}else{
						ret += "(\"" + ary[i].matchName +"\")";
					}
					
				}else if ( ary[i] instanceof Property){
					ret += "(\"" + ary[i].matchName +"\")";
				}
			}
		}else if ( ary[1].matchName == "ADBE Text Properties") {
			return "";
		}
		ret +=";\r\n/* layerIndex:"+ ary[0].index +  " name:\"" + ary[ary.length-1].name +"\"*/\r\n";
		return ret;

	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	var winObj = ( me instanceof Panel) ? me : new Window("palette", "Expressionの編集　curry_eggsさんのエディタが完成するまで暫定版", [  44,   58,   44+ 952,   58+ 415]);
	
	var btnGetProperty = winObj.add("button", [   9,   34,    9+  75,   34+  48], "プロパティ", {name:'ok'});
	var edTargetProperty = winObj.add("edittext", [  91,   34,   91+ 845,   34+  48], "", {readonly:false, multiline:true});
	var lstLayer = winObj.add("dropdownlist", [  10,   88,   10+ 173,   88+  20], [ ]);
	var lstProp = winObj.add("listbox", [  10,  115,   10+ 173,  115+ 292], [ ]);
	var btnGetExp = winObj.add("button", [ 499,  382,  499+  75,  382+  23], "獲得", {name:'ok'});
	var stGetExp = winObj.add("statictext", [ 197,   93,  197+ 438,   93+  18], "statictext_AE1");
	var edExp = winObj.add("edittext", [ 189,  114,  189+ 747,  114+ 250], "", {readonly:false, multiline:true});
	var btnDelExp = winObj.add("button", [ 197,  372,  197+ 132,  372+  33], "エクスプレッションを削除");
	//var btnTextSave = winObj.add("button", [ 335,  372,  335+  75,  372+  33], "Text Save");
	//var btnTextLoad = winObj.add("button", [ 416,  372,  416+  75,  372+  33], "Text Load");
	var statictext_AE1 = winObj.add("statictext", [  13,   16,   13+ 325,   16+  15], "プロパティボタンで選択した項目のアクセスコードを獲得");
	var statictext_AE2 = winObj.add("statictext", [ 497,  367,  497+ 241,  367+  12], "ターゲットのエクスプレッションを獲得。まずここを押す");
	var statictext_AE3 = winObj.add("statictext", [ 692,   16,  692+ 244,   16+  15], "curry_eggsさんのエディタが完成するまで暫定版");
	var statictext_AE4 = winObj.add("statictext", [ 771,   93,  771+ 165,   93+  18], "改行は、Ctrl+Returnになります。");
	var btnOK = winObj.add("button", [ 780,  372,  780+  75,  372+  33], "適用", {name:'ok'});
	if ( isPanel == true )
		var btnCancel = winObj.add("button", [ 861,  372,  861+  75,  372+  33], "初期化", {name:'cancel'});
	else
		var btnCancel = winObj.add("button", [ 861,  372,  861+  75,  372+  33], "閉じる", {name:'cancel'});
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	stGetExp.text = "";
	btnOK.enabled = false;
	statictext_AE4.enabled = statictext_AE4.visible = true;
	///////////////////////////////////////////////////////////////////////////////////////////////
	function selectedIndex(ctrl)
	{
		var ret = -1;
		if ( ctrl == null) return ret;
		if ( ctrl.items.length<=0)  return ret;
		for ( var i=0; i<ctrl.items.length; i++){
			if (ctrl.items[i].selected == true) {
				ret = i;
				break;
			}
		}
		return ret;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	function buildLstLayer(cmp)
	{
		lstLayer.removeAll();
		for ( var i=0; i<eleList.length; i++){
			lstLayer.add("item",eleList[i]);
		}
	}
	buildLstLayer();
	///////////////////////////////////////////////////////////////////////////////////////////////
	lstLayer.onChange = function()
	{
		eleListIndex = -1;
		var i = selectedIndex(lstLayer);
		lstProp.removeAll();
		if ( i >= eleSubList.length) return;
		var lst = eleSubList[i];
		eleListIndex = i;
		if ( lst.length>0) {
			for ( var k=0; k<lst.length; k++){
				lstProp.add("item",lst[k]);
			}
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	lstProp.onChange = function()
	{
		var i = selectedIndex(lstProp);
		if ( (i>=0)&&(eleListIndex>=0)) {
			edTargetProperty.text = eleSubList[eleListIndex][i];
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	function getTarget()
	{
		var ret = new Object;
		ret.comp = null;
		ret.layer = null;
		ret.property = null;
		ret.noneSuport = false;
		if ( (app.project.activeItem instanceof CompItem)==false) return ret;
		ret.comp = app.project.activeItem;
		
		if ( ret.comp.selectedLayers.length<=0) return ret;
		ret.layer = ret.comp.selectedLayers[0];
		
		
		if ( ret.layer.selectedProperties.length>0){
			for ( var i=0; i<ret.layer.selectedProperties.length; i++){
				if ( ret.layer.selectedProperties[i] instanceof Property){
					ret.property = ret.layer.selectedProperties[i];
					var p = proPath(ret.property);
					if ( ( p[1].matchName == "ADBE Text Properties")
						||( p[1].matchName == "ADBE Light Options Group")
						||( p[1].matchName == "ADBE Root Vectors Group"))
					{
						ret.noneSuport = true;
					}
					break;
				}
			}
		}
		
		return ret;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	function setMode(o)
	{
		if ((o ==null)||( o.property == null)||(o.property == undefined)){
			targetComp		= null;
			targetLayer		= null;
			targetProperty	= null;
			stGetExp.text	= "";
			btnOK.enabled	= false;
			btnGetProperty.enabled	= false;
			edTargetProperty.text = "";
			edExp.text = "";
		}else{
			targetComp		= o.comp;
			targetLayer		= o.layer;
			targetProperty	= o.property;
			var s = "";
			s += o.comp.name;
			s += "/" + o.layer.name;
			s += "/" + o.property.name;
			stGetExp.text = s; 
			btnOK.enabled	= true;
			btnGetProperty.enabled	= true;
			edTargetProperty.text = "";
			edExp.enabled = true;
		}
	}
	setMode(null);
	///////////////////////////////////////////////////////////////////////////////////////////////
	btnGetExp.onClick = function()
	{
		setMode(null);
		var t = getTarget();
		if ( t.property != null){
			if ( t.property.canSetExpression == true) {
				if ( t.noneSuport == true){
					alert("すみません。未対応です。");
				}else{
					setMode(t);
					if (targetProperty.expression == ""){
						var s = proPathToString(proPath(t.property),t);
						edExp.text = s;
						/*
						app.beginUndoGroup("エクスプレッションの追加");
						targetProperty.expression = s;
						targetProperty.expressionEnabled = true;
						app.endUndoGroup();
						*/
					}else{
						edExp.text = targetProperty.expression;
					}
				}
			}else{
				alert("なんかエクスプレッションにできないっす。");
			}
		}else{
			alert("なんかプロパティを選んでちょ！");
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	btnGetProperty.onClick = function()
	{
		var t = getTarget();
		if ( t.property != null){
			if ( t.noneSuport == true){
				alert("すみません。未対応です。");
			}else{
				var s = proPathToString(proPath(t.property),t);
				edTargetProperty.text = s;
			}
		}else{
			edTargetProperty.text = "";
			alert("なんかプロパティを選んでちょ！");
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	btnOK.onClick = function()
	{
		var s = edExp.text;
		if ( s == "" ) return;
		if (targetProperty == null) return;
		app.beginUndoGroup("エクスプレッションの編集");
		try{
			targetProperty.expression = s;
			targetProperty.expressionEnabled = true;
			setMode(null);
		}catch(e){
			if ( targetProperty.expressionError != "")
				alert(targetProperty.expressionError);
		}
		app.endUndoGroup();
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	btnDelExp.onClick = function()
	{
		var t = getTarget();
		if ( t.property != null){
			app.beginUndoGroup("エクスプレッションの削除");
			t.property.expression = "";
			app.endUndoGroup();
		}else{
			alert("なんかプロパティを選んでちょ！");
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	if ( isPanel == false){
		btnCancel.onClick = function() { winObj.close();}
		btnCancel.title = "閉じる";
		winObj.center();
		winObj.show();
	}else{
		btnCancel.onClick = function() { setMode(null);}
		btnCancel.title = "初期化";
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
})(this);
