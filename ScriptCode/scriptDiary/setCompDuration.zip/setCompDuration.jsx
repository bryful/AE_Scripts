﻿/*
	選択したコンポジションの長さを設定する。
	
*/
(function ()
{
	var targetComps = new Array;

	var sel = app.project.selection;
	if ( sel.length>0) {
		for (var i=0; i<sel.length; i++){
			if ( sel[i] instanceof CompItem){
				targetComps.push(sel[i]);
			}
		}
	}
	if (targetComps.length<=0) {
		alert("コンポを選択してください。");
		return;
	}
	//--------------------------------------------------
	function setDuration(nd)
	{
		app.beginUndoGroup("setCompDuration");
		for (var i=0; i<targetComps.length; i++){
			targetComps[i].duration = nd;
		}
		app.endUndoGroup();
	}
	//--------------------------------------------------
	function settingDlg()
	{
	var winObj = new Window("dialog", "選択したコンポの長さを一括設定", [  66,   87,   66+ 410,   87+ 454]);
	
	
	var panel_AE1 = winObj.add("panel", [  24,   12,   24+ 364,   12+ 368], "動作");
	var rbFrame = panel_AE1.add("radiobutton", [  31,   18,   31+  89,   18+  16], "Frameで指定");
	var edFrame = panel_AE1.add("edittext", [ 126,   15,  126+ 151,   15+  19], "", {readonly:false, multiline:false});
	var rbSecKoma = panel_AE1.add("radiobutton", [  31,   46,   31+  92,   46+  16], "秒+コマで指定");
	var edSec = panel_AE1.add("edittext", [ 126,   43,  126+  69,   43+  19], "", {readonly:false, multiline:false});
	var stPluss = panel_AE1.add("statictext", [ 202,   46,  202+  17,   46+  12], "＋");
	var edKoma = panel_AE1.add("edittext", [ 225,   43,  225+  52,   43+  19], "", {readonly:false, multiline:false});
	var stFrameRate = panel_AE1.add("statictext", [  59,   82,   59+  61,   82+  12], "FrameRate");
	var edFrameRate = panel_AE1.add("edittext", [ 126,   79,  126+  69,   79+  19], "", {readonly:true, multiline:false});
	var statictext_AE1 = panel_AE1.add("statictext", [  18,  115,   18+ 246,  115+  12], "リストをクリックするとそのコンポの秒数を獲得できます");
	var listComp = panel_AE1.add("listbox", [  18,  133,   18+ 330,  133+ 220], [ ]);
	var btnCancel = winObj.add("button", [ 207,  417,  207+  75,  417+  23], "Cancel", {name:'cancel'});
	var btnOK = winObj.add("button", [ 297,  417,  297+  75,  417+  23], "OK", {name:'ok'});
	var srWarning = winObj.add("statictext", [  31,  392,   31+ 270,  392+  12], "レイヤのin点/out点には何もしません。確認が必要です。");

	
		//---------------
		this.show = function()
		{
			winObj.center();
			return winObj.show();
		}
		//---------------
		edFrameRate.text = "24";
		//---------------
		function selectedIndex()
		{
			var ret = -1;
			if ( listComp.items.length<=0) {
				return ret;
			}
			for ( var i=0; i<listComp.items.length; i++){
				if (listComp.items[i].selected == true){
					ret = i;
					break;
				}
			}
			return ret;
		}
		//---------------
		if (targetComps.length>0){
			for (var i=0; i<targetComps.length; i++){
				listComp.add("item",targetComps[i].name);
			}
		}
		//---------------
		rbFrame.value = true;
		edFrame.enabled = true;
		rbSecKoma.value = false;
		edSec.enabled = false;
		edKoma.enabled = false;
		//---------------
		
		rbFrame.onClick = function(){
			rbFrame.value = true;
			edFrame.enabled = true;
			rbSecKoma.value = false;
			edSec.enabled = false;
			edKoma.enabled = false;
		}
		//---------------
		rbSecKoma.onClick = function(){
			rbFrame.value = false;
			edFrame.enabled = false;
			rbSecKoma.value = true;
			edSec.enabled = true;
			edKoma.enabled = true;
		}
		//---------------
		function toEdit(idx)
		{
			var cmp = targetComps[idx];
			var frm = Math.floor(cmp.duration * cmp.frameRate);
			edFrame.text = frm +"";
			edSec.text = Math.floor(frm /cmp.frameRate) +"";
			edKoma.text = Math.floor(frm % cmp.frameRate) +"";
			edFrameRate.text = cmp.frameRate;
		}
		//---------------
		listComp.onChange = function(){
			var idx = selectedIndex();
			if (idx>=0){
				toEdit(idx);
			}
		}
		//---------------
		if ( targetComps.length>0){
			listComp.items[0].selected = true;
			//toEdit(0);
		}
		//---------------
		btnOK.onClick = function(){
			var d = 0;
			if ( rbFrame.value == true){
				d = (edFrame.text * 1) / (edFrameRate.text * 1);
			}else{
				d = (edSec.text * 1) + ( (edKoma.text * 1) / (edFrameRate.text * 1));
			}
			setDuration(d);
			winObj.close();
		}
		//---------------
		btnCancel.onClick = function(){
			winObj.close();
		}
	}
	var sDlg = new settingDlg();
	sDlg.show();
})();