﻿namespace js_trim
{
	partial class cellTrimings
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.aE_DialogsMain1 = new bryful.AE_DialogsMain();
			this.pnlResize = new bryful.panel_AE();
			this.cbIsToInt = new bryful.checkbox_AE();
			this.stDiv = new bryful.statictext_AE();
			this.cbIsNoResize = new bryful.checkbox_AE();
			this.stShoote = new bryful.statictext_AE();
			this.tbShooteSize = new bryful.edittext_AE();
			this.tbPaintSize = new bryful.edittext_AE();
			this.cbIsSelectedOnly = new bryful.checkbox_AE();
			this.btnOK = new bryful.button_AE();
			this.btnSetGuideFrame = new bryful.button_AE();
			this.pnlNames = new bryful.panel_AE();
			this.stMixedCompFooter = new bryful.statictext_AE();
			this.tbMixedCompFooter = new bryful.edittext_AE();
			this.stPartsFolderFooter = new bryful.statictext_AE();
			this.tbPartsFolderFooter = new bryful.edittext_AE();
			this.pnlSmooth = new bryful.panel_AE();
			this.rbPSOFT = new bryful.radiobutton_AE();
			this.rbOLM = new bryful.radiobutton_AE();
			this.rbNone = new bryful.radiobutton_AE();
			this.cbIsBG = new bryful.checkbox_AE();
			this.pnlResize.SuspendLayout();
			this.pnlNames.SuspendLayout();
			this.pnlSmooth.SuspendLayout();
			this.SuspendLayout();
			// 
			// aE_DialogsMain1
			// 
			this.aE_DialogsMain1.Form = this;
			this.aE_DialogsMain1.IsLocal = true;
			this.aE_DialogsMain1.IsPalette = true;
			this.aE_DialogsMain1.winObjName = "winObj";
			// 
			// pnlResize
			// 
			this.pnlResize.Controls.Add(this.cbIsToInt);
			this.pnlResize.Controls.Add(this.stDiv);
			this.pnlResize.Controls.Add(this.cbIsNoResize);
			this.pnlResize.Controls.Add(this.stShoote);
			this.pnlResize.Controls.Add(this.tbShooteSize);
			this.pnlResize.Controls.Add(this.tbPaintSize);
			this.pnlResize.IsLocal = true;
			this.pnlResize.Location = new System.Drawing.Point(12, 40);
			this.pnlResize.Name = "pnlResize";
			this.pnlResize.Size = new System.Drawing.Size(156, 91);
			this.pnlResize.TabIndex = 1;
			this.pnlResize.TabStop = false;
			this.pnlResize.Text = "リサイズ設定";
			// 
			// cbIsToInt
			// 
			this.cbIsToInt.AutoSize = true;
			this.cbIsToInt.IsLocal = true;
			this.cbIsToInt.Location = new System.Drawing.Point(8, 61);
			this.cbIsToInt.Name = "cbIsToInt";
			this.cbIsToInt.Size = new System.Drawing.Size(130, 16);
			this.cbIsToInt.TabIndex = 5;
			this.cbIsToInt.Text = "Pos/Anchorを整数化";
			this.cbIsToInt.UseVisualStyleBackColor = true;
			// 
			// stDiv
			// 
			this.stDiv.AutoSize = true;
			this.stDiv.IsLocal = true;
			this.stDiv.Location = new System.Drawing.Point(88, 19);
			this.stDiv.Name = "stDiv";
			this.stDiv.Size = new System.Drawing.Size(11, 12);
			this.stDiv.TabIndex = 2;
			this.stDiv.Text = "/";
			// 
			// cbIsNoResize
			// 
			this.cbIsNoResize.AutoSize = true;
			this.cbIsNoResize.IsLocal = true;
			this.cbIsNoResize.Location = new System.Drawing.Point(8, 41);
			this.cbIsNoResize.Name = "cbIsNoResize";
			this.cbIsNoResize.Size = new System.Drawing.Size(89, 16);
			this.cbIsNoResize.TabIndex = 4;
			this.cbIsNoResize.Text = "リサイズしない";
			this.cbIsNoResize.UseVisualStyleBackColor = true;
			// 
			// stShoote
			// 
			this.stShoote.AutoSize = true;
			this.stShoote.IsLocal = true;
			this.stShoote.Location = new System.Drawing.Point(5, 19);
			this.stShoote.Name = "stShoote";
			this.stShoote.Size = new System.Drawing.Size(41, 12);
			this.stShoote.TabIndex = 0;
			this.stShoote.Text = "縮小率";
			// 
			// tbShooteSize
			// 
			this.tbShooteSize.IsLocal = true;
			this.tbShooteSize.Location = new System.Drawing.Point(46, 16);
			this.tbShooteSize.Name = "tbShooteSize";
			this.tbShooteSize.Size = new System.Drawing.Size(40, 19);
			this.tbShooteSize.TabIndex = 1;
			this.tbShooteSize.Text = "640";
			// 
			// tbPaintSize
			// 
			this.tbPaintSize.IsLocal = true;
			this.tbPaintSize.Location = new System.Drawing.Point(100, 16);
			this.tbPaintSize.Name = "tbPaintSize";
			this.tbPaintSize.Size = new System.Drawing.Size(37, 19);
			this.tbPaintSize.TabIndex = 3;
			this.tbPaintSize.Text = "1024";
			// 
			// cbIsSelectedOnly
			// 
			this.cbIsSelectedOnly.AutoSize = true;
			this.cbIsSelectedOnly.IsLocal = true;
			this.cbIsSelectedOnly.Location = new System.Drawing.Point(19, 387);
			this.cbIsSelectedOnly.Name = "cbIsSelectedOnly";
			this.cbIsSelectedOnly.Size = new System.Drawing.Size(140, 16);
			this.cbIsSelectedOnly.TabIndex = 5;
			this.cbIsSelectedOnly.Text = "選択レイヤのみ実行する";
			this.cbIsSelectedOnly.UseVisualStyleBackColor = true;
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.IsLocal = true;
			this.btnOK.Location = new System.Drawing.Point(12, 349);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(153, 32);
			this.btnOK.TabIndex = 4;
			this.btnOK.Text = "実行";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// btnSetGuideFrame
			// 
			this.btnSetGuideFrame.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnSetGuideFrame.IsLocal = true;
			this.btnSetGuideFrame.Location = new System.Drawing.Point(12, 5);
			this.btnSetGuideFrame.Name = "btnSetGuideFrame";
			this.btnSetGuideFrame.Size = new System.Drawing.Size(156, 30);
			this.btnSetGuideFrame.TabIndex = 0;
			this.btnSetGuideFrame.Text = "set F\'s GuideFrame";
			this.btnSetGuideFrame.UseVisualStyleBackColor = true;
			// 
			// pnlNames
			// 
			this.pnlNames.Controls.Add(this.stMixedCompFooter);
			this.pnlNames.Controls.Add(this.tbMixedCompFooter);
			this.pnlNames.Controls.Add(this.stPartsFolderFooter);
			this.pnlNames.Controls.Add(this.tbPartsFolderFooter);
			this.pnlNames.IsLocal = true;
			this.pnlNames.Location = new System.Drawing.Point(12, 242);
			this.pnlNames.Name = "pnlNames";
			this.pnlNames.Size = new System.Drawing.Size(156, 101);
			this.pnlNames.TabIndex = 3;
			this.pnlNames.TabStop = false;
			this.pnlNames.Text = "作成名称";
			// 
			// stMixedCompFooter
			// 
			this.stMixedCompFooter.AutoSize = true;
			this.stMixedCompFooter.IsLocal = true;
			this.stMixedCompFooter.Location = new System.Drawing.Point(15, 54);
			this.stMixedCompFooter.Name = "stMixedCompFooter";
			this.stMixedCompFooter.Size = new System.Drawing.Size(97, 12);
			this.stMixedCompFooter.TabIndex = 2;
			this.stMixedCompFooter.Text = "合成Comp・フッター";
			// 
			// tbMixedCompFooter
			// 
			this.tbMixedCompFooter.IsLocal = true;
			this.tbMixedCompFooter.Location = new System.Drawing.Point(17, 69);
			this.tbMixedCompFooter.Name = "tbMixedCompFooter";
			this.tbMixedCompFooter.Size = new System.Drawing.Size(100, 19);
			this.tbMixedCompFooter.TabIndex = 3;
			this.tbMixedCompFooter.Text = "_02Mixed";
			// 
			// stPartsFolderFooter
			// 
			this.stPartsFolderFooter.AutoSize = true;
			this.stPartsFolderFooter.IsLocal = true;
			this.stPartsFolderFooter.Location = new System.Drawing.Point(15, 15);
			this.stPartsFolderFooter.Name = "stPartsFolderFooter";
			this.stPartsFolderFooter.Size = new System.Drawing.Size(108, 12);
			this.stPartsFolderFooter.TabIndex = 0;
			this.stPartsFolderFooter.Text = "パーツフォルダ・フッター";
			// 
			// tbPartsFolderFooter
			// 
			this.tbPartsFolderFooter.IsLocal = true;
			this.tbPartsFolderFooter.Location = new System.Drawing.Point(17, 30);
			this.tbPartsFolderFooter.Name = "tbPartsFolderFooter";
			this.tbPartsFolderFooter.Size = new System.Drawing.Size(100, 19);
			this.tbPartsFolderFooter.TabIndex = 1;
			this.tbPartsFolderFooter.Text = "_01Parts";
			// 
			// pnlSmooth
			// 
			this.pnlSmooth.Controls.Add(this.cbIsBG);
			this.pnlSmooth.Controls.Add(this.rbPSOFT);
			this.pnlSmooth.Controls.Add(this.rbOLM);
			this.pnlSmooth.Controls.Add(this.rbNone);
			this.pnlSmooth.IsLocal = true;
			this.pnlSmooth.Location = new System.Drawing.Point(12, 137);
			this.pnlSmooth.Name = "pnlSmooth";
			this.pnlSmooth.Size = new System.Drawing.Size(156, 99);
			this.pnlSmooth.TabIndex = 2;
			this.pnlSmooth.TabStop = false;
			this.pnlSmooth.Text = "スムージング";
			// 
			// rbPSOFT
			// 
			this.rbPSOFT.IsLocal = true;
			this.rbPSOFT.Location = new System.Drawing.Point(12, 50);
			this.rbPSOFT.Name = "rbPSOFT";
			this.rbPSOFT.Size = new System.Drawing.Size(128, 16);
			this.rbPSOFT.TabIndex = 2;
			this.rbPSOFT.TabStop = true;
			this.rbPSOFT.Text = "PSOFT anti-aliasing";
			this.rbPSOFT.UseVisualStyleBackColor = true;
			// 
			// rbOLM
			// 
			this.rbOLM.IsLocal = true;
			this.rbOLM.Location = new System.Drawing.Point(12, 34);
			this.rbOLM.Name = "rbOLM";
			this.rbOLM.Size = new System.Drawing.Size(128, 16);
			this.rbOLM.TabIndex = 1;
			this.rbOLM.TabStop = true;
			this.rbOLM.Text = "OLM Smoother";
			this.rbOLM.UseVisualStyleBackColor = true;
			// 
			// rbNone
			// 
			this.rbNone.IsLocal = true;
			this.rbNone.Location = new System.Drawing.Point(12, 18);
			this.rbNone.Name = "rbNone";
			this.rbNone.Size = new System.Drawing.Size(128, 16);
			this.rbNone.TabIndex = 0;
			this.rbNone.TabStop = true;
			this.rbNone.Text = "処理無し";
			this.rbNone.UseVisualStyleBackColor = true;
			// 
			// cbIsBG
			// 
			this.cbIsBG.AutoSize = true;
			this.cbIsBG.Checked = true;
			this.cbIsBG.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbIsBG.IsLocal = true;
			this.cbIsBG.Location = new System.Drawing.Point(12, 72);
			this.cbIsBG.Name = "cbIsBG";
			this.cbIsBG.Size = new System.Drawing.Size(101, 16);
			this.cbIsBG.TabIndex = 6;
			this.cbIsBG.Text = "BG/BOOK対策";
			this.cbIsBG.UseVisualStyleBackColor = true;
			// 
			// cellTrimings
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(178, 435);
			this.Controls.Add(this.pnlSmooth);
			this.Controls.Add(this.pnlNames);
			this.Controls.Add(this.btnSetGuideFrame);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.cbIsSelectedOnly);
			this.Controls.Add(this.pnlResize);
			this.Name = "cellTrimings";
			this.Text = "切り取り";
			this.pnlResize.ResumeLayout(false);
			this.pnlResize.PerformLayout();
			this.pnlNames.ResumeLayout(false);
			this.pnlNames.PerformLayout();
			this.pnlSmooth.ResumeLayout(false);
			this.pnlSmooth.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private bryful.AE_DialogsMain aE_DialogsMain1;
		private bryful.button_AE btnOK;
		private bryful.checkbox_AE cbIsSelectedOnly;
		private bryful.panel_AE pnlResize;
		private bryful.statictext_AE stShoote;
		private bryful.edittext_AE tbShooteSize;
		private bryful.edittext_AE tbPaintSize;
		private bryful.panel_AE pnlNames;
		private bryful.statictext_AE stMixedCompFooter;
		private bryful.edittext_AE tbMixedCompFooter;
		private bryful.statictext_AE stPartsFolderFooter;
		private bryful.edittext_AE tbPartsFolderFooter;
		private bryful.button_AE btnSetGuideFrame;
		private bryful.panel_AE pnlSmooth;
		private bryful.radiobutton_AE rbPSOFT;
		private bryful.radiobutton_AE rbOLM;
		private bryful.radiobutton_AE rbNone;
		private bryful.checkbox_AE cbIsNoResize;
		private bryful.statictext_AE stDiv;
		private bryful.checkbox_AE cbIsToInt;
		private bryful.checkbox_AE cbIsBG;
	}
}

