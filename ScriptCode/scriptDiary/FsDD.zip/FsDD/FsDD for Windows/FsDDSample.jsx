
#include "FsDD.jsxinc"

function exec(ary)
{
	var s = "";
	for ( var i=0; i<ary.length; i++)
		s += ary[i].fsName +"\n";
	alert(s);
}

FsDD.show(exec);
