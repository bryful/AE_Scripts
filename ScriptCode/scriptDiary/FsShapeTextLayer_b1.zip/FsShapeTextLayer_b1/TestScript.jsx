﻿#include "FsShapeTextLayer.jsxinc";

var ac = app.project.activeItem;

var code ="";
if ( ac instanceof CompItem){

	var cmpObj = ac.getObject();
	code += "//-----------------------\r\n";
	code += "var cmpObj = " + JSON.stringify(cmpObj,null," ") +";\r\n";
	code += "var cmp = app.project.addCompFromObj(cmpObj);\r\n";
	
	if ( ac.numLayers>0){
		code += "//-----------------------\r\n";
		code += "var layers = [];\r\n";
		for ( var i= ac.numLayers; i>=1; i--){
			var lyr = ac.layers[i];
			if ( (lyr instanceof TextLayer)||(lyr instanceof ShapeLayer)){
				var lyrObj = lyr.getObject();
				code += "//-----------------------\r\n";
				code += "var lyrObj = " + JSON.stringify(lyrObj,null," ") +";\r\n";
				code += "var lyr = cmp.addLayerFromObj(lyrObj);\r\n";
				code += "layers.push(lyr);\r\n";
				
			}
		}
		code += "//-----------------------\r\n";
	}
	

}else{
	alert("コンポを選択してください");
}

if ( code != ""){
	var f = File.saveDialog("SampleCode","*.jsx");
	if ( f!=null){
		f.encoding = "UTF-8";
		f.open("w");
		try{
			f.write(code);
		}finally{
			f.close();
		}
	}
}


